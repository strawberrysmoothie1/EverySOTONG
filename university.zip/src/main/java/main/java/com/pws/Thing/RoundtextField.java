package main.java.com.pws.Thing;

import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JTextField;

public class RoundtextField extends JTextField implements FocusListener {
    private String defaultText;

    public RoundtextField() {
        super();
        decorate();
        addFocusListener(this);
    }

    public RoundtextField(String text) {
        super(text);
        this.defaultText = text;
        decorate();
        addFocusListener(this);
    }

    protected void decorate() {
        setOpaque(false);
        setHorizontalAlignment(JTextField.LEFT);
    }

    @Override
    protected void paintComponent(Graphics g) {
        int width = getWidth();
        int height = getHeight();
        Graphics2D graphics = (Graphics2D) g;
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics.setColor(getBackground());
        graphics.fillRoundRect(0, 0, width, height, 10, 10);
        if (!isFocusOwner() && getText().isEmpty()) {
            FontMetrics fontMetrics = graphics.getFontMetrics();
            Rectangle stringBounds = fontMetrics.getStringBounds(this.getText(), graphics).getBounds();
            int textX = 8;
            int textY = (height - stringBounds.height) / 2 + fontMetrics.getAscent();
            graphics.setColor(getForeground());
            graphics.setFont(getFont());
            graphics.drawString(getText(), textX, textY);
        } else {
            super.paintComponent(g);
        }
        graphics.dispose();
    }

    // 포커스를 얻었을 때 호출됨
    @Override
    public void focusGained(FocusEvent e) {
        if (getText().equals(defaultText)) {
            setText("");
        }
    }

    // 포커스를 잃었을 때 호출됨
    @Override
    public void focusLost(FocusEvent e) {
        if (getText().isEmpty()) {
            setText(defaultText);
        }
    }

    // 새로운 기본 텍스트 설정
    public void setDefaultText(String text) {
        this.defaultText = text;
        if (getText().isEmpty()) {
            setText(defaultText);
        }
    }


}
