package main.java.com.pws.Thing;

import java.util.ArrayList;
import javax.swing.JFrame;

public class FrameManager {
    private static ArrayList<JFrame> frames = new ArrayList<>();

    public static void addFrame(JFrame frame) {
        frames.add(frame);
    }

    public static void closeAllFrames() {
        for (JFrame frame : frames) {
            frame.dispose();
        }
        frames.clear();
    }
}
