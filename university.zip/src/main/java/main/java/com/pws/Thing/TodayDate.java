package main.java.com.pws.Thing;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TodayDate {

	
    public long TodayDate() {
        // 현재 날짜와 시간을 가져오기
        LocalDateTime currentDateTime = LocalDateTime.now();

        // DateTimeFormatter를 사용하여 원하는 형식으로 포맷팅
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmm");

        // 포맷된 현재 날짜와 시간 반환
        long intNewBdate = Long.parseLong(currentDateTime.format(formatter));
        return intNewBdate;
    }
    
    public static long addDaysToCurrentDate(int daysToAdd) {
        LocalDateTime currentDateTime = LocalDateTime.now();
        LocalDateTime newDateTime = currentDateTime.plusDays(daysToAdd);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmm");
        return Long.parseLong(newDateTime.format(formatter));
    }
    
    public static String formatDateTime(LocalDateTime dateTime) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return dateTime.format(formatter);
    }
    
    public static LocalDateTime parseDateTime(String dateStr) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmm");
        return LocalDateTime.parse(dateStr, formatter);
    }
}
