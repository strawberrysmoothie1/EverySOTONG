package main.java.com.pws.Schedule;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicScrollBarUI;

import org.json.JSONObject;


import main.java.com.pws.Thing.FrameManager;
import main.java.com.pws.Thing.GetLecture;
import main.java.com.pws.Thing.GetUserLecture;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundedBorder;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.RoundedComboBox;
import main.java.com.pws.Thing.RoundtextField;
import main.java.com.pws.Thing.collor;


public class UserLecture{
	private String userIDD;
	private String Section;
	private int DarK;

    public UserLecture(String userIDD, String Section, int DarK) {
        this.userIDD = userIDD;
        this.Section = Section;
        this.DarK = DarK;

        initialize();
    }

    private void initialize() {
	    JSONObject data = new JSONObject();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }


	    data.put("table", "users");
	    data.put("want", "UID");
	    data.put("what", "UserID");
	    data.put("user_id", userIDD);
	    Post po = new Post();
		JSONObject SearchNickname1 = po.jsonpost("/find_user_information", data);
		String AdminUID = SearchNickname1.getString("UID");
	
        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        Border borderBlack = BorderFactory.createLineBorder(colors.BoardPanel, 1);
	
	    // 다이얼로그 프레임 생성
	    JFrame dialogFrame = new JFrame();
	    dialogFrame.setBounds(150, 240, 550, 570);
	    dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	    dialogFrame.getContentPane().setLayout(null);
	
    	FrameManager.addFrame(dialogFrame);

	    // 다이얼로그 패널 생성
	    JPanel dialogPanel = new JPanel();
	    dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
	    dialogPanel.setBounds(5, 0, 526, 528);
	    dialogPanel.setLayout(null);
	    dialogPanel.setBackground(colors.Ground); // 배경색 설정
	    dialogPanel.setBorder(borderWhite); // 테두리 설정
	    dialogFrame.getContentPane().add(dialogPanel);
	
        String[] SearchLectures = {"없음"};
        RoundedButton AdChangeUbutton = new RoundedButton("강의 추가");
        AdChangeUbutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	LectureList adminlecture = new LectureList(userIDD, SearchLectures, Section, "강의실", DarK);
            }
        });
        AdChangeUbutton.setBackground(new Color(255, 30, 30));// 배경색 설정 (빨간색)
        AdChangeUbutton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        AdChangeUbutton.setBounds(437, 26, 60, 20);
        dialogFrame.add(AdChangeUbutton);
        
	    // 다이얼로그 라벨 생성
	    JLabel MyPostLabel = new JLabel("전체 수강 목록");
	    MyPostLabel.setBounds(200, 25, 200, 20);
	    MyPostLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
	    Font MyPostFont = new Font(MyPostLabel.getFont().getName(), Font.BOLD, 20);
	    MyPostLabel.setFont(MyPostFont);
	    dialogPanel.add(MyPostLabel);
	    
	    
	    JLabel ShowIDLabel = new JLabel("수강 학기");
	    ShowIDLabel.setBounds(63, 60, 100, 20);
	    ShowIDLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
	    Font ShowInfoFont = new Font(ShowIDLabel.getFont().getName(), Font.BOLD, 15);
	    ShowIDLabel.setFont(ShowInfoFont);
	    dialogPanel.add(ShowIDLabel);
	    
	    JLabel ShowNameLabel = new JLabel("강의");
	    ShowNameLabel.setBounds(251, 60, 100, 20);
	    ShowNameLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
	    ShowNameLabel.setFont(ShowInfoFont);
	    dialogPanel.add(ShowNameLabel);
	    
	    JLabel ShowDeptLabel = new JLabel("취득학점");
	    ShowDeptLabel.setBounds(381, 60, 100, 20);
	    ShowDeptLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
	    ShowDeptLabel.setFont(ShowInfoFont);
	    dialogPanel.add(ShowDeptLabel);
	    

        GetLecture  getLecture  = new GetLecture ();
        List<List<String>> Lectures = getLecture.GetLecture();
        
        Map<String, String> LectureMap = new HashMap<>();
        Map<String, String> LectureNumMap = new HashMap<>();

        int what = 0;
        for (List<String> Lecture : Lectures) {
            String lecture_id = Lecture.get(1);
            String lecture_name = Lecture.get(4);
            LectureMap.put(lecture_id, lecture_name);
            
            String xText = Integer.toString(what);
            LectureNumMap.put(lecture_id, xText);
            what = what+1;
            }


        
        //로그인 유저의 강의정보 가져오기
        String userID = userIDD; 
        String sectionID = Section;
        String encodedUserID = null;
        String encodedSectionID = null;
        
        try {
            encodedUserID = URLEncoder.encode(userID, StandardCharsets.UTF_8.toString());
            encodedSectionID = URLEncoder.encode(sectionID, StandardCharsets.UTF_8.toString());
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        String url = "/get_all_User2_Lecture?UserID=" + encodedUserID + "&section_id=" + encodedSectionID;
	    GetUserLecture  getUserLecture  = new GetUserLecture ();
        List<List<String>> UserLectures = getUserLecture.GetUserLecture(url);
        

	    // 패널 생성
	    JPanel panel_1 = new JPanel();
	    panel_1.setBackground(colors.Ground);
	    int hight = 458;
	    if (Lectures.size() > 10) {
	        hight = 50 + 42 * UserLectures.size();
	    }
	    panel_1.setBounds(24, 90, 530, hight);
	    dialogPanel.add(panel_1);
	    panel_1.setLayout(null);
	    panel_1.setBorder(borderWhite); // 테두리 설정
	    RoundedBorder roundedBorder = new RoundedBorder(20);
	    panel_1.setPreferredSize(new Dimension(480, hight));
	    
        int COUNT = 0;
        


        for (int a = 0; a < Lectures.size(); a++) {
        	
        }

        for (int a = UserLectures.size() - 1; a >= 0; a--) {
            List<String> UserLecture = UserLectures.get(a);

            String UserLecture_id = UserLecture.get(0);
            String UserID = UserLecture.get(1);
            String UserSection_id = UserLecture.get(2);
            String credits_grade = UserLecture.get(3);
            
            String SectionInfo ;
	        String whatSection = UserSection_id.substring(4, UserSection_id.length() - 0);
	        String[] thisSection = {null};
	        if (whatSection.equals("1")) {
	        	thisSection[0] = "1학기";
	        } else if (whatSection.equals("2")) {
	        	thisSection[0] = "여름학기";
	        } else if (whatSection.equals("3")) {
	        	thisSection[0] = "2학기";
	        } else if (whatSection.equals("4")) {
	        	thisSection[0] = "겨울학기";
	        }
	        SectionInfo = UserSection_id.substring(0, UserSection_id.length() - 1) + "년 " + thisSection[0];
        
            
            String SearchLecturename = LectureMap.get(UserLecture_id);

            if (UserID.equals(userIDD)) {
                // 게시물 페널
                JPanel Lecturepanel = new JPanel();
                Lecturepanel.setBackground(colors.Ground);
                Lecturepanel.setBounds(25, 5 + (42 * COUNT), 474, 40);
                panel_1.add(Lecturepanel);
                Lecturepanel.setLayout(null);
                Lecturepanel.setBorder(borderBlack); // 테두리 설정
                Lecturepanel.setBorder(roundedBorder);


                // 수강학기 버튼
                JButton Sectionbutton = new JButton(SectionInfo);
                Sectionbutton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                    	//LectureInfo lectureInfo = new LectureInfo(userIDD, B);
                    }
                });
                Sectionbutton.setBorder(borderWhite);
                Sectionbutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
                Sectionbutton.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
                Sectionbutton.setBounds(5, 5, 135, 30);
                Font contentFont = new Font(Sectionbutton.getFont().getName(), Font.BOLD, 14);
                Sectionbutton.setFont(contentFont);
                Lecturepanel.add(Sectionbutton);
                
    	        String WhatDept = UserLecture_id.substring(0, UserLecture_id.length() - 5);

                // 강의이름 버튼
                JButton LectureNamebutton = new JButton(SearchLecturename);
                LectureNamebutton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                    	int B = 0;
                        String lecture_id = null;
                        String lecture_id2 = null;
                        int what ;
                        for (what = 0 ; what < Lectures.size() ;what++) {
                        	List<String> Lecture = Lectures.get(what);
            	            lecture_id = Lecture.get(1);
	                            if(what>0) {	                            	
	                	            List<String> Lecture2 = Lectures.get(what-1);
	                	            lecture_id2 = Lecture2.get(1);
	                            } 
                	            if (UserLecture_id.equals(lecture_id)) {
                	            	B = what;
                	            	break;
                	            }
                            }
                        
        	            if(UserLecture_id.equals(lecture_id2)) {
        	            	B=B-1;

        	            	System.out.println("조정: "+B);
        	            }
                    	LectureInfo lectureInfo = new LectureInfo(userIDD, Section, B, DarK, "리스트");
                    }
                });
                LectureNamebutton.setBorder(borderWhite);
                LectureNamebutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
                if(WhatDept.equals("1")) {
                	LectureNamebutton.setForeground(colors.Text); // 텍스트 색상(흰색)
                } else {
                	LectureNamebutton.setForeground(new Color(150, 150, 150)); // 텍스트 색상(흰색)
                }
                LectureNamebutton.setBounds(140, 5, 205, 30);
                LectureNamebutton.setFont(contentFont);
                Lecturepanel.add(LectureNamebutton);

                //String[] Grade = new String[11]; // Note: Size should be 11 to hold all values


                String[] Grade = {credits_grade, "A+", "A", "B+", "B", "C+", "C", "D+", "D", "F", "P"};

                
                RoundedComboBox<String> GradeChoice = new RoundedComboBox<>(
                		Grade, colors.Ground, colors.Text, colors.BoardPanel);
                GradeChoice.setBounds(365, 7, 45, 25);
                Lecturepanel.add(GradeChoice);
                
                GradeChoice.addItemListener(new ItemListener() {
                    @Override
                    public void itemStateChanged(ItemEvent e) {
                        if (e.getStateChange() == ItemEvent.SELECTED) { // 선택된 상태에서만 작동
                            String Choice = GradeChoice.getSelectedItem().toString();

                            
                            data.put("table", "lecture");
                            data.put("lecture_id", UserLecture_id);
                            data.put("UserID", UserID);
                            data.put("credits_grade", Choice);

            				JSONObject change_check = po.jsonpost("/Change_User_Lecture", data);
            				boolean success = change_check.getBoolean("success"); 
            				System.out.println("학점등록 성공 여부: " + success);    
                        	
                            dialogFrame.dispose();
                            FrameManager.closeAllFrames(); // 모든 프레임 닫기
                        	UserLecture ShowuserLecture = new UserLecture(userIDD, Section, DarK); 
                        }
                    }         
                });
                
                
                JButton AddLecturebutton = new JButton("⚊");
                AddLecturebutton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                    	minusCheckDialog(SearchLecturename, UserLecture_id, userIDD);
                  	
                    }
                });
                AddLecturebutton.setBorder(borderWhite);
                AddLecturebutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
                AddLecturebutton.setForeground(new Color(230, 50, 50)); // 텍스트 색상(흰색)
                AddLecturebutton.setBounds(435, 4, 30, 30);
                AddLecturebutton.setFont(contentFont);
                Lecturepanel.add(AddLecturebutton);
                
                COUNT++;
            }
        }
        // 스크롤바 추가
        JScrollPane scrollPane = new JScrollPane(panel_1);
        scrollPane.setBounds(0, 90, 625, 458); // JScrollPane의 위치 및 크기 설정
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        // 가로 스크롤바를 비활성화합니다.
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        // 세로 스크롤바의 UI 변경
        scrollPane.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = new Color(100, 100, 100); // 스크롤바 색상 설정
            }

            @Override
            protected JButton createDecreaseButton(int orientation) {
                return new JButton() {
                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension(0, 0); // 위 버튼 크기 0으로 설정하여 숨김
                    }
                };
            }

            @Override
            protected JButton createIncreaseButton(int orientation) {
                return new JButton() {
                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension(0, 0); // 아래 버튼 크기 0으로 설정하여 숨김
                    }
                };
            }

            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // 둥근 모양의 스크롤바
                g2.setColor(Color.LIGHT_GRAY); // 색상 변경
                g2.fillRoundRect(thumbBounds.x, thumbBounds.y, thumbBounds.width, thumbBounds.height, 10, 10);

                g2.dispose();
            }
        });
        scrollPane.setVisible(true);

        dialogPanel.add(scrollPane);
        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
	
    private void ChangeGradeDialog(String Lecturnmae,String lecture_id, String UserID, String Grade) {
        JSONObject data = new JSONObject();
        Post po = new Post();
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(270, 400, 300, 150);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null); 

        Border borderBlue = BorderFactory.createLineBorder(new Color(155, 155, 155), 2);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 276, 110);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(new Color(255, 255, 255)); // 배경색 설정
        dialogPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255), 1)); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel dialogLabel = new JLabel(Lecturnmae + ": " +lecture_id);
        dialogLabel.setBounds(15, 23, 250, 20);
        dialogLabel.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        dialogLabel.setHorizontalAlignment(JLabel.CENTER);
        dialogPanel.add(dialogLabel);
        
        // 다이얼로그 라벨 생성
        JLabel dialog2Label = new JLabel("취득학점: ");
        dialog2Label.setBounds(85, 43, 60, 20);
        dialog2Label.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        dialogPanel.add(dialog2Label);
        
        // 검색창 박스
        RoundtextField textField = new RoundtextField(); // 텍스트 필드 생성
        textField.setBounds(150, 42, 30, 26); // 텍스트 필드 위치 및 크기 설정
        textField.setBackground(new Color(220, 220, 220)); // 배경색 설정
        textField.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        dialogPanel.add(textField); // 패널에 텍스트 필드 추가
        textField.setColumns(10); // 텍스트 필드 컬럼 수 설정
        textField.setBorder(borderBlue); // 테두리 설정
        textField.setDefaultText(Grade); // 기본 텍스트 설정
        
	            
                
        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("입력");
        confirmButton.setBounds(110, 80, 65, 20);
        confirmButton.setBackground(new Color(230, 30, 30));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String SearchTextField = textField.getText();

                data.put("table", "lecture");
                data.put("lecture_id", lecture_id);
                data.put("UserID", UserID);
                data.put("credits_grade", SearchTextField);

				JSONObject change_check = po.jsonpost("/Change_User_Lecture", data);
				boolean success = change_check.getBoolean("success"); 
				System.out.println("학점등록 성공 여부: " + success);
            	
            	
            	
                dialogFrame.dispose();
                FrameManager.closeAllFrames(); // 모든 프레임 닫기
            	UserLecture ShowuserLecture = new UserLecture(userIDD, Section, DarK); 
            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
    
    //삭제 확인
    private void minusCheckDialog(String Lecturnmae,String lecture_id, String UserID) {
        JSONObject data = new JSONObject();
        Post po = new Post();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(31, 31, 31);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(70, 70, 70);
            colors.buttonBackground = new Color(50, 50, 50);
            colors.postbuttonColor = new Color(40, 40, 40);
            colors.RedText = new Color(200, 100, 100);
        }
        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);

        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(270, 400, 300, 150);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null); 

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 276, 110);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(borderWhite); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel dialogLabel = new JLabel(Lecturnmae + ": " +lecture_id);
        dialogLabel.setBounds(15, 23, 250, 20);
        dialogLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
        dialogLabel.setHorizontalAlignment(JLabel.CENTER);
        dialogPanel.add(dialogLabel);
        
        // 다이얼로그 라벨 생성
        JLabel dialog2Label = new JLabel("강의를 삭제 하시겠습니까?");
        dialog2Label.setBounds(15, 43, 250, 20);
        dialog2Label.setForeground(colors.Text); // 텍스트 색상(흰색)
        dialog2Label.setHorizontalAlignment(JLabel.CENTER);
        dialogPanel.add(dialog2Label);
        
        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("삭제");
        confirmButton.setBounds(110, 80, 65, 20);
        confirmButton.setBackground(new Color(230, 30, 30));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                data.put("table", "lecture");
                data.put("lecture_id", lecture_id);
                data.put("UserID", UserID);
				JSONObject change_check = po.jsonpost("/delete2_column", data);
				boolean success = change_check.getBoolean("success"); 
				System.out.println("강의삭제 성공 여부: " + success);
            	
            	
            	
                dialogFrame.dispose();
                FrameManager.closeAllFrames(); // 모든 프레임 닫기
            	UserLecture ShowuserLecture = new UserLecture(userIDD, Section, DarK); 
            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
}
