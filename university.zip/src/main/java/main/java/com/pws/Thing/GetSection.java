package main.java.com.pws.Thing;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GetSection {

    public List<List<String>> GetSection() {
        HttpURLConnection connection = null;
        List<List<String>> Sections = new ArrayList<>();

        try {
            String apiURL = "http://127.0.0.1:5000/get_all_Section";
            URL url = new URL(apiURL);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");

            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"))) {
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    String returnMsg = response.toString();
                    System.out.println("서버 응답: " + returnMsg); // 서버 응답 출력

                    if (!returnMsg.trim().isEmpty()) {
                        JSONObject jsonResponse = new JSONObject(returnMsg);
                        JSONArray SectionsArray = jsonResponse.getJSONArray("Sections");

                        for (int i = 0; i < SectionsArray.length(); i++) {
                            JSONObject section = SectionsArray.getJSONObject(i);
                            List<String> SectioneData = new ArrayList<>();
                            SectioneData.add(section.getString("section_id"));
                            SectioneData.add(section.getString("start_section"));
                            SectioneData.add(section.getString("end_section"));
                            Sections.add(SectioneData);
                        }
                    } else {
                        System.out.println("서버 응답이 비어있습니다.");
                    }
                }
            } else {
                System.out.println("HTTP 응답 코드: " + responseCode);
            }

        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }

        return Sections;
    }
}
