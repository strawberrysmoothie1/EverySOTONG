package main.java.com.pws.dialog;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicScrollBarUI;

import org.json.JSONObject;

import main.java.com.pws.Thing.FrameManager;
import main.java.com.pws.Thing.GetClass_rooms;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundedBorder;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.TodayDate;
import main.java.com.pws.Thing.collor;

public class Class_RoomList{
	private String userIDD;
    private int DarK;

    public Class_RoomList(String userIDD, int DarK) {
        this.userIDD = userIDD;
        this.DarK = DarK;

        initialize();
    }

    private void initialize() {
	    JSONObject data = new JSONObject();
	    TodayDate todayDate = new TodayDate();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }

	
        Border borderBlue = BorderFactory.createLineBorder(new Color(155, 155, 155), 2);
        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        Border borderBlack = BorderFactory.createLineBorder(colors.BoardPanel, 1);
	
	    // 다이얼로그 프레임 생성
	    JFrame dialogFrame = new JFrame();
	    dialogFrame.setBounds(150, 240, 550, 570);
	    dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	    dialogFrame.getContentPane().setLayout(null);
	
    	FrameManager.addFrame(dialogFrame);

	    // 다이얼로그 패널 생성
	    JPanel dialogPanel = new JPanel();
	    dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
	    dialogPanel.setBounds(5, 0, 526, 528);
	    dialogPanel.setLayout(null);
	    dialogPanel.setBackground(colors.Ground); // 배경색 설정
	    dialogPanel.setBorder(borderWhite); // 테두리 설정
	    dialogFrame.getContentPane().add(dialogPanel);
	
	    // 다이얼로그 라벨 생성
	    JLabel MyPostLabel = new JLabel("강의실 목록");
	    MyPostLabel.setBounds(214, 25, 200, 20);
	    MyPostLabel.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
	    Font MyPostFont = new Font(MyPostLabel.getFont().getName(), Font.BOLD, 20);
	    MyPostLabel.setFont(MyPostFont);
	    dialogPanel.add(MyPostLabel);
	    
	    
	    JLabel ShowIDLabel = new JLabel("아이디");
	    ShowIDLabel.setBounds(85, 110, 100, 20);
	    ShowIDLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
	    Font ShowInfoFont = new Font(ShowIDLabel.getFont().getName(), Font.BOLD, 15);
	    ShowIDLabel.setFont(ShowInfoFont);
	    dialogPanel.add(ShowIDLabel);
	    
	    JLabel ShowNameLabel = new JLabel("건물");
	    ShowNameLabel.setBounds(246, 110, 100, 20);
	    ShowNameLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
	    ShowNameLabel.setFont(ShowInfoFont);
	    dialogPanel.add(ShowNameLabel);
	    
	    JLabel ShowDeptLabel = new JLabel("강의실");
	    ShowDeptLabel.setBounds(397, 110, 100, 20);
	    ShowDeptLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
	    ShowDeptLabel.setFont(ShowInfoFont);
	    dialogPanel.add(ShowDeptLabel);
	    
        RoundedButton AddInstructorbutton = new RoundedButton("강의실 추가");
        AddInstructorbutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	AddClass_Room ShowAddClass_Room = new AddClass_Room(userIDD, DarK);
            }
        });
        AddInstructorbutton.setBackground(new Color(200, 100, 150));// 배경색 설정 (빨간색)
        AddInstructorbutton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        AddInstructorbutton.setBounds(440, 15, 70, 20);
        dialogPanel.add(AddInstructorbutton);


        GetClass_rooms  getClass_rooms  = new GetClass_rooms ();
        List<List<String>> Class_rooms = getClass_rooms.GetClass_rooms();

	    // 패널 생성
	    JPanel panel_1 = new JPanel();
	    panel_1.setBackground(colors.Ground);
	    int hight = 408;
	    if (Class_rooms.size() > 9) {
	        hight = 5 + 42 * Class_rooms.size();
	    }
	    panel_1.setBounds(24, 140, 480, hight);
	    dialogPanel.add(panel_1);
	    panel_1.setLayout(null);
	    panel_1.setBorder(borderWhite); // 테두리 설정
	    RoundedBorder roundedBorder = new RoundedBorder(20);
	    panel_1.setPreferredSize(new Dimension(480, hight));
	    
	    
	    data.put("table", "users");
	    data.put("want", "UID");
	    data.put("what", "UserID");
	    data.put("user_id", userIDD);
	    Post po = new Post();
		JSONObject SearchNickname1 = po.jsonpost("/find_user_information", data);
		String AdminUID = SearchNickname1.getString("UID");
        String SchoolID = AdminUID.substring(0, AdminUID.length() - 2);

		
	    int COUNT = 0;
	    int aa = Class_rooms.size() -1 ;
	    for (int a = 1; a <= Class_rooms.size(); a++) {
	    	List<String> Class_room = Class_rooms.get(aa);
	
	        String room_id = Class_room.get(0);
	        String building = Class_room.get(1);
	        String room_number = Class_room.get(2);

	
	        String UserSchoolID = room_id.substring(0, room_id.length() - 3);
	        aa--;

        if (UserSchoolID.equals(SchoolID)) {
        	
            // 게시물 페널
            JPanel Postpanel = new JPanel();
            Postpanel.setBackground(colors.Ground);
            Postpanel.setBounds(25, 5 + (42 * COUNT), 474, 40);
            panel_1.add(Postpanel);
            Postpanel.setLayout(null);
            Postpanel.setBorder(borderBlack); // 테두리 설정
            Postpanel.setBorder(roundedBorder);


            // 아이디 버튼
            JButton RoomIDbutton = new JButton(room_id);
            RoomIDbutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	Class_RoomInfo class_RoomInfo = new Class_RoomInfo(userIDD, room_id, DarK);
                    dialogFrame.dispose();
                }
            });
            RoomIDbutton.setBorder(borderWhite);
            RoomIDbutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
            RoomIDbutton.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
            RoomIDbutton.setBounds(5, 5, 155, 30);
            Font contentFont = new Font(RoomIDbutton.getFont().getName(), Font.BOLD, 14);
            RoomIDbutton.setFont(contentFont);
            RoomIDbutton.setContentAreaFilled(false);
            RoomIDbutton.setFocusPainted(false);
            RoomIDbutton.setOpaque(true);
            Postpanel.add(RoomIDbutton);
            
            // 건물 버튼
            JButton Buildingbutton = new JButton(building);
            Buildingbutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	Class_RoomInfo class_RoomInfo = new Class_RoomInfo(userIDD, room_id, DarK);
                    dialogFrame.dispose();
                }
            });
            Buildingbutton.setBorder(borderWhite);
            Buildingbutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
            Buildingbutton.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
            Buildingbutton.setBounds(160, 5, 155, 30);
            Buildingbutton.setFont(contentFont);
            Buildingbutton.setContentAreaFilled(false);
            Buildingbutton.setFocusPainted(false);
            Buildingbutton.setOpaque(true);
            Postpanel.add(Buildingbutton);

            // 닉네임 버튼
            JButton Numberbutton = new JButton(room_number);
            Numberbutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	Class_RoomInfo class_RoomInfo = new Class_RoomInfo(userIDD, room_id, DarK);
                    dialogFrame.dispose();
                }
            });
            Numberbutton.setBorder(borderWhite);
            Numberbutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
            Numberbutton.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
            Numberbutton.setBounds(315, 5, 155, 30);
            Numberbutton.setFont(contentFont);
            Numberbutton.setContentAreaFilled(false);
            Numberbutton.setFocusPainted(false);
            Numberbutton.setOpaque(true);
            Postpanel.add(Numberbutton);


            
            COUNT++;
            }
    	}
        // 스크롤바 추가
        JScrollPane scrollPane = new JScrollPane(panel_1);
        scrollPane.setBounds(0, 140, 625, 408); // JScrollPane의 위치 및 크기 설정
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        // 가로 스크롤바를 비활성화합니다.
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        // 세로 스크롤바의 UI 변경
        scrollPane.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = new Color(100, 100, 100); // 스크롤바 색상 설정
            }

            @Override
            protected JButton createDecreaseButton(int orientation) {
                return new JButton() {
                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension(0, 0); // 위 버튼 크기 0으로 설정하여 숨김
                    }
                };
            }

            @Override
            protected JButton createIncreaseButton(int orientation) {
                return new JButton() {
                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension(0, 0); // 아래 버튼 크기 0으로 설정하여 숨김
                    }
                };
            }

            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // 둥근 모양의 스크롤바
                g2.setColor(Color.LIGHT_GRAY); // 색상 변경
                g2.fillRoundRect(thumbBounds.x, thumbBounds.y, thumbBounds.width, thumbBounds.height, 10, 10);

                g2.dispose();
            }
        });
        scrollPane.setVisible(true);

        dialogPanel.add(scrollPane);
        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
	
}
