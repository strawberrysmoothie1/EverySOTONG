package main.java.com.pws.Board;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.RenderingHints;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicScrollBarUI;

import org.json.JSONObject;

import main.java.com.pws.User.mypage;
import main.java.com.pws.Login.login;
import main.java.com.pws.Schedule.schedule;
import main.java.com.pws.Thing.GetSearch;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundedBorder;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.TodayDate;
import main.java.com.pws.Thing.collor;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class searchclass {
	private String userIDD;
	private String Search;
	private String Section;
	private int DarK;
	private int Ground;
	private int Text;
	
    JFrame frame;

    /**
     * 어플리케이션 실행 메소드
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    login window = new login();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * 어플리케이션 생성자
     */
    public searchclass(String userIDD, String Search, String Section, int DarK) {
        this.userIDD = userIDD;
        this.Search = Search;
        this.Section = Section;
        this.DarK = DarK;

        initialize();
    }

    /**
     * 프레임 내용 초기화 메소드
     */
    private void initialize() {
    	JSONObject data = new JSONObject();
        TodayDate todayDate = new TodayDate();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }


        frame = new JFrame();
        frame.setBounds(100, 100, 650, 800); // 프레임 위치 및 크기 설정
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // 닫기 버튼 동작 설정
        frame.getContentPane().setLayout(null); // 레이아웃 설정 (null은 절대 위치 배치)

        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        Border borderBlack = BorderFactory.createLineBorder(new Color(0, 0, 0), 1);
        JPanel panel = new JPanel();
        panel.setBounds(5, 0, 625, 755);
        frame.getContentPane().add(panel);
        panel.setLayout(null);
        panel.setBackground(colors.Ground); // 배경색 설정

        // 에브리소통 그림2
        String everyTimeIMG = "src/img/everygood.png";
        if(DarK == 1) {
        	everyTimeIMG = "src/img/everygoodDark.png";
        }
        ImageIcon everyImageIcon = new ImageIcon(everyTimeIMG);
        Image everyImage = everyImageIcon.getImage();
        Image every1Image = everyImage.getScaledInstance(120, 30, Image.SCALE_SMOOTH);
        ImageIcon every1ImageIcon = new ImageIcon(every1Image);
        JButton image1Button = new JButton(every1ImageIcon);
        image1Button.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        image1Button.setBounds(30, 40, 120, 30);
        image1Button.setBorder(borderWhite);
        image1Button.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                boardclass b = new boardclass(userIDD, Section, DarK);
                b.showFrame();
                frame.dispose();
            }
        });
        panel.add(image1Button);

        // 게시판 버튼
        JButton btnClickMe = new JButton("게시판"); // 버튼 생성 및 텍스트 설정
        btnClickMe.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                boardclass b = new boardclass(userIDD, Section, DarK); 
                b.showFrame();
                frame.dispose();
            }
        });
        btnClickMe.setBounds(210, 32, 100, 45); // 버튼 위치 및 크기 설정
        btnClickMe.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        btnClickMe.setForeground(colors.Text); // 텍스트 색상(흰색)
        panel.add(btnClickMe); // 패널에 버튼 추가
        Font buttonFont = new Font(btnClickMe.getFont().getName(), Font.BOLD, 18);
        btnClickMe.setFont(buttonFont);
        btnClickMe.setContentAreaFilled(false);
        btnClickMe.setFocusPainted(false);
        btnClickMe.setOpaque(true);
        btnClickMe.setBorder(borderWhite); // 테두리 설정

        // 시간표 버튼
        JButton Schedule = new JButton("시간표"); // 버튼 생성 및 텍스트 설정
        Schedule.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                schedule a = new schedule(userIDD, Section, DarK); 
                a.showFrame();
                frame.dispose();
            }
        });
        Schedule.setBounds(320, 32, 100, 45); // 버튼 위치 및 크기 설정
        Schedule.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        Schedule.setForeground(colors.Text); // 텍스트 색상(흰색)
        panel.add(Schedule); // 패널에 버튼 추가
        Font ScheduleFont = new Font(Schedule.getFont().getName(), Font.PLAIN, 18);
        Schedule.setFont(ScheduleFont);
        Schedule.setContentAreaFilled(false);
        Schedule.setFocusPainted(false);
        Schedule.setOpaque(true);
        Schedule.setBorder(borderWhite); // 테두리 설정

        // 회원 버튼
        JButton member = new JButton("설정"); // 버튼 생성 및 텍스트 설정
        member.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                mypage my = new mypage(userIDD, Section, DarK);
                my.showFrame();
                frame.dispose();
            }
        });
        member.setBounds(530, 30, 70, 30); // 버튼 위치 및 크기 설정
        member.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        member.setForeground(colors.Text); // 텍스트 색상(흰색)
        panel.add(member); // 패널에 버튼 추가
        Font memberbuttonFont = new Font(member.getFont().getName(), Font.BOLD, 12);
        member.setFont(memberbuttonFont);
        member.setContentAreaFilled(false);
        member.setFocusPainted(false);
        member.setOpaque(true);
        member.setBorder(borderWhite); // 테두리 설정

        Font contentFont = new Font(member.getFont().getName(), Font.BOLD, 10);

        // 검색 라벨
        JLabel SearchLabel = new JLabel("검색 결과");
        SearchLabel.setBounds(262, 95, 150, 30); // Adjust the position and size as needed
        SearchLabel.setForeground(new Color(100, 100, 100)); // Set label text color
        Font labelFont2 = new Font(SearchLabel.getFont().getName(), Font.BOLD, 22);
        SearchLabel.setFont(labelFont2);
        panel.add(SearchLabel);

        Font TimeFont = new Font(SearchLabel.getFont().getName(), Font.BOLD, 8);

        data.put("table", "users");
        data.put("want", "UID");
        data.put("what", "UserID");
        data.put("user_id", userIDD);
        Post po = new Post();
    	JSONObject UserUID1 = po.jsonpost("/find_user_information", data);
    	String UserUID = UserUID1.getString("UID");
        
        String cutUserUIDD = UserUID.substring(0, UserUID.length() - 2);

        data.put("keyword", Search);
        GetSearch getSearch = new GetSearch();
        List<List<String>> bulletins = getSearch.searchBulletins(data);


        // 패널 생성
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(colors.Ground);
        int hight = 615;
        if (bulletins.size() > 9) {
            hight = 5 + 62 * bulletins.size();
        }
        panel_1.setBounds(73, 140, 480, hight);
        panel.add(panel_1);
        panel_1.setLayout(null);
        panel_1.setBorder(borderWhite); // 테두리 설정
        RoundedBorder roundedBorder = new RoundedBorder(20);
        panel_1.setPreferredSize(new Dimension(480, hight));

        int COUNT = 0;

        for (int i = 0; i < bulletins.size(); i++) {
        	List<String> bulletin = bulletins.get(i);
            String ShowTitle = null;
            String ShowContent = null;
            String ShowNicname = null;

            String BulletinID = bulletin.get(0);
            String SearchTitle = bulletin.get(4);
            String SearchContent = bulletin.get(5);           
            String SearchBdate1 = bulletin.get(6);
            long SearchBdate = Long.valueOf(SearchBdate1);
            String SearchUser = bulletin.get(1);
            String bulletinUIDD = bulletin.get(2);
            
            data.put("table", "users");
            data.put("want", "Nickname");
            data.put("what", "UserID");
            data.put("user_id", SearchUser);
        	JSONObject SearchNickname1 = po.jsonpost("/find_user_information", data);
        	String SearchNickname = SearchNickname1.getString("Nickname");
        	
            String cutUIDD = bulletinUIDD.substring(0, bulletinUIDD.length() - 2);

            if (cutUserUIDD.equals(cutUIDD)) { // 학교구별
                // 게시물 페널
                JPanel Postpanel = new JPanel();
                Postpanel.setBackground(colors.Ground);
                Postpanel.setBounds(73, 5 + (62 * COUNT), 474, 60);
                panel_1.add(Postpanel);
                Postpanel.setLayout(null);
                Postpanel.setBorder(borderBlack); // 테두리 설정
                Postpanel.setBorder(roundedBorder);

                // 변수 설정
                ShowNicname = SearchNickname;
                ShowTitle = SearchTitle;
                ShowContent = SearchContent;

                long NewDateTime = todayDate.TodayDate();
                long newMinte = NewDateTime % 100;
                long searchMinte = SearchBdate % 100;
                long minute = 0;
                minute = newMinte - searchMinte;
                if (minute < 0) {
                    minute = 60 + minute;
                }
                long newHour = (NewDateTime % 10000) / 100;
                long searchHour = (SearchBdate % 10000) / 100;
                long hour = 0;
                hour = newHour - searchHour;
                if (hour < 0) {
                    hour = 24 + hour;
                }
                long newDay = (NewDateTime % 1000000) / 10000;
                long searchDay = (SearchBdate % 1000000) / 10000;
                long day = 0;
                day = newDay - searchDay;

                long newmonth = (NewDateTime % 100000000) / 1000000;
                long searchmonth = (SearchBdate % 100000000) / 1000000;
                long month = 0;
                month = newmonth - searchmonth;

                long newyear = NewDateTime / 100000000;
                long searchyear = SearchBdate / 100000000;
                long year = 0;
                year = newyear - searchyear;

                String dayLabel = null;
                if (year > 0) {
                    dayLabel = searchyear + " " + searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (month > 0) {
                    dayLabel = searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (day > 0) {
                    dayLabel = searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (day == 0 && hour > 0) {
                    dayLabel = hour + "시간" + minute + "분 전";
                } else {
                    dayLabel = minute + "분 전";
                }

                // 시간 라벨
                JLabel TimeLabel = new JLabel(dayLabel);
                TimeLabel.setBounds(10, 38, 200, 15); // Adjust the position and size as needed
                TimeLabel.setForeground(new Color(100, 100, 100)); // Set label text color
                TimeLabel.setFont(TimeFont);
                Postpanel.add(TimeLabel);

                // 제목 버튼
                JButton postbutton = new JButton(ShowTitle);
                postbutton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        showPost b = new showPost(userIDD, SearchUser, BulletinID, "일반", Section, DarK);
                        b.showFrame();
                        frame.dispose();
                    }
                });
                postbutton.setHorizontalAlignment(SwingConstants.LEFT);
                postbutton.setBorder(borderWhite);
                postbutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
                postbutton.setForeground(colors.Text); // 텍스트 색상(흰색)
                postbutton.setBounds(6, 2, 410, 20);
                postbutton.setFont(memberbuttonFont);
                postbutton.setContentAreaFilled(false);
                postbutton.setFocusPainted(false);
                postbutton.setOpaque(true);
                Postpanel.add(postbutton);
                // 내용 버튼
                JButton contentbutton = new JButton(ShowContent);
                contentbutton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        showPost b = new showPost(userIDD, SearchUser, BulletinID, "일반", Section, DarK);
                        b.showFrame();
                        frame.dispose();
                    }
                });
                contentbutton.setHorizontalAlignment(SwingConstants.LEFT);
                contentbutton.setBorder(borderWhite);
                contentbutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
                contentbutton.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
                contentbutton.setBounds(7, 22, 420, 15);
                contentbutton.setFont(contentFont);
                contentbutton.setContentAreaFilled(false);
                contentbutton.setFocusPainted(false);
                contentbutton.setOpaque(true);
                Postpanel.add(contentbutton);

                // 닉네임
                JButton Nicknamebutton = new JButton(ShowNicname);
                Nicknamebutton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        userDialog(SearchUser);
                    }
                });
                Nicknamebutton.setBorder(borderWhite);
                Nicknamebutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
                Nicknamebutton.setForeground(new Color(80, 80, 80)); // 텍스트 색상(흰색)
                Nicknamebutton.setBounds(420, 8, 50, 15);
                Nicknamebutton.setFont(contentFont);
                Nicknamebutton.setContentAreaFilled(false);
                Nicknamebutton.setFocusPainted(false);
                Nicknamebutton.setOpaque(true);
                Postpanel.add(Nicknamebutton);

                COUNT++;
            }
        }
        if (COUNT == 0) {
            // 검색결과
            ImageIcon nonesearchIcon = new ImageIcon("src/img/noneSearch.png");
            Image noneSearchImage = nonesearchIcon.getImage();
            Image noneSearch1Image = noneSearchImage.getScaledInstance(170, 130, Image.SCALE_SMOOTH);
            ImageIcon noneSearch1Icon = new ImageIcon(noneSearch1Image);
            JButton noneSearchButton = new JButton(noneSearch1Icon);
            noneSearchButton.setBackground(new Color(255, 255, 255));// 배경색 설정 (빨간색)
            noneSearchButton.setBounds(220, 95, 170, 130);
            noneSearchButton.setBorder(BorderFactory.createLineBorder(Color.WHITE));
            noneSearchButton.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
                public void actionPerformed(ActionEvent e) {
                    boardclass b = new boardclass(userIDD, Section, DarK);
                    b.showFrame();
                    frame.dispose();
                }
            });
            noneSearchButton.setContentAreaFilled(false);
            noneSearchButton.setFocusPainted(false);
            noneSearchButton.setOpaque(true);
            panel_1.add(noneSearchButton);

        }

        // 스크롤바 추가
        JScrollPane scrollPane = new JScrollPane(panel_1);
        scrollPane.setBounds(0, 140, 625, 617); // JScrollPane의 위치 및 크기 설정
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        // 가로 스크롤바를 비활성화합니다.
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        // 세로 스크롤바의 UI 변경
        scrollPane.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = new Color(100, 100, 100); // 스크롤바 색상 설정
            }

            @Override
            protected JButton createDecreaseButton(int orientation) {
                return new JButton() {
                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension(0, 0); // 위 버튼 크기 0으로 설정하여 숨김
                    }
                };
            }

            @Override
            protected JButton createIncreaseButton(int orientation) {
                return new JButton() {
                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension(0, 0); // 아래 버튼 크기 0으로 설정하여 숨김
                    }
                };
            }

            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // 둥근 모양의 스크롤바
                g2.setColor(Color.LIGHT_GRAY); // 색상 변경
                g2.fillRoundRect(thumbBounds.x, thumbBounds.y, thumbBounds.width, thumbBounds.height, 10, 10);

                g2.dispose();
            }
        });
        scrollPane.setVisible(true);

        panel.add(scrollPane);

        frame.getContentPane().add(panel);

        // 다이얼로그 표시
        frame.setVisible(true);
        // frame.getContentPane().add(scrollPane);

    }


    // 작성자 정보
    private void userDialog(String user) {
    	JSONObject data = new JSONObject();

        // 테두리 스타일 설정

        Border borderWhite = BorderFactory.createLineBorder(new Color(255, 255, 255), 2);

        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(275, 350, 300, 350);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        // dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 100, 100);
        frame.getContentPane().add(dialogPanel);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(new Color(255, 255, 255)); // 배경색 설정
        dialogFrame.add(dialogPanel);

        // 작성자 정보 라벨
        JLabel ChangePWLabel = new JLabel("작성자 정보");
        ChangePWLabel.setBounds(105, 11, 150, 30); // Adjust the position and size as needed
        ChangePWLabel.setForeground(new Color(100, 100, 100)); // Set label text color
        Font ChangePWFont = new Font(ChangePWLabel.getFont().getName(), Font.BOLD, 14);
        ChangePWLabel.setFont(ChangePWFont);
        dialogPanel.add(ChangePWLabel);

        // 취소 버튼
        JButton BackButton = new JButton("취소"); // 버튼 생성 및 텍스트 설정
        BackButton.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                dialogFrame.dispose();
            }
        });
        BackButton.setBounds(275, 10, 60, 20); // 버튼 위치 및 크기 설정
        BackButton.setBackground(new Color(255, 255, 255));// 배경색 설정
        BackButton.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        dialogPanel.add(BackButton); // 패널에 버튼 추가
        Font memberbuttonFont = new Font(BackButton.getFont().getName(), Font.BOLD, 11);
        BackButton.setFont(memberbuttonFont);
        BackButton.setBorder(borderWhite); // 테두리 설정
        BackButton.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        BackButton.setContentAreaFilled(false);
        BackButton.setFocusPainted(false);
        BackButton.setOpaque(true);

        data.put("table", "users");
        data.put("want", "Nickname");
        data.put("what", "UserID");
        data.put("user_id", user);
        Post po = new Post();
    	JSONObject SearchNickname1 = po.jsonpost("/find_user_information", data);
    	String SearchNickname = SearchNickname1.getString("Nickname");
        
        data.put("table", "users");
        data.put("want", "UID");
        data.put("what", "UserID");
        data.put("user_id", user);
    	JSONObject SearchSchoolcode1 = po.jsonpost("/find_user_information", data);
    	String SearchSchoolcode = SearchSchoolcode1.getString("UID");
        
        data.put("table", "university");
        data.put("want", "UName");
        data.put("what", "UID");
        data.put("user_id", SearchSchoolcode);
    	JSONObject SearchSchoolname1 = po.jsonpost("/find_user_information", data);
    	String SearchSchoolname = SearchSchoolname1.getString("UName");
               
        data.put("table", "university");
        data.put("want", "department");
        data.put("what", "UID");
        data.put("user_id", SearchSchoolcode);
    	JSONObject Searchdepartment1 = po.jsonpost("/find_user_information", data);
    	String Searchdepartment = Searchdepartment1.getString("department");
        
        // 이미지 유저
        ImageIcon useroriginalImageIcon = new ImageIcon("src/img/user.png");
        Image useroriginalImage = useroriginalImageIcon.getImage();
        Image userscaledImage = useroriginalImage.getScaledInstance(60, 60, Image.SCALE_SMOOTH);
        ImageIcon userscaledImageIcon = new ImageIcon(userscaledImage);
        JLabel userimageLabel = new JLabel(userscaledImageIcon);
        userimageLabel.setBounds(110, 70, 60, 60);
        dialogPanel.add(userimageLabel);

        JLabel Nickname = new JLabel("닉네임: " + SearchNickname);
        Nickname.setBounds(94, 150, 150, 20); // Adjust the position and size as needed
        Nickname.setForeground(new Color(0, 0, 0)); // Set label text color
        Font labelFont4 = new Font(Nickname.getFont().getName(), Font.BOLD, 14);
        Nickname.setFont(labelFont4);
        dialogPanel.add(Nickname);

        JLabel Schoolname = new JLabel("학교: " + SearchSchoolname);
        Schoolname.setBounds(94, 170, 150, 20); // Adjust the position and size as needed
        Schoolname.setForeground(new Color(100, 100, 100)); // Set label text color
        Font labelFont5 = new Font(Schoolname.getFont().getName(), Font.BOLD, 11);
        Schoolname.setFont(labelFont5);
        dialogPanel.add(Schoolname);

        JLabel department = new JLabel("학과: " + Searchdepartment);
        department.setBounds(94, 190, 150, 20); // Adjust the position and size as needed
        department.setForeground(new Color(100, 100, 100)); // Set label text color
        department.setFont(labelFont5);
        dialogPanel.add(department);

        // 확인 버튼
        RoundedButton confirmButton = new RoundedButton("확인");
        confirmButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                dialogFrame.dispose();
            }
        });
        confirmButton.setBackground(new Color(255, 0, 0));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.setBounds(110, 250, 65, 25);
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }


    public void showFrame() {
        frame.setVisible(true);
    }

}
