package main.java.com.pws.Schedule;

import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.border.Border;

import org.json.JSONObject;

import main.java.com.pws.Board.boardclass;
import main.java.com.pws.Login.login;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.RoundedButton2;
import main.java.com.pws.Thing.RoundedComboBox;
import main.java.com.pws.Thing.RoundtextField;
import main.java.com.pws.Thing.GetLecture;
import main.java.com.pws.Thing.GetMyFriends;
import main.java.com.pws.Thing.GetSection;
import main.java.com.pws.Thing.GetUserLecture;
import main.java.com.pws.Thing.GetUsers;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundPasswordField;
import main.java.com.pws.Thing.TimetablePanel;
import main.java.com.pws.Thing.collor;
import main.java.com.pws.User.mypage;
import main.java.com.pws.dialog.Class_RoomList;
import main.java.com.pws.dialog.InstructorList;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class schedule {
	private String userIDD;
	private String Section;	
	private int DarK;
    JFrame frame;
	private String FriendID;	

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                	login window = new login();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public schedule(String userIDD, String Section, int DarK) {
        this.userIDD = userIDD;
        this.Section = Section;
        this.DarK = DarK;

        initialize();
    }

    private void initialize() {
    	JSONObject data = new JSONObject();

        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
            colors.BlackText = new Color(150, 150, 150);
        }

        frame = new JFrame();
        frame.setBounds(100, 100, 650, 800); // 프레임 위치 및 크기 설정
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // 닫기 버튼 동작 설정
        frame.getContentPane().setLayout(null); 


        Border borderBlue = BorderFactory.createLineBorder(new Color(155, 155, 155), 2);
        Border borderBlack = BorderFactory.createLineBorder(colors.BoardPanel, 1);
        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        JPanel panel = new JPanel();
        panel.setBounds(5, 0, 625, 755);
        frame.getContentPane().add(panel);
        panel.setLayout(null);
        panel.setBackground(colors.Ground); // 배경색 설정		
        
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setLayout(null);
        layeredPane.setBounds(49, 130, 538, 500);

        panel.add(layeredPane);

        //(45, 130, 538, 500);

        //시간표 이미지
        TimetablePanel timetablePanel = new TimetablePanel(colors.Ground, colors.BoardPanel, colors.BlackText);
        timetablePanel.setBounds(0, 0, 538, 500);  // 크기 및 위치 설정
        layeredPane.add(timetablePanel, JLayeredPane.DEFAULT_LAYER);

        // 에브리소통 그림2
        String everyTimeIMG = "src/img/everygood.png";
        if(DarK == 1) {
        	everyTimeIMG = "src/img/everygoodDark.png";
        }
        ImageIcon everyImageIcon = new ImageIcon(everyTimeIMG);
        Image everyImage = everyImageIcon.getImage();
        Image every1Image = everyImage.getScaledInstance(120, 30, Image.SCALE_SMOOTH);
        ImageIcon every1ImageIcon = new ImageIcon(every1Image);
        JButton image1Button = new JButton(every1ImageIcon);
        image1Button.setBackground(colors.Ground);
        image1Button.setBounds(30, 40, 120, 30);
        image1Button.setBorder(borderWhite);
        image1Button.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                boardclass b = new boardclass(userIDD, Section, DarK);
                b.showFrame();
                frame.dispose();
            }
        });
        panel.add(image1Button);
        
        // 게시판 버튼
        JButton btnClickMe = new JButton("게시판"); // 버튼 생성 및 텍스트 설정
        btnClickMe.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {

                boardclass b = new boardclass(userIDD, Section, DarK);
                b.showFrame();
                frame.dispose();
            }
        });
        btnClickMe.setBounds(210, 70, 100, 45); // 버튼 위치 및 크기 설정
        btnClickMe.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        btnClickMe.setForeground(colors.Text); // 텍스트 색상(흰색)
        panel.add(btnClickMe); // 패널에 버튼 추가
        Font buttonFont = new Font(btnClickMe.getFont().getName(), Font.PLAIN, 18);
        btnClickMe.setFont(buttonFont);
        btnClickMe.setBorder(borderWhite); // 테두리 설정
        btnClickMe.setContentAreaFilled(false);
        btnClickMe.setFocusPainted(false);
        btnClickMe.setOpaque(true);

        // 시간표 버튼
        JButton Schedule = new JButton("시간표"); // 버튼 생성 및 텍스트 설정
        Schedule.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                schedule a = new schedule(userIDD, Section, DarK);
                a.showFrame();
                frame.dispose();
            }
        });
        Schedule.setBounds(320, 70, 100, 45); // 버튼 위치 및 크기 설정
        Schedule.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        Schedule.setForeground(colors.Text); // 텍스트 색상(흰색)
        panel.add(Schedule); // 패널에 버튼 추가
        Font ScheduleFont = new Font(Schedule.getFont().getName(), Font.BOLD, 18);
        Schedule.setFont(ScheduleFont);
        Schedule.setBorder(borderWhite); // 테두리 설정
        Schedule.setContentAreaFilled(false);
        Schedule.setFocusPainted(false);
        Schedule.setOpaque(true);

        // 회원 버튼
        JButton member = new JButton("설정"); // 버튼 생성 및 텍스트 설정
        member.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                mypage my = new mypage(userIDD, Section, DarK);
                my.showFrame();
                frame.dispose();
            }
        });
        member.setBounds(520, 20, 70, 30); // 버튼 위치 및 크기 설정
        member.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        member.setForeground(colors.Text); // 텍스트 색상(흰색)
        panel.add(member); // 패널에 버튼 추가
        Font memberbuttonFont = new Font(member.getFont().getName(), Font.BOLD, 12);
        member.setFont(memberbuttonFont);
        member.setBorder(borderWhite); // 테두리 설정
        member.setContentAreaFilled(false);
        member.setFocusPainted(false);
        member.setOpaque(true);
        
        String[] SearchLectures = {"없음"};
        if (userIDD.equals("admin")){
            RoundedButton AdChangeUbutton = new RoundedButton("강의 관리");
            AdChangeUbutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	LectureList adminlecture = new LectureList(userIDD, SearchLectures, Section, "관리자", DarK);
                }
            });
            AdChangeUbutton.setBackground(new Color(200, 100, 100));// 배경색 설정 (빨간색)
            AdChangeUbutton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
            AdChangeUbutton.setBounds(500, 645, 70, 20);
            panel.add(AdChangeUbutton);
            
            RoundedButton AdUserbutton = new RoundedButton("교수 관리");
            AdUserbutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	InstructorList ShowInstructor = new InstructorList(userIDD, Section, DarK);
                }
            });
            AdUserbutton.setBackground(new Color(200, 100, 150));// 배경색 설정 (빨간색)
            AdUserbutton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
            AdUserbutton.setBounds(500, 670, 70, 20);
            panel.add(AdUserbutton);
            
            RoundedButton AdBoardbutton = new RoundedButton("건물 관리");
            AdBoardbutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	Class_RoomList Class_RoomDialog = new Class_RoomList(userIDD, DarK);
                }
            });
            AdBoardbutton.setBackground(new Color(200, 150, 100));// 배경색 설정 (빨간색)
            AdBoardbutton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
            AdBoardbutton.setBounds(500, 695, 70, 20);
            panel.add(AdBoardbutton);
        }
        
        String NewSectionID = Section.substring(4, Section.length() - 0);
        String[] thisSection1 = {null};
        if (NewSectionID.equals("1")) {
        	thisSection1[0] = "1학기";
        } else if (NewSectionID.equals("2")) {
        	thisSection1[0] = "여름학기";
        } else if (NewSectionID.equals("3")) {
        	thisSection1[0] = "2학기";
        } else if (NewSectionID.equals("4")) {
        	thisSection1[0] = "겨울학기";
        }
        String SectionShow = Section.substring(0, Section.length() - 1) + "년 " + thisSection1[0];
        
        // 학기 라벨
        JLabel SectionLabel = new JLabel(SectionShow);
        SectionLabel.setBounds(168, 40, 300, 35); // Adjust the position and size as needed
        SectionLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        Font labelFont3 = new Font(SectionLabel.getFont().getName(), Font.BOLD, 18);
        SectionLabel.setFont(labelFont3);
        SectionLabel.setHorizontalAlignment(JLabel.CENTER);
        panel.add(SectionLabel);
        
        // 학기 라벨
        JLabel ChoiseSectionLabel = new JLabel("학기 선택");
        ChoiseSectionLabel.setBounds(71, 85, 80, 15); // Adjust the position and size as needed
        ChoiseSectionLabel.setForeground(new Color(90, 90, 90)); // Set label text color
        Font labelFont2 = new Font(ChoiseSectionLabel.getFont().getName(), Font.BOLD, 12);
        ChoiseSectionLabel.setFont(labelFont2);
        panel.add(ChoiseSectionLabel);
        

        GetSection getSection = new GetSection();
        List<List<String>> Sections = getSection.GetSection();
        String[] object = new String[Sections.size()+1]; // 배열 초기화
        String[] sections = new String[Sections.size()+1]; // 배열 초기화
        object[0] = SectionShow;
        int aa = Sections.size() - 1;
        for (int a = 1; a <= Sections.size(); a++) {
            List<String> Lecture = Sections.get(aa);
            String SectionID = Lecture.get(0);
	        String whatSection = SectionID.substring(4, SectionID.length() - 0);
	        String[] thisSection = {null};
	        if (whatSection.equals("1")) {
	        	thisSection[0] = "1학기";
	        } else if (whatSection.equals("2")) {
	        	thisSection[0] = "여름학기";
	        } else if (whatSection.equals("3")) {
	        	thisSection[0] = "2학기";
	        } else if (whatSection.equals("4")) {
	        	thisSection[0] = "겨울학기";
	        }
	        sections[a] = Lecture.get(0);
            object[a] = SectionID.substring(0, SectionID.length() - 1) + "년 " + thisSection[0];
            aa--;
        }
        
        RoundedComboBox<String> SectionChoice = new RoundedComboBox<>(
        		object, colors.Ground, colors.Text, Color.GRAY);
        SectionChoice.setBounds(70, 100, 117, 20);
        panel.add(SectionChoice);

        SectionChoice.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) { // 선택된 상태에서만 작동
                    String Choice = SectionChoice.getSelectedItem().toString();
                    for (int a = 1; a <= Sections.size(); a++) {
                        if (Choice.equals(object[a])) {
                            Section = sections[a];
                            break;
                        }
                    }      
                    schedule a = new schedule(userIDD, Section, DarK);
                    a.showFrame();
                    frame.dispose();
                }
            }         
        });
        
        System.out.println("현제 학기: "+Section);

        
        data.put("what", "FriendID");
        data.put("user_id", userIDD);
        data.put("Accept", "1");

        // 해당 유저의 친구 목록을 조회
        GetMyFriends getMyFriendsAccept = new GetMyFriends();
        List<List<String>> friendsAccept = getMyFriendsAccept.getFriendsByUserID(data); // 친구 목록 조회
                
        for (int a = 0; a < friendsAccept.size(); a++) {
            List<String> friendInfo = friendsAccept.get(a); // 친구 정보 가져오기
            String getuserID = friendInfo.get(0);  // 친구 ID (인덱스 1에 있다고 가정)
            String Accept = friendInfo.get(2);  // 친구 ID (인덱스 1에 있다고 가정)
            System.out.println("친구요청상태: "+ Accept);
                

            // 일정 시간 후 다이얼로그 띄우기
            Timer timer = new Timer(500, new ActionListener() {  // 500ms 후 다이얼로그 표시
                @Override
                public void actionPerformed(ActionEvent e) {
                    FriendAeccptDialog(getuserID);  // 다이얼로그 호출
                }
            });
            timer.setRepeats(false);  // 타이머가 한 번만 실행되도록 설정
            timer.start();
        }

        
        
     // 유저 목록과 친구 목록을 조회하여 매핑하는 부분
        GetUsers getUsers = new GetUsers();
        List<List<String>> users = getUsers.getAllUsers(); // 유저 목록 조회

        Map<String, String> userMap = new HashMap<>();
        for (List<String> user : users) {
            String userID = user.get(0);  // 유저 ID
            String nickname = user.get(3); // 유저 닉네임 (인덱스 3에 닉네임이 있다고 가정)
            userMap.put(userID, nickname); // 유저ID와 닉네임을 맵에 저장
        }

        Map<String, String> FriendIDMap = new HashMap<>();
        for (List<String> user : users) {
            String userID = user.get(0);  // 유저 ID
            String nickname = user.get(3); // 유저 닉네임 (인덱스 3에 닉네임이 있다고 가정)
            FriendIDMap.put(nickname, userID); // 유저ID와 닉네임을 맵에 저장
        }
        
        data.put("what", "UserID");
        data.put("user_id", userIDD);
        data.put("Accept", "0");

        // 해당 유저의 친구 목록을 조회
        GetMyFriends getMyFriends = new GetMyFriends();
        List<List<String>> friends = getMyFriends.getFriendsByUserID(data); // 친구 목록 조회

        
        // 친구 목록을 표시할 배열 초기화
        String[] FriendList = new String[friends.size()]; // 친구 닉네임 배열
        for (int a = 0; a < friends.size(); a++) {
            List<String> friendInfo = friends.get(a); // 친구 정보 가져오기
            String getFriendID = friendInfo.get(1);  // 친구 ID (인덱스 1에 있다고 가정)
            
            // 맵을 사용하여 친구 ID로 닉네임 찾기
            String FriendNickname = userMap.get(getFriendID); 
            if (FriendNickname != null) {
                FriendList[a] = FriendNickname; // 닉네임을 배열에 추가
            } else {
                FriendList[a] = "Unknown"; // 닉네임이 없으면 "Unknown"으로 처리
            }
        }
        
        // 친구 목록을 보여줄 RoundedComboBox 생성
        RoundedComboBox<String> FriendChoice = new RoundedComboBox<>(
            FriendList, colors.Ground, colors.Text, Color.GRAY);
        FriendChoice.insertItemAt("친구목록", 0);
        FriendChoice.setSelectedIndex(0); // 기본 선택은 "친구목록"
        FriendChoice.setBounds(500, 100, 80, 20);
        panel.add(FriendChoice); // 패널에 추가

        // SectionChoice 콤보박스에 아이템 선택 리스너 추가
        FriendChoice.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) { // 선택된 상태에서만 작동
                    String Choice = FriendChoice.getSelectedItem().toString(); // 선택된 아이템

                    // "친구목록"이 아닌 친구가 선택된 경우에만 작동
                    if (!Choice.equals("친구목록")) {
                        for (int a = 0; a < friends.size(); a++) {
                            FriendID = FriendIDMap.get(Choice); 
                            break;
                   
                        }
                        System.out.println("친구ID: "+FriendID);
                        System.out.println("학기ID: "+Section);

                        // 새로운 스케줄 화면을 열기
                        FriendSchedule a = new FriendSchedule(userIDD, Section, DarK, FriendID);
                        a.showFrame(); // 스케줄 프레임 열기
                    }
                }
            }
        });

        
        // 친구추가버튼
        String addFriendIMG = "src/img/addFriend.png";
        if(DarK == 1) {
        	addFriendIMG = "src/img/WaadFriend.png";
        }
        ImageIcon addFriendImageIcon = new ImageIcon(addFriendIMG);
        Image addFriendImage = addFriendImageIcon.getImage();
        Image addFriend1Image = addFriendImage.getScaledInstance(18, 18, Image.SCALE_SMOOTH);
        ImageIcon addFriend1ImageIcon = new ImageIcon(addFriend1Image);
        JButton addFriendButton = new JButton(addFriend1ImageIcon);
        addFriendButton.setBackground(colors.Ground);
        addFriendButton.setBounds(581, 101, 23, 18);
        addFriendButton.setBorder(borderWhite);
        addFriendButton.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
            	AddFriendDialog();
            }
        });
        addFriendButton.setContentAreaFilled(false);
        addFriendButton.setFocusPainted(false);
        addFriendButton.setOpaque(true);
        panel.add(addFriendButton);
        
        
        //강의실
        RoundedButton lecture = new RoundedButton("강의실"); // 버튼 생성 및 텍스트 설정
        lecture.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
            	UserLecture ShowuserLecture = new UserLecture(userIDD, Section, DarK); 
            }
        });
        lecture.setBounds(534, 65, 45, 20); // 버튼 위치 및 크기 설정
        lecture.setBackground(new Color(200, 50, 50));// 배경색 설정 (빨간색)
        lecture.setForeground(colors.Ground); // 	텍스트 색상(흰색)
        Font lectureFont = new Font(Schedule.getFont().getName(), Font.BOLD, 12);
        panel.add(lecture); // 패널에 버튼 추가
        lecture.setFont(lectureFont);

        
        GetLecture  getLecture  = new GetLecture ();
        List<List<String>> Lectures = getLecture.GetLecture();
        
        Map<String, String> LectureMap = new HashMap<>();
        Map<String, List<String>> StartTimeMap = new HashMap<>();
        Map<String, List<String>> EndTimeMap = new HashMap<>();
        Map<String, String> NameMap = new HashMap<>();

        for (List<String> Lecture : Lectures) {
            String lecture_id = Lecture.get(1);
            String Grade = Lecture.get(5);
            String StartTime = Lecture.get(2);
            String EndTime = Lecture.get(3);
            String LectureName = Lecture.get(4);

            LectureMap.put(lecture_id, Grade);
            StartTimeMap.computeIfAbsent(lecture_id, k -> new ArrayList<>()).add(StartTime);
            EndTimeMap.computeIfAbsent(lecture_id, k -> new ArrayList<>()).add(EndTime);
            NameMap.put(lecture_id, LectureName);
        }

        
        //로그인 유저의 강의정보 가져오기
        String userID = userIDD; 
        String sectionID = Section;
        String encodedUserID = null;
        String encodedSectionID = null;
        
        try {
            encodedUserID = URLEncoder.encode(userID, StandardCharsets.UTF_8.toString());
            encodedSectionID = URLEncoder.encode(sectionID, StandardCharsets.UTF_8.toString());
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        String url = "/get_all_User2_Lecture?UserID=" + encodedUserID + "&section_id=" + encodedSectionID;
	    GetUserLecture  getUserLecture  = new GetUserLecture ();
        List<List<String>> UserLectures = getUserLecture.GetUserLecture(url);
        
        double AddGrage = 0;
        double Multiply1 = 0;
        double Multiply = 0;
        
        double AddGrage2 = 0;

        double LecturNum = 1;
        for (int a = 0; a < UserLectures.size(); a++) {
            List<String> UserLecture = UserLectures.get(a);
            String UserLecture_id = UserLecture.get(0);
            String credits_grade = UserLecture.get(3);     
            
            String LectureGrade = LectureMap.get(UserLecture_id);  
            
            switch (credits_grade) {	// 조건
    		case "A+":		// 값 불일치(미실행)
    			credits_grade = "4.5";
    			break;
    		case "A":
    			credits_grade = "4";
    			break; // 종료
    		case "B+":
    			credits_grade = "3.5";
    			break;
    		case "B":
    			credits_grade = "3";
    			break;
    		case "C+":
    			credits_grade = "2.5";
    			break;
    		case "C":
    			credits_grade = "2";
    			break;
    		case "D+":
    			credits_grade = "1.5";
    			break;
    		case "D":
    			credits_grade = "1";
    			break;
    		case "F":
    			credits_grade = "0";
    			break;
    		default:
    			credits_grade = "P";
            }
            double LectureGrade1 = Double.parseDouble(LectureGrade);        
            if(credits_grade.equals("P")) {
            	LecturNum --;
            } else {
                double credits_grade1 = Double.parseDouble(credits_grade);

                Multiply1 = credits_grade1*LectureGrade1;

                Multiply = Multiply + Multiply1;
                AddGrage = AddGrage + LectureGrade1;
            }
            AddGrage2 = AddGrage2 + LectureGrade1;
        }
        System.out.println("총합: " + Multiply);
        System.out.println("P제외 합: " + AddGrage);
        System.out.println("이수학점: " + AddGrage2);

        double Show_credits_grade = Math.round(Multiply / AddGrage * 100) / 100.0;
        JLabel aver_grade = new JLabel("평군 학점: "+Show_credits_grade);
        aver_grade.setBounds(80, 690, 150, 25); // Adjust the position and size as needed
        aver_grade.setForeground(colors.BlackText); // Set label text color
        aver_grade.setFont(buttonFont);
        //aver_grade.setHorizontalAlignment(JLabel.CENTER);
        panel.add(aver_grade);
        
        int ShowAddGrage = (int) Math.round(AddGrage2);
        JLabel grade = new JLabel("이수 학점: "+ShowAddGrage);
        grade.setBounds(80, 665, 150, 25); // Adjust the position and size as needed
        grade.setForeground(colors.BlackText); // Set label text color
        grade.setFont(buttonFont);
        //aver_grade.setHorizontalAlignment(JLabel.CENTER);
        panel.add(grade);
        
        int AllGrade = 0;
	    GetUserLecture  getUserLecture2  = new GetUserLecture ();
        List<List<String>> UserLectures2 = getUserLecture2.GetUserLecture("/get_all_User_Lecture");
        for (int a = UserLectures2.size() - 1; a >= 0; a--) {
            List<String> UserLecture = UserLectures2.get(a);
            String UserLecture_id = UserLecture.get(0);
            String UserID = UserLecture.get(1);
            if(UserID.equals(userIDD)) {
	            String LectureGrade = LectureMap.get(UserLecture_id);
	            int number = Integer.parseInt(LectureGrade);
	            AllGrade = AllGrade + number;
            }
        }
        JLabel allgrade = new JLabel("전체 이수 학점: " + AllGrade);
        allgrade.setBounds(80, 640, 200, 25); // Adjust the position and size as needed
        allgrade.setForeground(colors.BlackText); // Set label text color
        allgrade.setFont(buttonFont);
        //aver_grade.setHorizontalAlignment(JLabel.CENTER);
        panel.add(allgrade);
        
        panel.setLayout(null); // 레이아웃 매니저 비활성화

        for (int a = 0; a < 10; a++) { 
                    // 버튼 생성
    
        }
        
        panel.setLayout(null); // 레이아웃 매니저 비활성화

        for (int a = 0; a < UserLectures.size(); a++) {
            List<String> UserLecture = UserLectures.get(a);
            String UserLecture_id = UserLecture.get(0);
            String UserID = UserLecture.get(1);
            String UserSection_id = UserLecture.get(2);
            String credits_grade = UserLecture.get(3);           
            String LectureGrade = LectureMap.get(UserLecture_id);
            String LectureName = NameMap.get(UserLecture_id);

            List<String> StartTimes = StartTimeMap.get(UserLecture_id);
            List<String> EndTimes = EndTimeMap.get(UserLecture_id);

            if (StartTimes != null && EndTimes != null) {
                for (int i = 0; i < StartTimes.size(); i++) {

                    String StartTime = StartTimes.get(i);
                    String EndTime = EndTimes.get(i);

                    // 요일별 X 위치 계산
                    String Startday = StartTime.substring(0, StartTime.length() - 2);
                    int DayX = 0;
                    switch (Startday) {
                        case "월": DayX = 38; break;
                        case "화": DayX = 138; break;
                        case "수": DayX = 238; break;
                        case "목": DayX = 338; break;
                        case "금": DayX = 438; break;
                    }

                    // 시간별 Y 위치 계산
                    int StartHour = Integer.parseInt(StartTime.substring(1));
                    int EndHour = Integer.parseInt(EndTime.substring(1));
                    int StartY = 26 + (StartHour - 9) * 43;  // 9시 기준
                    int EndY = (EndHour - 9) * 43;      // 9시 기준

                    // 넓이는 40, 높이는 EndY - StartY
                    int widthX = 99;
                    int heightY = EndY - (StartY-26);

                    System.out.println(LectureName + ": " + Startday + "요일 " + StartHour + "시 부터 " + EndHour + "시 까지");
                    
                    String ShowText = "<html>" + LectureName.replace("\n", "<br>");
                    RoundedButton2 Showlecture = new RoundedButton2(ShowText);

                    Showlecture.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                        	int B = 0;
                            String lecture_id = null;
                            String lecture_id2 = null;
                            int what ;
                            for (what = 0 ; what < Lectures.size() ;what++) {
                            	List<String> Lecture = Lectures.get(what);
                	            lecture_id = Lecture.get(1);
    	                            if(what>0) {	                            	
    	                	            List<String> Lecture2 = Lectures.get(what-1);
    	                	            lecture_id2 = Lecture2.get(1);
    	                            } 
                    	            if (UserLecture_id.equals(lecture_id)) {
                    	            	B = what;
                    	            	break;
                    	            }
                                }
                            
            	            if(UserLecture_id.equals(lecture_id2)) {
            	            	B=B-1;

            	            	System.out.println("조정: "+B);
            	            }
                        	LectureInfo lectureInfo = new LectureInfo(userIDD, Section, B, DarK, "빼기");
                        }
                    });
                    // 버튼 위치 및 크기 설정
                    Showlecture.setBounds(DayX, StartY, widthX, heightY); 
                    Showlecture.setBackground(new Color(49 + a*18, 120 + a*10, 225- a*18)); // 배경색 설정
                    Showlecture.setForeground(colors.Ground); // 텍스트 색상 설정
                    Font ShowlectureFont = new Font(Schedule.getFont().getName(), Font.BOLD, 10);
                    Showlecture.setFont(ShowlectureFont);  // 폰트 설정
                    
                    // 패널에 버튼 추가

                    layeredPane.add(Showlecture, JLayeredPane.PALETTE_LAYER);

                    layeredPane.revalidate();
                    layeredPane.repaint();
                    

                }
            }
        }  
    }
    
    // 친구추가
    private void AddFriendDialog() {
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
            colors.ToggleBtn = new Color(70, 70, 70);
        }
        Border borderBlack = BorderFactory.createLineBorder(new Color(0, 0, 0), 1);
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(270, 400, 300, 190);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 276, 150);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255), 1)); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel SuccessLabel = new JLabel("친구아이디 입력");
        SuccessLabel.setBounds(87, 20, 200, 15);
        SuccessLabel.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
        Font SuccessFont = new Font(SuccessLabel.getFont().getName(), Font.BOLD, 14);
        SuccessLabel.setFont(SuccessFont);
        dialogPanel.add(SuccessLabel);

        RoundtextField FrindIDfield = new RoundtextField(); // 텍스트 필드 생성
        FrindIDfield.setBounds(37, 55, 200, 30); // 텍스트 필드 위치 및 크기 설정
        FrindIDfield.setBackground(colors.BoardPanel); // 배경색 설정
        FrindIDfield.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        dialogPanel.add(FrindIDfield); // 패널에 텍스트 필드 추가
        FrindIDfield.setColumns(10); // 텍스트 필드 컬럼 수 설정
        FrindIDfield.setBorder(borderBlack); // 테두리 설정

        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("추가");
        confirmButton.setBounds(107, 120, 65, 20);
        confirmButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)

        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String GetFriendID = FrindIDfield.getText();

                AddFriendCheckDialog(GetFriendID);
                
                dialogFrame.dispose();

            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
    
    // 친구추가 2
    private void AddFriendCheckDialog(String FID) {
        JSONObject data = new JSONObject();

        collor colors = new collor(); 
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
            colors.ToggleBtn = new Color(70, 70, 70);
        }
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(270, 400, 300, 150);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 276, 110);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255), 1)); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        data.put("table", "users");
        data.put("want", "Nickname");
        data.put("what", "UserID");
        data.put("user_id", FID);
        Post po = new Post();
    	JSONObject FriendNickname1 = po.jsonpost("/find_user_information", data);
    	String FriendNickname = FriendNickname1.getString("Nickname");
        
    	if(FID.equals(userIDD)) {
            // 다이얼로그 라벨 생성
            JLabel SuccessLabel = new JLabel("자신을 친구로 등록할 수 없습니다");
            SuccessLabel.setBounds(38, 28, 200, 15);
            SuccessLabel.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
            Font SuccessFont = new Font(SuccessLabel.getFont().getName(), Font.BOLD, 12);
            SuccessLabel.setFont(SuccessFont);
            SuccessLabel.setHorizontalAlignment(JLabel.CENTER);
            dialogPanel.add(SuccessLabel);
            
    	} else if(FriendNickname.equals("없음")) {
            // 다이얼로그 라벨 생성
            JLabel SuccessLabel = new JLabel("아이디가 등록 되어있지 않습니다");
            SuccessLabel.setBounds(38, 28, 200, 15);
            SuccessLabel.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
            Font SuccessFont = new Font(SuccessLabel.getFont().getName(), Font.BOLD, 12);
            SuccessLabel.setFont(SuccessFont);
            SuccessLabel.setHorizontalAlignment(JLabel.CENTER);
            dialogPanel.add(SuccessLabel);
    	} else { 		
            JLabel SuccessLabel = new JLabel(FriendNickname + "님 에게 친구 요청을 했습니다!");
            SuccessLabel.setBounds(18, 28, 240, 15);
            SuccessLabel.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
            Font SuccessFont = new Font(SuccessLabel.getFont().getName(), Font.BOLD, 12);
            SuccessLabel.setFont(SuccessFont);
            SuccessLabel.setHorizontalAlignment(JLabel.CENTER);
            dialogPanel.add(SuccessLabel);
            
            data.put("UserID", userIDD);
            data.put("FriendID", FID);
            data.put("Accept", "1");
			JSONObject change_check = po.jsonpost("/request_friend", data);
			boolean success = change_check.getBoolean("success"); 
			System.out.println("친구요청 성공 여부: " + success);
            
            
    	}
        
        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("확인");
        confirmButton.setBounds(107, 80, 65, 20);
        confirmButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialogFrame.dispose();

            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }

    //친구 수락
    private void FriendAeccptDialog(String FriendID) {
        JSONObject data = new JSONObject();

        collor colors = new collor(); 
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
            colors.ToggleBtn = new Color(70, 70, 70);
        }
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(270, 400, 300, 150);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 276, 110);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255), 1)); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        data.put("table", "users");
        data.put("want", "Nickname");
        data.put("what", "UserID");
        data.put("user_id", FriendID);
        Post po = new Post();
    	JSONObject FriendNickname1 = po.jsonpost("/find_user_information", data);
    	String FriendNickname = FriendNickname1.getString("Nickname");
        
        // 다이얼로그 라벨 생성
        JLabel alarmLabel = new JLabel(FriendNickname + "님이 친구요청을 했습니다!");
        alarmLabel.setBounds(38, 28, 200, 15);
        alarmLabel.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
        Font SuccessFont = new Font(alarmLabel.getFont().getName(), Font.BOLD, 12);
        alarmLabel.setFont(SuccessFont);
        alarmLabel.setHorizontalAlignment(JLabel.CENTER);
        dialogPanel.add(alarmLabel);

            
    	
        
        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("수락");
        confirmButton.setBounds(70, 80, 65, 20);
        confirmButton.setBackground(new Color(255, 80, 80));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	
            	data.put("table", "Friend");
                data.put("this1", "UserID");
                data.put("this11", FriendID);
                data.put("this2", "FriendID");
                data.put("this22", userIDD);
            	data.put("what", "Accept");
                data.put("change", "0");               
    			JSONObject change_check2 = po.jsonpost("/change_Information", data);
    			boolean success2 = change_check2.getBoolean("success"); 
    			System.out.println("친구 성공 여부: " + success2);
            	          	
                data.put("UserID", userIDD);
                data.put("FriendID", FriendID);
                data.put("Accept", "0");
    			JSONObject change_check = po.jsonpost("/request_friend", data);
    			boolean success = change_check.getBoolean("success"); 
    			System.out.println("친구 성공 여부2: " + success);    	
    			
                schedule a = new schedule(userIDD, Section, DarK);
                a.showFrame();
                frame.dispose();
                
                dialogFrame.dispose();
                
            }
        });
        dialogPanel.add(confirmButton);

        
        // 확인 버튼 생성
        RoundedButton cancelButton = new RoundedButton("거절");
        cancelButton.setBounds(144, 80, 65, 20);
        cancelButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        cancelButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	data.put("table", "Friend");
                data.put("what", "UserID");
                data.put("what2", "FriendID");
                data.put("column", FriendID);
                data.put("column2", userIDD);

    			JSONObject change_check = po.jsonpost("/delete_column3", data);
    			boolean success = change_check.getBoolean("success"); 
    			System.out.println("친구 성공 여부: " + success);
    			
                dialogFrame.dispose();

            }
        });
        dialogPanel.add(cancelButton);

        
        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }

    
    

    public void showFrame() {
        frame.setVisible(true);
    }
    
    
}
