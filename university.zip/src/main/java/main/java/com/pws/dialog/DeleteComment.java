package main.java.com.pws.dialog;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

import org.json.JSONObject;

import main.java.com.pws.Board.showPost;
import main.java.com.pws.Thing.FrameManager;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.collor;

public class DeleteComment {
	private String CommentsID;	
	private String LogID;
	private String PostuserIDD;
	private String PostIDD;
	private String Section;
	private int DarK;

	public DeleteComment(String CommentsID, String LogID, String PostuserIDD, String PostIDD, String Section, int DarK) {		
        this.CommentsID = CommentsID;
        this.LogID = LogID;
        this.PostuserIDD = PostuserIDD;
        this.PostIDD = PostIDD;
        this.Section = Section;
        this.DarK = DarK;

		 initialize();
	}
	
	
    private void initialize() {
    	JSONObject data = new JSONObject();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }

        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);

        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(270, 400, 300, 150);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null); // 레이아웃 설정 (null은 절대 위치 배치)

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 276, 110);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(borderWhite); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel SuccessLabel = new JLabel("댓글을 삭제 하시겠습니까?");
        SuccessLabel.setBounds(73, 30, 200, 15);
        SuccessLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
        Font SuccessFont = new Font(SuccessLabel.getFont().getName(), Font.BOLD, 12);
        SuccessLabel.setFont(SuccessFont);
        dialogPanel.add(SuccessLabel);

        // 확인 버튼 생성
        RoundedButton OkButton = new RoundedButton("삭제");
        OkButton.setBounds(80, 80, 50, 20);
        OkButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        OkButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        OkButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {                
                data.put("table", "comments");
                data.put("what", "CommentsID");
                data.put("column", CommentsID);
                Post po = new Post();
				JSONObject change_check = po.jsonpost("/delete_column", data);
				boolean success = change_check.getBoolean("success"); 
				System.out.println("댓글 삭제 여부: " + success);
                              
                FrameManager.closeAllFrames(); // 모든 프레임 닫기
                showPost b = new showPost(LogID, PostuserIDD, PostIDD, "일반", Section, DarK);
                b.showFrame();
                dialogFrame.dispose();

            }
        });
        dialogPanel.add(OkButton);

        RoundedButton NoButton = new RoundedButton("취소");
        NoButton.setBounds(140, 80, 50, 20);
        NoButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        NoButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        NoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialogFrame.dispose();

            }
        });
        dialogPanel.add(NoButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }

}
