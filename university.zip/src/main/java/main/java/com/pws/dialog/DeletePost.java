package main.java.com.pws.dialog;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

import org.json.JSONObject;

import main.java.com.pws.Board.freeboardclass;
import main.java.com.pws.Thing.FrameManager;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.collor;

public class DeletePost {
	private String BulletinID;	
	private String LogID;
	private String Section;
	private int DarK;

	public DeletePost(String BulletinID, String LogID, String Section, int DarK) {		
        this.BulletinID = BulletinID;
        this.LogID = LogID;
        this.Section = Section;
        this.DarK = DarK;

		 initialize();
	}
	
	
    private void initialize() {
    	JSONObject data = new JSONObject();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }
        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);


        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(270, 400, 300, 150);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null); 

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 276, 110);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(borderWhite); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel SuccessLabel = new JLabel("게시물을 삭제 하시겠습니까?");
        SuccessLabel.setBounds(65, 30, 200, 15);
        SuccessLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
        Font SuccessFont = new Font(SuccessLabel.getFont().getName(), Font.BOLD, 12);
        SuccessLabel.setFont(SuccessFont);
        dialogPanel.add(SuccessLabel);

        // 확인 버튼 생성
        RoundedButton OkButton = new RoundedButton("삭제");
        OkButton.setBounds(80, 80, 50, 20);
        OkButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        OkButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        OkButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {     
				data.put("table", "bulletin");
		        data.put("want", "BoardID");
		        data.put("what", "BulletinID");
		        data.put("user_id", BulletinID);
                Post po = new Post();
				JSONObject SearchBoardID1 = po.jsonpost("/find_user_information", data);
				String SearchBoardID = SearchBoardID1.getString("BoardID");
				
                data.put("table", "comments");
                data.put("what", "BulletinID");
                data.put("column", BulletinID);
				JSONObject change_check = po.jsonpost("/delete_column", data);
				boolean success = change_check.getBoolean("success"); 
				System.out.println("해당 게시물 댓글 삭제 여부: " + success);
                                
                data.put("table", "bulletin");
                data.put("what", "BulletinID");
                data.put("column", BulletinID);
				JSONObject change_check2 = po.jsonpost("/delete_column", data);
				boolean success2 = change_check2.getBoolean("success"); 
				System.out.println("해당 게시물 삭제 여부: " + success2);
				
			
                FrameManager.closeAllFrames(); // 모든 프레임 닫기
                freeboardclass b = new freeboardclass(LogID, SearchBoardID, Section, DarK);
                b.showFrame();
                dialogFrame.dispose();

            }
        });
        dialogPanel.add(OkButton);

        RoundedButton NoButton = new RoundedButton("취소");
        NoButton.setBounds(140, 80, 50, 20);
        NoButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        NoButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        NoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialogFrame.dispose();

            }
        });
        dialogPanel.add(NoButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }

}
