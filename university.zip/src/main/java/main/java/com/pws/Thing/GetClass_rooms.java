package main.java.com.pws.Thing;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GetClass_rooms {

    public List<List<String>> GetClass_rooms() {
        HttpURLConnection connection = null;
        List<List<String>> Class_rooms = new ArrayList<>();

        try {
            String apiURL = "http://127.0.0.1:5000/get_all_room";
            URL url = new URL(apiURL);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");

            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"))) {
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    String returnMsg = response.toString();
                    System.out.println("서버 응답: " + returnMsg); // 서버 응답 출력

                    if (!returnMsg.trim().isEmpty()) {
                        JSONObject jsonResponse = new JSONObject(returnMsg);
                        JSONArray Class_roomsArray = jsonResponse.getJSONArray("class_rooms");

                        for (int i = 0; i < Class_roomsArray.length(); i++) {
                            JSONObject Class_room = Class_roomsArray.getJSONObject(i);
                            List<String> Class_roomData = new ArrayList<>();
                            Class_roomData.add(Class_room.getString("room_id"));
                            Class_roomData.add(Class_room.getString("building"));
                            Class_roomData.add(Class_room.getString("room_number"));

                            Class_rooms.add(Class_roomData);
                        }
                    } else {
                        System.out.println("서버 응답이 비어있습니다.");
                    }
                }
            } else {
                System.out.println("HTTP 응답 코드: " + responseCode);
            }

        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }

        return Class_rooms;
    }
}
