package main.java.com.pws.Thing;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GetInstructors {

    public List<List<String>> GetInstructors() {
        HttpURLConnection connection = null;
        List<List<String>> instructors = new ArrayList<>();

        try {
            String apiURL = "http://127.0.0.1:5000/get_all_instructors";
            URL url = new URL(apiURL);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");

            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"))) {
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    String returnMsg = response.toString();
                    System.out.println("서버 응답: " + returnMsg); // 서버 응답 출력

                    if (!returnMsg.trim().isEmpty()) {
                        JSONObject jsonResponse = new JSONObject(returnMsg);
                        JSONArray instructorsArray = jsonResponse.getJSONArray("instructors");

                        for (int i = 0; i < instructorsArray.length(); i++) {
                            JSONObject instructor = instructorsArray.getJSONObject(i);
                            List<String> instructorData = new ArrayList<>();
                            instructorData.add(instructor.getString("instructor_id"));
                            instructorData.add(instructor.getString("name"));
                            instructorData.add(instructor.getString("UID"));

                            instructors.add(instructorData);
                        }
                    } else {
                        System.out.println("서버 응답이 비어있습니다.");
                    }
                }
            } else {
                System.out.println("HTTP 응답 코드: " + responseCode);
            }

        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }

        return instructors;
    }
}
