package main.java.com.pws.dialog;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import org.json.JSONObject;

import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.RoundtextField;
import main.java.com.pws.Thing.TodayDate;
import main.java.com.pws.Thing.collor;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;

public class UserLimit {
    private String userIDD;
    private String PostUserID;
    private int DarK;

    public UserLimit(String userIDD, String PostUserID, int DarK) {
        this.userIDD = userIDD;
        this.PostUserID = PostUserID;
        this.DarK = DarK;

        initialize();
    }

    private void initialize() {
        JSONObject data = new JSONObject();
        TodayDate todayDate = new TodayDate();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }

        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        Border borderBlack = BorderFactory.createLineBorder(colors.BoardPanel, 2);
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(250, 400, 350, 250);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 326, 308);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(borderWhite); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel MyPostLabel = new JLabel("유저 제한");
        MyPostLabel.setBounds(122, 25, 200, 20);
        MyPostLabel.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
        Font MyPostFont = new Font(MyPostLabel.getFont().getName(), Font.BOLD, 18);
        MyPostLabel.setFont(MyPostFont);
        dialogPanel.add(MyPostLabel);
        
        
        
        // 제한일수 입력 필드
        RoundtextField LimitField = new RoundtextField();
        LimitField.setBounds(60, 70, 200, 20);
        LimitField.setBackground(colors.BoardPanel);
        LimitField.setForeground(colors.Text);
        dialogPanel.add(LimitField);
        LimitField.setColumns(10);
        LimitField.setBorder(borderBlack);
        LimitField.setDefaultText("  제한일수 입력");
        
        // 비밀번호 일치 여부를 표시하는 라벨
        JLabel LimitDateLabel = new JLabel("");
        Font labelFont2 = new Font(LimitDateLabel.getFont().getName(), Font.BOLD, 9);
        LimitDateLabel.setFont(labelFont2);
        dialogPanel.add(LimitDateLabel);

        // 제한일수 필드에 DocumentListener 추가
        LimitField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                checkInputValidity();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                checkInputValidity();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                checkInputValidity();
            }

            private void checkInputValidity() {
                String LimiDay = LimitField.getText().trim();

                if (LimiDay.isEmpty() || !isNumeric(LimiDay)) {
                    LimitDateLabel.setText("정수를 입력해 주세요.");
                    LimitDateLabel.setForeground(new Color(150, 100, 100)); // 빨간색
                    LimitDateLabel.setBounds(114, 100, 150, 15);
                } else {
                    int IntLimitDay = Integer.parseInt(LimiDay);
                    long newDateTimeLong = TodayDate.addDaysToCurrentDate(IntLimitDay);
                    LocalDateTime newDateTime = TodayDate.parseDateTime(String.valueOf(newDateTimeLong));
                    String addYear = String.valueOf(newDateTime.getYear());
                    String addMonth = String.valueOf(newDateTime.getMonthValue());
                    String addDay = String.valueOf(newDateTime.getDayOfMonth());
                    String addHour = String.valueOf(newDateTime.getHour());
                    String addMinute = String.valueOf(newDateTime.getMinute());
                    
                    LimitDateLabel.setText(addYear+"년 "+
                    		addMonth+"월 "+ addDay+"일 "+
                    		addHour+"시 " + addMinute+"분 까지");
                    LimitDateLabel.setForeground(new Color(100, 100, 150)); // 빨간색
                    LimitDateLabel.setBounds(100, 105, 150, 15);
                }
            }
        });
        
        JLabel NoLimitLabel = new JLabel("제한 해제시 0입력");
        NoLimitLabel.setBounds(120, 123, 200, 10);
        NoLimitLabel.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
        NoLimitLabel.setFont(labelFont2);
        dialogPanel.add(NoLimitLabel);
        
        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("제한");
        confirmButton.setBounds(128, 140, 65, 20);
        confirmButton.setBackground(new Color(100, 100, 100)); // 배경색 설정
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String LimiDay = LimitField.getText().trim();

                if (LimiDay.isEmpty() || !isNumeric(LimiDay)) {
                    LimitDateLabel.setText("정수를 입력해 주세요.");
                    LimitDateLabel.setForeground(new Color(150, 100, 100)); // 빨간색
                    LimitDateLabel.setBounds(117, 105, 150, 15);
                } else {
                    int IntLimitDay = Integer.parseInt(LimiDay);
                    long newDateTimeLong = TodayDate.addDaysToCurrentDate(IntLimitDay);
                    String LimitDate = String.valueOf(newDateTimeLong);
                    
                	data.put("table", "users");
                    data.put("this1", "UserID");
                    data.put("this2", PostUserID);
                    data.put("what", "LimitDate");
                    data.put("change", LimitDate);
                    Post po = new Post();
    				JSONObject change_check = po.jsonpost("/change_user", data);
    				boolean success = change_check.getBoolean("success"); 
    				System.out.println("변경 성공 여부: " + success);
                    dialogFrame.dispose();
                }
            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }

    private boolean isNumeric(String str) {
        if (str == null || str.isEmpty()) {
            return false;
        }
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
