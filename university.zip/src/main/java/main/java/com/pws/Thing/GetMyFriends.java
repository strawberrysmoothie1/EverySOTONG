package main.java.com.pws.Thing;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public class GetMyFriends {

    // 서버로부터 특정 UserID에 해당하는 친구 정보를 가져오는 메서드
    public List<List<String>> getFriendsByUserID(JSONObject json) {
        List<List<String>> friendsList = new ArrayList<>();
        HttpURLConnection connection = null;

        try {
            // Flask 서버의 API 엔드포인트
            String apiURL = "http://127.0.0.1:5000/get_my_Friends";
            URL url = new URL(apiURL);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");  // POST 메서드를 사용하도록 수정
            connection.setRequestProperty("Content-Type", "application/json; utf-8");
            connection.setDoOutput(true);

            // JSON 데이터 전송
            try (OutputStreamWriter wr = new OutputStreamWriter(connection.getOutputStream(), StandardCharsets.UTF_8)) {
                wr.write(json.toString());
                wr.flush();
            }

            // 응답 코드 확인
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                // 서버로부터 응답을 받음
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder response = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }

                // 응답을 JSON으로 파싱
                String responseStr = response.toString();
                System.out.println("친구목록 응답: " + responseStr); // 서버 응답 출력

                JSONObject jsonResponse = new JSONObject(responseStr);
                JSONArray friendsArray = jsonResponse.getJSONArray("friends");

                // 각 친구 정보를 리스트로 저장
                for (int i = 0; i < friendsArray.length(); i++) {
                    JSONObject friend = friendsArray.getJSONObject(i);
                    List<String> friendData = new ArrayList<>();
                    friendData.add(friend.getString("UserID"));
                    friendData.add(friend.getString("FriendID"));
                    friendData.add(friend.getString("Accept"));
                    friendsList.add(friendData);
                }
            } else {
                System.out.println("HTTP 응답 코드: " + responseCode);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return friendsList; // 친구 정보 리스트 반환
    }
}
