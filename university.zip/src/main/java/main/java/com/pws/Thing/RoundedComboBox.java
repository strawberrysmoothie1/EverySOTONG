package main.java.com.pws.Thing;

import javax.swing.*;
import javax.swing.plaf.basic.BasicComboBoxUI;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class RoundedComboBox<E> extends JComboBox<E> {

    public RoundedComboBox(E[] items, Color backgroundColor, Color textColor, Color borderColor) {
        super(items);
        
        // Set the UI to the custom UI
        setUI(new CustomComboBoxUI(backgroundColor, textColor, borderColor));
        
        // Set custom renderer for the ComboBox
        setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                
                // Set text color
                label.setForeground(textColor);
                
                // Set background color for selected item
                if (isSelected) {
                    label.setBackground(backgroundColor.darker());
                } else {
                    label.setBackground(backgroundColor);
                }
                
                return label;
            }
        });
    }
    
    private static class CustomComboBoxUI extends BasicComboBoxUI {
        private final Color backgroundColor;
        private final Color textColor;
        private final Color borderColor;
        
        public CustomComboBoxUI(Color backgroundColor, Color textColor, Color borderColor) {
            this.backgroundColor = backgroundColor;
            this.textColor = textColor;
            this.borderColor = borderColor;
        }

        @Override
        protected JButton createArrowButton() {
            JButton button = new JButton("▼");
            button.setBackground(backgroundColor);
            button.setBorder(BorderFactory.createEmptyBorder());
            button.setForeground(textColor);
            return button;
        }

        @Override
        public void paintCurrentValueBackground(Graphics g, Rectangle bounds, boolean hasFocus) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setColor(backgroundColor);
            g2.fillRect(bounds.x, bounds.y, bounds.width, bounds.height);
        }

        @Override
        protected void installDefaults() {
            super.installDefaults();
            comboBox.setBackground(backgroundColor);
            comboBox.setForeground(textColor);
            comboBox.setBorder(BorderFactory.createLineBorder(borderColor));
        }

        @Override
		public void paintCurrentValue(Graphics g, Rectangle bounds, boolean hasFocus) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(comboBox.getBackground());
            RoundRectangle2D roundedRectangle = new RoundRectangle2D.Float(0, 0, comboBox.getWidth(), comboBox.getHeight(), 10, 10);
            g2.fill(roundedRectangle);
            
            g.setColor(comboBox.getForeground());
            super.paintCurrentValue(g, bounds, hasFocus);
        }
    }
}
