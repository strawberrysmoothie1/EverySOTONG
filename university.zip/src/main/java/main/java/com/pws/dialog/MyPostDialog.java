package main.java.com.pws.dialog;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicScrollBarUI;

import org.json.JSONObject;

import main.java.com.pws.Board.showPost;
import main.java.com.pws.Thing.FrameManager;
import main.java.com.pws.Thing.GetBulletins;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundedBorder;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.TodayDate;
import main.java.com.pws.Thing.collor;

public class MyPostDialog {
	private String UserID;	
	private String LogID;
	private String Section;
	private int DarK;

	public MyPostDialog(String UserID, String LogID, String Section, int DarK) {		
        this.UserID = UserID;
        this.LogID = LogID;
        this.Section = Section;
        this.DarK = DarK;

		 initialize();
	}
	
    public void initialize () {        
        JSONObject data = new JSONObject();
        TodayDate todayDate = new TodayDate();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }


        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        Border borderBlack = BorderFactory.createLineBorder(new Color(0, 0, 0), 1);

        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(150, 240, 550, 570);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 526, 528);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255), 1)); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel MyPostLabel = new JLabel("작성한 글");
        MyPostLabel.setBounds(223, 25, 200, 20);
        MyPostLabel.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
        Font MyPostFont = new Font(MyPostLabel.getFont().getName(), Font.BOLD, 20);
        MyPostLabel.setFont(MyPostFont);
        dialogPanel.add(MyPostLabel);
        
        data.put("table", "bulletin");
        data.put("want", "UserID");
        data.put("boardID", UserID);
        Post po = new Post();
    	JSONObject SearchCount1 = po.jsonpost("/board_find_post_id", data);
    	int SearchCount = SearchCount1.getInt("count");
        
        // 패널 생성
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(colors.Ground);
        int hight = 468;
        if (SearchCount > 7) {
            hight = 5 + 62 * SearchCount;
        }
        panel_1.setBounds(23, 80, 480, hight);
        dialogPanel.add(panel_1);
        panel_1.setLayout(null);
        panel_1.setBorder(borderWhite); // 테두리 설정
        RoundedBorder roundedBorder = new RoundedBorder(20);
        panel_1.setPreferredSize(new Dimension(480, hight));
        
        data.put("table", "users");
        data.put("want", "Nickname");
        data.put("what", "UserID");
        data.put("user_id", UserID);
    	JSONObject SearchNickname1 = po.jsonpost("/find_user_information", data);
    	String SearchNickname = SearchNickname1.getString("Nickname");
    	
    	GetBulletins getBulletins = new GetBulletins(); 	
        List<List<String>> bulletins = getBulletins.getAllBulletins();
    	
        int COUNT = 0;
        int aa = bulletins.size() -1 ;
        for (int a = 1; a <= bulletins.size(); a++) {
        	List<String> bulletin = bulletins.get(aa);
            String ShowTitle = null;
            String ShowContent = null;
            String ShowNicname = null;

            String BulletinID = bulletin.get(0);
            String SearchTitle = bulletin.get(4);
            String SearchContent = bulletin.get(5);
            long SearchBdate = Long.parseLong(bulletin.get(6));
            String SearchUser = bulletin.get(1);

            aa--;

            if (UserID.equals(SearchUser)) {
                // 게시물 페널
                JPanel Postpanel = new JPanel();
                Postpanel.setBackground(colors.Ground);
                Postpanel.setBounds(23, 5 + (62 * COUNT), 474, 60);
                panel_1.add(Postpanel);
                Postpanel.setLayout(null);
                Postpanel.setBorder(borderBlack); // 테두리 설정
                Postpanel.setBorder(roundedBorder);

                // 변수 설정
                ShowNicname = SearchNickname;
                ShowTitle = SearchTitle;
                ShowContent = SearchContent;

                long NewDateTime = todayDate.TodayDate();
                long newMinte = NewDateTime % 100;
                long searchMinte = SearchBdate % 100;
                long minute = newMinte - searchMinte;

                long newHour = (NewDateTime % 10000) / 100;
                long searchHour = (SearchBdate % 10000) / 100;
                long hour = newHour - searchHour;
                if (minute < 0) {
                    minute += 60;
                    hour -= 1; // 분에서 빼준 만큼 시간을 조정
                }
                long newDay = (NewDateTime % 1000000) / 10000;
                long searchDay = (SearchBdate % 1000000) / 10000;
                long day = newDay - searchDay;
                if (hour < 0) {
                    hour += 24;
                    day -= 1; // 시간에서 빼준 만큼 날짜를 조정
                }
                long newmonth = (NewDateTime % 100000000) / 1000000;
                long searchmonth = (SearchBdate % 100000000) / 1000000;
                long month = newmonth - searchmonth;
                if (day < 0) {
                    day += 30;  // 필요 시 해당 달의 일수로 조정해야 할 수도 있음
                    month -= 1;
                }
                long newyear = NewDateTime / 100000000;
                long searchyear = SearchBdate / 100000000;
                long year = newyear - searchyear;
                if (month < 0) {
                    month += 12;
                    year -= 1;
                }
                String dayLabel = null;
                if (year > 0) {
                    dayLabel = searchyear + " " + searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (month > 0) {
                    dayLabel = searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (day > 0) {
                    dayLabel = searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (day == 0 && hour > 0) {
                    dayLabel = hour + "시간" + minute + "분 전";
                } else {
                    dayLabel = minute + "분 전";
                }

                // 시간 라벨
                JLabel TimeLabel = new JLabel(dayLabel);
                TimeLabel.setBounds(10, 38, 200, 15); // Adjust the position and size as needed
                TimeLabel.setForeground(new Color(100, 100, 100)); // Set label text color
                Font TimeFont = new Font(TimeLabel.getFont().getName(), Font.BOLD, 8);
                TimeLabel.setFont(TimeFont);
                Postpanel.add(TimeLabel);

                // 제목 버튼
                JButton postbutton = new JButton(ShowTitle);
                postbutton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        dialogFrame.dispose();
                        FrameManager.closeAllFrames(); // 모든 프레임 닫기
                        showPost b = new showPost(LogID, SearchUser, BulletinID, "일반", Section, DarK);
                        b.showFrame();
                    }
                });
                postbutton.setHorizontalAlignment(SwingConstants.LEFT);
                postbutton.setBorder(borderWhite);
                postbutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
                postbutton.setForeground(colors.Text); // 텍스트 색상(흰색)
                postbutton.setBounds(6, 2, 410, 20);
                Font memberbuttonFont = new Font(postbutton.getFont().getName(), Font.BOLD, 12);
                postbutton.setFont(memberbuttonFont);
                postbutton.setContentAreaFilled(false);
                postbutton.setFocusPainted(false);
                postbutton.setOpaque(true);
                Postpanel.add(postbutton);
                // 내용 버튼
                JButton contentbutton = new JButton(ShowContent);
                contentbutton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        dialogFrame.dispose();
                        FrameManager.closeAllFrames(); // 모든 프레임 닫기
                        showPost b = new showPost(LogID, SearchUser, BulletinID, "일반", Section, DarK);
                        b.showFrame();
                    }
                });
                contentbutton.setHorizontalAlignment(SwingConstants.LEFT);
                contentbutton.setBorder(borderWhite);
                contentbutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
                contentbutton.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
                contentbutton.setBounds(7, 22, 420, 15);
                Font contentFont = new Font(contentbutton.getFont().getName(), Font.BOLD, 10);
                contentbutton.setFont(contentFont);
                contentbutton.setContentAreaFilled(false);
                contentbutton.setFocusPainted(false);
                contentbutton.setOpaque(true);
                Postpanel.add(contentbutton);

                // 닉네임
                JLabel Nicknamebutton = new JLabel(ShowNicname);
                Nicknamebutton.setForeground(new Color(80, 80, 80)); // 텍스트 색상(흰색)
                Nicknamebutton.setBounds(420, 8, 50, 15);
                Nicknamebutton.setFont(contentFont);
                Postpanel.add(Nicknamebutton);

                
                if (LogID.equals("admin")) {
                    RoundedButton LimitButton = new RoundedButton("삭제");
                    LimitButton.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                            DeletePost deletePost = new DeletePost(BulletinID, LogID, Section, DarK);
                        	}
                    });
                    LimitButton.setBackground(colors.Text); // 배경색 설정 (검은색)
                    LimitButton.setForeground(colors.Ground); // 텍스트 색상(흰색)
                    LimitButton.setBounds(432, 35, 30, 15);
                    Postpanel.add(LimitButton);                   
                }
                
                COUNT++;
            }
        }
        JScrollPane scrollPane = new JScrollPane(panel_1);
        scrollPane.setBounds(0, 80, 526, 468); // JScrollPane의 위치 및 크기 설정
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        // 가로 스크롤바를 비활성화합니다.
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        // 세로 스크롤바의 UI 변경
        scrollPane.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = new Color(100, 100, 100); // 스크롤바 색상 설정
            }

            @Override
            protected JButton createDecreaseButton(int orientation) {
                return new JButton() {
                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension(0, 0); // 위 버튼 크기 0으로 설정하여 숨김
                    }
                };
            }

            @Override
            protected JButton createIncreaseButton(int orientation) {
                return new JButton() {
                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension(0, 0); // 아래 버튼 크기 0으로 설정하여 숨김
                    }
                };
            }

            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // 둥근 모양의 스크롤바
                g2.setColor(Color.LIGHT_GRAY); // 색상 변경
                g2.fillRoundRect(thumbBounds.x, thumbBounds.y, thumbBounds.width, thumbBounds.height, 10, 10);

                g2.dispose();
            }
        });
        scrollPane.setVisible(true);

        dialogPanel.add(scrollPane);
        // 다이얼로그 프레임에 패널 추가
        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }

}
