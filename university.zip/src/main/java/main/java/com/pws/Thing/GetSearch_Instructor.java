package main.java.com.pws.Thing;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GetSearch_Instructor {
    public List<String> searchInstructor(JSONObject json) {
        List<String> Instructors = new ArrayList<>();
        HttpURLConnection connection = null;

        try {
            String apiURL = "http://127.0.0.1:5000/search_Instructor";
            URL link = new URL(apiURL);
            connection = (HttpURLConnection) link.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");
            connection.setDoOutput(true);

            try (OutputStreamWriter wr = new OutputStreamWriter(connection.getOutputStream(), StandardCharsets.UTF_8)) {
                wr.write(json.toString());
                wr.flush();
            }
            
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    String returnMsg = response.toString();
                    System.out.println("서버 응답: " + returnMsg); // 서버 응답 출력

                    JSONObject jsonResponse = new JSONObject(returnMsg);
                    if (jsonResponse.has("result") && jsonResponse.getString("result").equals("Fail")) {
                        System.out.println("검색 결과가 없습니다.");
                    } else {
                        JSONArray InstructorArray = jsonResponse.getJSONArray("Instructors");
                        for (int i = 0; i < InstructorArray.length(); i++) {
                            JSONObject Instructor = InstructorArray.getJSONObject(i);
                            List<String> InstructorData = new ArrayList<>();
                            InstructorData.add(Instructor.getString("instructor_id"));
                            InstructorData.add(Instructor.getString("name"));
                            InstructorData.add(Instructor.getString("UID"));

                            Instructors = InstructorData;
                        }
                    }
                }
            } else {
                System.out.println("HTTP 응답 코드: " + responseCode);
            }

        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }

        return Instructors;
    }
}

