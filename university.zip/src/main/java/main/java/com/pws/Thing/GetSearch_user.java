package main.java.com.pws.Thing;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GetSearch_user {
    public List<String> searchusers(JSONObject json) {
        List<String> users = new ArrayList<>();
        HttpURLConnection connection = null;

        try {
            String apiURL = "http://127.0.0.1:5000/search_user";
            URL link = new URL(apiURL);
            connection = (HttpURLConnection) link.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");
            connection.setDoOutput(true);

            try (OutputStreamWriter wr = new OutputStreamWriter(connection.getOutputStream(), StandardCharsets.UTF_8)) {
                wr.write(json.toString());
                wr.flush();
            }
            
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    String returnMsg = response.toString();
                    System.out.println("서버 응답: " + returnMsg); // 서버 응답 출력

                    JSONObject jsonResponse = new JSONObject(returnMsg);
                    if (jsonResponse.has("result") && jsonResponse.getString("result").equals("Fail")) {
                        System.out.println("검색 결과가 없습니다.");
                    } else {
                        JSONArray userArray = jsonResponse.getJSONArray("users");
                        for (int i = 0; i < userArray.length(); i++) {
                            JSONObject user = userArray.getJSONObject(i);
                            List<String> userData = new ArrayList<>();
                            userData.add(user.getString("UserID"));
                            userData.add(user.getString("UserPW"));
                            userData.add(user.getString("UID"));
                            userData.add(user.getString("Nickname"));
                            userData.add(String.valueOf(user.getLong("LimitDate")));

                            users = userData;
                        }
                    }
                }
            } else {
                System.out.println("HTTP 응답 코드: " + responseCode);
            }

        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }

        return users;
    }
}

