package main.java.com.pws.Thing;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Insets;
import javax.swing.border.Border;

public class RoundedBorder2 implements Border {
    private int radius;
    private Color borderColor;  // 테두리 색상

    public RoundedBorder2(int radius, Color borderColor) {
        this.radius = radius;
        this.borderColor = borderColor;
    }

    @Override
    public Insets getBorderInsets(Component c) {
        return new Insets(this.radius + 1, this.radius + 1, this.radius + 2, this.radius + 1);
    }

    @Override
    public boolean isBorderOpaque() {
        return true;
    }

    @Override
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        g.setColor(borderColor);  // 테두리 색상 설정
        g.drawRoundRect(x, y, width - 1, height - 1, radius, radius);
    }
}
