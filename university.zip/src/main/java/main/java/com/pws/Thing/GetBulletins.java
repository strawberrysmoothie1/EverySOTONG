package main.java.com.pws.Thing;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GetBulletins {

    public List<List<String>> getAllBulletins() {
        HttpURLConnection connection = null;
        List<List<String>> bulletins = new ArrayList<>();

        try {
            String apiURL = "http://127.0.0.1:5000/get_all_bulletins";
            URL url = new URL(apiURL);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");

            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"))) {
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    String returnMsg = response.toString();
                    System.out.println("서버 응답: " + returnMsg); // 서버 응답 출력

                    if (!returnMsg.trim().isEmpty()) {
                        JSONObject jsonResponse = new JSONObject(returnMsg);
                        JSONArray bulletinsArray = jsonResponse.getJSONArray("bulletins");

                        for (int i = 0; i < bulletinsArray.length(); i++) {
                            JSONObject bulletin = bulletinsArray.getJSONObject(i);
                            List<String> bulletinData = new ArrayList<>();
                            bulletinData.add(String.valueOf(bulletin.getInt("BulletinID"))); // 정수를 문자열로 변환하여 추가
                            bulletinData.add(bulletin.getString("UserID"));
                            bulletinData.add(bulletin.getString("UID"));
                            bulletinData.add(bulletin.getString("BoardID"));
                            bulletinData.add(bulletin.getString("BulletinTitle"));
                            bulletinData.add(bulletin.getString("Bcontent"));
                            bulletinData.add(bulletin.getString("Bdate"));

                            bulletins.add(bulletinData);
                        }
                    } else {
                        System.out.println("서버 응답이 비어있습니다.");
                    }
                }
            } else {
                System.out.println("HTTP 응답 코드: " + responseCode);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return bulletins;
    }

}
