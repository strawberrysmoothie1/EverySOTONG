package main.java.com.pws.dialog;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import org.json.JSONObject;

import main.java.com.pws.Login.login;
import main.java.com.pws.Thing.FrameManager;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundPasswordField;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.RoundtextField;
import main.java.com.pws.Thing.TodayDate;
import main.java.com.pws.Thing.collor;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;

public class AddClass_Room {
    private String userIDD;
    private int DarK;


    public AddClass_Room(String userIDD, int DarK) {
        this.userIDD = userIDD;
        this.DarK = DarK;

        initialize();
    }

    private void initialize() {
        JSONObject data = new JSONObject();
        Post po = new Post();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }
        Border borderBlack = BorderFactory.createLineBorder(colors.Text, 1);
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(200, 270, 450, 450);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    	FrameManager.addFrame(dialogFrame);
        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setBounds(5, 0, 100, 100);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogFrame.add(dialogPanel);

        // 작성자 정보 라벨
        JLabel ChangePWLabel = new JLabel("강의실 추가");
        ChangePWLabel.setBounds(178, 11, 150, 30); // Adjust the position and size as needed
        ChangePWLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        Font ChangePWFont = new Font(ChangePWLabel.getFont().getName(), Font.BOLD, 16);
        ChangePWLabel.setFont(ChangePWFont);
        dialogPanel.add(ChangePWLabel);
  
        data.put("table", "users");
        data.put("want", "UID");
        data.put("what", "UserID");
        data.put("user_id", userIDD);
        JSONObject SearchUID1 = po.jsonpost("/find_user_information", data);
        String SearchUID = SearchUID1.getString("UID");
		String cutuniversity = SearchUID.substring(0, SearchUID.length() - 2);

	     // 학교아이디 라벨
        JLabel Class_room_IDLabel = new JLabel("강의실ID");
        Class_room_IDLabel.setBounds(125, 115, 150, 15); // Adjust the position and size as needed
        Class_room_IDLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        Font labelFont2 = new Font(Class_room_IDLabel.getFont().getName(), Font.BOLD, 9);
        Class_room_IDLabel.setFont(labelFont2);
        dialogPanel.add(Class_room_IDLabel);
        // 학교 아이디 입력 필드
        RoundtextField Class_Room_IDField = new RoundtextField();
        Class_Room_IDField.setBounds(120, 130, 200, 35);
        Class_Room_IDField.setBackground(colors.BoardPanel);
        Class_Room_IDField.setForeground(colors.Text);
        dialogPanel.add(Class_Room_IDField);
        Class_Room_IDField.setColumns(10);
        Class_Room_IDField.setBorder(borderBlack);
        Class_Room_IDField.setDefaultText("ex) "+cutuniversity + "001");

        JLabel univerLabel = new JLabel("");

        univerLabel.setForeground(new Color(0, 0, 255)); // Set label text color
        univerLabel.setFont(labelFont2);
        dialogPanel.add(univerLabel);

        // 학교 검색 버튼 (원래 중복 확인 기능은 여기에 넣어도 됨)
        RoundedButton searchButton = new RoundedButton("중복확인");
        searchButton.setBounds(319, 137, 50, 20);
        searchButton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        searchButton.setForeground(colors.Text); // 텍스트 색상(흰색)
        Font searchFont = new Font(searchButton.getFont().getName(), Font.PLAIN, 10);
        searchButton.setFont(searchFont);
        dialogPanel.add(searchButton); // 패널에 버튼 추가
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String NewRoomID = Class_Room_IDField.getText();
                // 여기서 데이터베이스 조회하여 중복 여부 확인
                data.put("where", "room_id");
                data.put("what", NewRoomID);
                Post po = new Post();
				JSONObject nickDuplicate = po.jsonpost("/check_Room_exists", data);
				boolean nickDuplicate1;
				nickDuplicate1 = nickDuplicate.getBoolean("exists");
				
                if (nickDuplicate1) {
                    univerLabel.setText("이미 사용중인 아이디 입니다.");
                    univerLabel.setForeground(new Color(255, 0, 0));
                    univerLabel.setBounds(162, 168, 150, 15);
                } else {
                	univerLabel.setText("사용가능한 아이디 입니다.");
                    univerLabel.setForeground(new Color(0, 0, 255));
                    univerLabel.setBounds(162, 168, 150, 15);
                }
            }
        });
            

        // 건물 라벨
        JLabel BuildingLabel = new JLabel("건물");
        BuildingLabel.setBounds(125, 180, 150, 15); // Adjust the position and size as needed
        BuildingLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        BuildingLabel.setFont(labelFont2);
        dialogPanel.add(BuildingLabel);


        // 건물 입력 필드
        RoundtextField BuildingField = new RoundtextField();
        BuildingField.setBounds(120, 195, 200, 35);
        BuildingField.setBackground(colors.BoardPanel);
        BuildingField.setForeground(colors.Text);
        dialogPanel.add(BuildingField);
        BuildingField.setColumns(10);
        BuildingField.setBorder(borderBlack);
        BuildingField.setDefaultText("건물 입력");
        
        // 강의실 라벨
        JLabel NumberLabel = new JLabel("강의실");
        NumberLabel.setBounds(125, 245, 150, 15); // Adjust the position and size as needed
        NumberLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        NumberLabel.setFont(labelFont2);
        dialogPanel.add(NumberLabel);

        // 강의실 입력 필드
        RoundtextField NumberField = new RoundtextField();
        NumberField.setBounds(120, 260, 200, 35);
        NumberField.setBackground(colors.BoardPanel);
        NumberField.setForeground(colors.Text);
        dialogPanel.add(NumberField);
        NumberField.setColumns(10);
        NumberField.setBorder(borderBlack);
        NumberField.setDefaultText("강의실 번호 입력");

        //  버튼
        RoundedButton OKButton = new RoundedButton("추가");
        OKButton.setBounds(183, 317, 65, 20);
        OKButton.setBackground(new Color(255, 0, 0));// 배경색 설정 (빨간색)
        OKButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        dialogPanel.add(OKButton); // 패널에 버튼 추가

        JLabel OKLabel = new JLabel("");
        OKLabel.setFont(labelFont2);
        dialogPanel.add(OKLabel);

        // 회원가입 버튼에 ActionListener 추가
        OKButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String NewClassID = Class_Room_IDField.getText();
                String NewBuilding = BuildingField.getText();
                String NewNumber = NumberField.getText();

                // 에러 메시지 라벨 초기화
                OKLabel.setText("");

                    // 아이디 중복 확인
                    data.put("where", "room_id");
                    data.put("what", NewClassID);
    				JSONObject isDuplicate = po.jsonpost("/check_Room_exists", data);
    				boolean isDuplicate1;
    				isDuplicate1 = isDuplicate.getBoolean("exists");

                    // 모든 조건이 충족되면 회원가입 성공
                    if (!isDuplicate1) {
                        // 여기에 회원가입 로직을 추가하면 됩니다.
                        data.put("room_id", NewClassID);
                        data.put("building", NewBuilding);
                        data.put("room_number", NewNumber);
        				JSONObject change_check = po.jsonpost("/register_Room", data);
        				boolean success = change_check.getBoolean("success"); 
        				System.out.println("강의실추가 성공 여부: " + success);
                        // 회원가입 성공 다이얼로그 표시
                        showSuccessDialog();
                    } else {
                        OKLabel.setText("아이디를 확인해 주세요.");
                        OKLabel.setForeground(new Color(255, 0, 0));
                        OKLabel.setBounds(165, 350, 250, 15);
                    }
                
            }
        });
        
        
        
        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
  
    private void showSuccessDialog() {
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(31, 31, 31);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(70, 70, 70);
            colors.buttonBackground = new Color(50, 50, 50);
            colors.postbuttonColor = new Color(40, 40, 40);
            colors.RedText = new Color(200, 100, 100);
        }

        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(270, 400, 300, 150);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null); 

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 276, 110);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255), 1)); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel dialogLabel = new JLabel("추가 성공!");
        dialogLabel.setBounds(115, 30, 200, 35);
        dialogLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
        dialogPanel.add(dialogLabel);

        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("확인");
        confirmButton.setBounds(110, 80, 65, 20);
        confirmButton.setBackground(new Color(120, 120, 120));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialogFrame.dispose();
                FrameManager.closeAllFrames(); // 모든 프레임 닫기
            	Class_RoomList Class_RoomDialog = new Class_RoomList(userIDD, DarK);
            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
}
