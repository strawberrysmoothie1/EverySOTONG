package main.java.com.pws.Thing;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONException;
import org.json.JSONObject;

public class Post {

    public JSONObject jsonpost(String url, JSONObject json) {
        HttpURLConnection connection = null;
        try {
            String apiURL = "http://127.0.0.1:5000" + url;
            URL link = new URL(apiURL);
            connection = (HttpURLConnection) link.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");
            connection.setDoOutput(true);

            try (OutputStreamWriter wr = new OutputStreamWriter(connection.getOutputStream(), "UTF-8")) {
                wr.write(json.toString());
                wr.flush();
            }

            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"))) {
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    String returnMsg = response.toString();
                    System.out.println("서버 응답: " + returnMsg); // 서버 응답 출력

                    if (!returnMsg.trim().isEmpty()) {
                        return new JSONObject(returnMsg);
                    } else {
                        System.out.println("서버 응답이 비어있습니다.");
                    }
                }
            } else {
                System.out.println("HTTP 응답 코드: " + responseCode);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // 오류 발생 시 기본적으로 반환할 JSON 객체
        JSONObject result = new JSONObject();
        try {
            result.put("check", "false");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return result;
    }
}


