package main.java.com.pws.Thing;

import java.awt.Color;

public class collor {

	public Color Ground;
	public Color Text;
	public Color buttonBackground;
    public Color BoardPanel;
    public Color postbuttonColor;
	public Color RedText;
	public Color BlackText;
	public Color ToggleBtn;


    
    public collor() {
    	
    	BlackText = new Color(0, 0, 0);
    	RedText = new Color(0, 0, 0);
    	Ground = new Color(250, 250, 250);
    	Text = new Color(0, 0, 0);
	    BoardPanel = new Color(200, 200, 200);
	    buttonBackground = new Color(255, 255, 255);
	    postbuttonColor = new Color(255, 255, 255);
	    ToggleBtn = new Color(200, 200, 200);

    }
}
