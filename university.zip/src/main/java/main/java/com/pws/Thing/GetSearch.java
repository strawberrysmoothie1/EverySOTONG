package main.java.com.pws.Thing;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GetSearch {
    public List<List<String>> searchBulletins(JSONObject json) {
        List<List<String>> bulletins = new ArrayList<>();
        HttpURLConnection connection = null;

        try {
            String apiURL = "http://127.0.0.1:5000/search";
            URL link = new URL(apiURL);
            connection = (HttpURLConnection) link.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");
            connection.setDoOutput(true);

            try (OutputStreamWriter wr = new OutputStreamWriter(connection.getOutputStream(), StandardCharsets.UTF_8)) {
                wr.write(json.toString());
                wr.flush();
            }
            
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    String returnMsg = response.toString();
                    System.out.println("서버 응답: " + returnMsg); // 서버 응답 출력

                    JSONObject jsonResponse = new JSONObject(returnMsg);
                    JSONArray bulletinArray = jsonResponse.getJSONArray("bulletins");
                    for (int i = 0; i < bulletinArray.length(); i++) {
                        JSONObject bulletin = bulletinArray.getJSONObject(i);
                        List<String> bulletinData = new ArrayList<>();
                        bulletinData.add(String.valueOf(bulletin.getInt("BulletinID"))); // 정수 값을 문자열로 변환
                        bulletinData.add(bulletin.getString("UserID"));
                        bulletinData.add(bulletin.getString("UID"));
                        bulletinData.add(bulletin.getString("BoardID"));
                        bulletinData.add(bulletin.getString("BulletinTitle"));
                        bulletinData.add(bulletin.getString("Bcontent"));
                        bulletinData.add(bulletin.getString("Bdate"));

                        bulletins.add(bulletinData);
                    }
                }
            } else {
                System.out.println("HTTP 응답 코드: " + responseCode);
            }

        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }

        return bulletins;
    }
}

