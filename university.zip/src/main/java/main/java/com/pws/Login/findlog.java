package main.java.com.pws.Login;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

import org.json.JSONObject;

import main.java.com.pws.Thing.RoundPasswordField;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundtextField;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.RoundedBorder;

public class findlog {

    private JFrame frame;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    login window = new login();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public findlog() {
        initialize();
    }


    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
    	JSONObject data = new JSONObject();
    	
        frame = new JFrame();
        frame.setBounds(100, 100, 650, 800); // 프레임 위치 및 크기 설정
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // 닫기 버튼 동작 설정
        frame.getContentPane().setLayout(null); // 레이아웃 설정 (null은 절대 위치 배치)

        Border borderBlack = BorderFactory.createLineBorder(new Color(0, 0, 0), 2);

        // 테두리 스타일 설정
        Border border = BorderFactory.createLineBorder(new Color(255, 0, 0), 2);

        JPanel panel = new JPanel();
        panel.setBounds(5, 0, 625, 755);
        frame.getContentPane().add(panel);
        panel.setLayout(null);
        panel.setBackground(new Color(255, 255, 255)); // 배경색 설정

        // 아이디 찾기
        JButton FindIDButton = new JButton("아이디 찾기"); // 버튼 생성 및 텍스트 설정
        FindIDButton.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                findlog log = new findlog(); // abc 클래스의 생성자 호출 수정
                log.showFrame();
                frame.dispose();
            }
        });
        FindIDButton.setBounds(170, 100, 130, 20); // 버튼 위치 및 크기 설정
        FindIDButton.setBackground(new Color(255, 255, 255));// 배경색 설정 (빨간색)
        FindIDButton.setForeground(new Color(255, 0, 0)); // 텍스트 색상(흰색)
        Font FindIDFont = new Font(FindIDButton.getFont().getName(), Font.BOLD, 20);
        FindIDButton.setFont(FindIDFont);
        FindIDButton.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        panel.add(FindIDButton); // 패널에 버튼 추가

        // 비밀번호 찾기
        JButton FindPWButton = new JButton("비밀번호 찾기"); // 버튼 생성 및 텍스트 설정
        FindPWButton.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                findPW log = new findPW(); // abc 클래스의 생성자 호출 수정
                log.showFrame();
                frame.dispose();
            }
        });
        FindPWButton.setBounds(300, 100, 150, 20); // 버튼 위치 및 크기 설정
        FindPWButton.setBackground(new Color(255, 255, 255));// 배경색 설정 (빨간색)
        FindPWButton.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
        FindPWButton.setFont(FindIDFont);
        FindPWButton.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        FindPWButton.setContentAreaFilled(false);
        FindPWButton.setFocusPainted(false);
        FindPWButton.setOpaque(true);
        panel.add(FindPWButton); // 패널에 버튼 추가

        // 둥근 페널
        JPanel roundedPanel = new JPanel();
        roundedPanel.setBackground(new Color(255, 255, 255));
        roundedPanel.setBounds(70, 150, 480, 420);
        panel.add(roundedPanel);
        roundedPanel.setLayout(null);
        roundedPanel.setBorder(border); // 테두리 설정
        RoundedBorder roundedBorder = new RoundedBorder(20);
        roundedPanel.setBorder(roundedBorder);

        // 별명 라벨
        JLabel NicknameLabel = new JLabel("별명");
        NicknameLabel.setBounds(145, 85, 150, 15); // Adjust the position and size as needed
        NicknameLabel.setForeground(new Color(100, 100, 100)); // Set label text color
        Font labelFont2 = new Font(NicknameLabel.getFont().getName(), Font.BOLD, 9);
        NicknameLabel.setFont(labelFont2);
        roundedPanel.add(NicknameLabel);
        // 중복 라벨
        JLabel duplicationLabel = new JLabel("");
        duplicationLabel.setBounds(190, 138, 150, 15); // Adjust the position and size as needed
        duplicationLabel.setForeground(new Color(0, 0, 255)); // Set label text color
        duplicationLabel.setFont(labelFont2);
        roundedPanel.add(duplicationLabel);

        // 별명 입력 필드
        RoundtextField NicknameField = new RoundtextField();
        NicknameField.setBounds(140, 100, 200, 35);
        NicknameField.setBackground(new Color(200, 200, 200));
        NicknameField.setForeground(new Color(255, 255, 255));
        roundedPanel.add(NicknameField);
        NicknameField.setColumns(10);
        NicknameField.setBorder(borderBlack);
        NicknameField.setDefaultText("  별명");
        // 확인 버튼
        RoundedButton checkDuplicationButton = new RoundedButton("확인");
        checkDuplicationButton.setBounds(339, 107, 50, 20);
        Font checkFont = new Font(checkDuplicationButton.getFont().getName(), Font.PLAIN, 10);
        checkDuplicationButton.setFont(checkFont);
        checkDuplicationButton.setBackground(new Color(255, 255, 255));// 배경색 설정 (빨간색)
        checkDuplicationButton.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        roundedPanel.add(checkDuplicationButton); // 패널에 버튼 추가
        checkDuplicationButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String enteredNickname = NicknameField.getText();
                // 여기서 데이터베이스 조회하여 중복 여부 확인
                data.put("where", "Nickname");
                data.put("what", enteredNickname);
                Post po = new Post();
				JSONObject isDuplicate = po.jsonpost("/check_id_exists", data);
				boolean isDuplicate1;
				isDuplicate1 = isDuplicate.getBoolean("exists");
                if (isDuplicate1) {
                    duplicationLabel.setText("별명이 존재 합니다.");
                    duplicationLabel.setForeground(new Color(0, 0, 255));
                } else {
                    duplicationLabel.setText("별명이 존재하지 않습니다.");
                    duplicationLabel.setForeground(new Color(255, 0, 0));
                }
            }
        });

        // 학교아이디 라벨
        JLabel universityLabel = new JLabel("학교 학과 코드");
        universityLabel.setBounds(145, 160, 150, 15); // Adjust the position and size as needed
        universityLabel.setForeground(new Color(100, 100, 100)); // Set label text color
        universityLabel.setFont(labelFont2);
        roundedPanel.add(universityLabel);
        // 학교 아이디 입력 필드
        RoundtextField universityField = new RoundtextField();
        universityField.setBounds(140, 175, 200, 35);
        universityField.setBackground(new Color(200, 200, 200));
        universityField.setForeground(new Color(255, 255, 255));
        roundedPanel.add(universityField);
        universityField.setColumns(10);
        universityField.setBorder(borderBlack);
        universityField.setDefaultText("  ex)12301");

        JLabel univerLabel = new JLabel("");

        univerLabel.setForeground(new Color(0, 0, 255)); // Set label text color
        univerLabel.setFont(labelFont2);
        roundedPanel.add(univerLabel);

        // 학교 검색 버튼 (원래 중복 확인 기능은 여기에 넣어도 됨)
        RoundedButton searchButton = new RoundedButton("확인");
        searchButton.setBounds(339, 183, 50, 20);
        searchButton.setBackground(new Color(255, 255, 255));// 배경색 설정 (빨간색)
        searchButton.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        Font searchFont = new Font(searchButton.getFont().getName(), Font.PLAIN, 10);
        searchButton.setFont(searchFont);
        roundedPanel.add(searchButton); // 패널에 버튼 추가
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
	
            	String enteredNickname = NicknameField.getText();
                // 여기서 데이터베이스 조회하여 중복 여부 확인
                data.put("where", "Nickname");
                data.put("what", enteredNickname);
                Post po = new Post();
 				JSONObject isDuplicate = po.jsonpost("/check_id_exists", data);
 				boolean isDuplicate1;
 				isDuplicate1 = isDuplicate.getBoolean("exists");
            	
                if (isDuplicate1 == false) {
                	univerLabel.setText("별명을 확인해 주세요.");
                	univerLabel.setForeground(new Color(255, 0, 0));
                	univerLabel.setBounds(187, 215, 170, 15);
                } else {
	                String schoolcode = universityField.getText();
	                // 여기서 데이터베이스 조회하여 중복 여부 확인
	                data.put("what", schoolcode);
					JSONObject universityInfo = po.jsonpost("/get_university_info", data);
					String getUName = universityInfo.getString("uName");  
					String getDepartment = universityInfo.getString("department"); 

	                data.put("table", "users");
	                data.put("want", "UID");
	                data.put("what", "Nickname");
	                data.put("user_id", enteredNickname);
                	JSONObject SearchUID = po.jsonpost("/find_user_information", data);
                		String SearchUID1 = SearchUID.getString("UID");
				
                
					if (SearchUID1.equals(schoolcode)) {
                		univerLabel.setText(getUName + "-" + getDepartment);
                    	univerLabel.setForeground(new Color(0, 0, 255));
                    	univerLabel.setBounds(187, 215, 150, 15);
                	} else if (universityInfo != null) {
                		univerLabel.setText("입력한 별명과 학교정보가 다릅니다.");
                    	univerLabel.setForeground(new Color(255, 0, 0));
                    	univerLabel.setBounds(165, 215, 170, 15);
                	} else {
                		univerLabel.setText("학교 정보를 찾을 수 없습니다.");
                    	univerLabel.setForeground(new Color(255, 0, 0));
                    	univerLabel.setBounds(182, 215, 150, 15);
                	}
                }
            }

        });

        // 비밀번호 라벨
        JLabel usePWLabel = new JLabel("비밀번호");
        usePWLabel.setBounds(145, 235, 150, 15); // Adjust the position and size as needed
        usePWLabel.setForeground(new Color(100, 100, 100)); // Set label text color
        usePWLabel.setFont(labelFont2);
        roundedPanel.add(usePWLabel);

        // 비밀번호 입력 필드
        RoundPasswordField usePWField = new RoundPasswordField();
        usePWField.setBounds(140, 250, 200, 35);
        usePWField.setBackground(new Color(200, 200, 200));
        usePWField.setForeground(new Color(255, 255, 255));
        roundedPanel.add(usePWField);
        usePWField.setColumns(10);
        usePWField.setBorder(borderBlack);
 
        // 비밀번호 일치 여부를 표시하는 라벨
        JLabel passwordMatchLabel = new JLabel("");
        passwordMatchLabel.setFont(labelFont2);
        roundedPanel.add(passwordMatchLabel);

        // 확인 버튼
        RoundedButton checkPWButton = new RoundedButton("확인");
        checkPWButton.setBounds(339, 257, 50, 20);
        checkPWButton.setFont(checkFont);
        checkPWButton.setBackground(new Color(255, 255, 255));// 배경색 설정 (빨간색)
        checkPWButton.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        roundedPanel.add(checkPWButton); // 패널에 버튼 추가
        checkPWButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String enteredPW = usePWField.getText();
                String enteredNick = NicknameField.getText();            
            	String enteredNickname = NicknameField.getText();
                // 여기서 데이터베이스 조회하여 중복 여부 확인
                data.put("where", "Nickname");
                data.put("what", enteredNickname);
                Post po = new Post();
 				JSONObject isDuplicate = po.jsonpost("/check_id_exists", data);
 				boolean isDuplicate1;
 				isDuplicate1 = isDuplicate.getBoolean("exists");
            	
                if (isDuplicate1 == false) {
                	univerLabel.setText("별명을 확인해 주세요.");
                	univerLabel.setForeground(new Color(255, 0, 0));
                	univerLabel.setBounds(187, 290, 170, 15);
                } else {	                	
	                data.put("table", "users");
	                data.put("want", "UserPW");
	                data.put("what", "Nickname");
	                data.put("user_id", enteredNick);
					JSONObject isDuplicatePW = po.jsonpost("/find_user_information", data);
					String isDuplicatePW1 = isDuplicatePW.getString("UserPW");
	                
	                if (isDuplicatePW1.equals(enteredPW)) {
	                    passwordMatchLabel.setText("비밀번호가 일치합니다");
	                    passwordMatchLabel.setForeground(new Color(0, 0, 255));
	                    passwordMatchLabel.setBounds(180, 290, 170, 15);
	
	                } else {
	                    passwordMatchLabel.setText("비밀번호가 일치하지 않습니다");
	                    passwordMatchLabel.setForeground(new Color(255, 0, 0));
	                    passwordMatchLabel.setBounds(165, 290, 170, 15);
	
	                }
	            }
            }
        });

        // 찾기 버튼
        RoundedButton OKButton = new RoundedButton("찾기");
        OKButton.setBounds(208, 340, 65, 20);
        OKButton.setBackground(new Color(255, 0, 0));// 배경색 설정 (빨간색)
        OKButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        roundedPanel.add(OKButton); // 패널에 버튼 추가

        JLabel OKLabel = new JLabel("");
        OKLabel.setFont(labelFont2);
        roundedPanel.add(OKLabel);

        // 찾기 버튼에 ActionListener 추가
        OKButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // 입력된 값들 가져오기
                String schoolcode = universityField.getText();
                String enteredNickname = NicknameField.getText();
                String password1 = usePWField.getText();
                // 여기서 데이터베이스 조회하여 중복 여부 확인
                data.put("where", "Nickname");
                data.put("what", enteredNickname);
                Post po = new Post();
 				JSONObject isDuplicate = po.jsonpost("/check_id_exists", data);
 				boolean isDuplicate1;
 				isDuplicate1 = isDuplicate.getBoolean("exists");
            	
                if (isDuplicate1 == false) {
                	univerLabel.setText("별명을 확인해 주세요.");
                	univerLabel.setForeground(new Color(255, 0, 0));
                	univerLabel.setBounds(191, 370, 170, 15);
                } else {
	                data.put("table", "users");
	                data.put("want", "UserPW");
	                data.put("what", "Nickname");
	                data.put("user_id", enteredNickname);
					JSONObject isDuplicatePW = po.jsonpost("/find_user_information", data);
					String isDuplicatePW1 = isDuplicatePW.getString("UserPW");
	                           
	                // 학교 정보 조회
	                //String isDuplicateUID = DBConnection.FindUserInformation("users", "UID", "Nickname", enteredNickname);
	                data.put("table", "users");
	                data.put("want", "UID");
	                data.put("what", "Nickname");
	                data.put("user_id", enteredNickname);
					JSONObject isDuplicateUID = po.jsonpost("/find_user_information", data);
					String isDuplicateUID1 = isDuplicateUID.getString("UID");                             
	                
	               // boolean isDuplicateNick = DBConnection.checkIfIDExists("Nickname", enteredNickname);
	                data.put("where", "Nickname");
	                data.put("what", enteredNickname);
					JSONObject isDuplicateNick = po.jsonpost("/check_id_exists", data);
					boolean isDuplicateNick1;
					isDuplicateNick1 = isDuplicateNick.getBoolean("exists");
	                // 에러 메시지 라벨 초기화
	                OKLabel.setText("");
	
	                // 별명 에러 메시지 출력
	                if (!isDuplicateNick1) {
	                    OKLabel.setText("별명을 확인해 주세요.");
	                    OKLabel.setForeground(new Color(255, 0, 0));
	                    OKLabel.setBounds(193, 370, 250, 15);
	                } else {
	
	                    // 학교코드 에러 메시지 출력
	                    if (!isDuplicateUID1.equals(schoolcode)) {
	                        OKLabel.setText("학교 학과 코드를 확인해 주세요.");
	                        OKLabel.setForeground(new Color(255, 0, 0));
	                        OKLabel.setBounds(172, 370, 250, 15);
	                    }
	
	                    // 비밀번호 확인
	                    // 비밀번호 관련 에러 메시지 출력
	                    if (!isDuplicatePW1.equals(password1)) {
	                        OKLabel.setText("비밀번호를 확인해 주세요.");
	                        OKLabel.setForeground(new Color(255, 0, 0));
	                        OKLabel.setBounds(185, 370, 250, 15);
	                    }
	
	                    // 모든 조건이 충족되면 회원가입 성공
	                    if (isDuplicateUID1.equals(schoolcode) && isDuplicatePW1.equals(password1)) {
	
	                        data.put("table", "users");
	                        data.put("want", "UserID");
	                        data.put("what", "Nickname");
	                        data.put("user_id", enteredNickname);
	        				JSONObject SearchUsrID = po.jsonpost("/find_user_information", data);
	        				String SearchUsrID1 = SearchUsrID.getString("UserID");   
	                        showSuccessDialog(SearchUsrID1);
	
	                    }
	                }
	            }
            }
        });

        // 뒤로가기 버튼
        JButton BackButton = new JButton("뒤로가기"); // 버튼 생성 및 텍스트 설정
        BackButton.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                login log = new login(); 
                log.showFrame();
                frame.dispose();
            }
        });
        BackButton.setBounds(530, 30, 90, 30); // 버튼 위치 및 크기 설정
        BackButton.setBackground(new Color(255, 255, 255));// 배경색 설정 (빨간색)
        BackButton.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        panel.add(BackButton); // 패널에 버튼 추가
        Font memberbuttonFont = new Font(BackButton.getFont().getName(), Font.BOLD, 12);
        BackButton.setFont(memberbuttonFont);
        BackButton.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        BackButton.setContentAreaFilled(false);
        BackButton.setFocusPainted(false);
        BackButton.setOpaque(true);

    }

    public void showFrame() {
        frame.setVisible(true);
    }

    private void showSuccessDialog(String FindID) {
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(270, 400, 300, 170);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 276, 130);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(new Color(255, 255, 255)); // 배경색 설정
        dialogPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255), 1)); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel SuccessLabel = new JLabel("아이디 찾기 성공!");
        SuccessLabel.setBounds(97, 20, 200, 15);
        SuccessLabel.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        Font SuccessFont = new Font(SuccessLabel.getFont().getName(), Font.BOLD, 12);
        SuccessLabel.setFont(SuccessFont);
        dialogPanel.add(SuccessLabel);

        // 다이얼로그 라벨 생성
        JLabel dialogLabel = new JLabel(FindID);
        dialogLabel.setBounds(120, 50, 200, 35);
        dialogLabel.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        dialogPanel.add(dialogLabel);

        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("확인");
        confirmButton.setBounds(110, 100, 65, 20);
        confirmButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                login l = new login();
                l.showFrame();
                dialogFrame.dispose();
            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }

}
