package main.java.com.pws.Board;

import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.RenderingHints;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.Border;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.plaf.basic.BasicScrollBarUI;

import org.json.JSONObject;

import main.java.com.pws.Login.login;
import main.java.com.pws.Schedule.schedule;
import main.java.com.pws.Thing.FrameManager;
import main.java.com.pws.Thing.GetBulletins;
import main.java.com.pws.Thing.GetUsers;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.User.mypage;
import main.java.com.pws.dialog.DeletePost;
import main.java.com.pws.dialog.Schoolchange;
import main.java.com.pws.dialog.UserInfo;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.RoundedBorder;
import main.java.com.pws.Thing.RoundtextField;
import main.java.com.pws.Thing.TodayDate;
import main.java.com.pws.Thing.collor;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



public class freeboardclass {
	private String userIDD;
    private String boardID;
    private String Section;
    private int DarK;

    JFrame frame;

    /**
     * 어플리케이션 실행 메소드
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    login window = new login();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * 어플리케이션 생성자
     */
    public freeboardclass(String userIDD, String boardID, String Section, int DarK) {
        this.userIDD = userIDD;
        this.boardID = boardID;
        this.Section = Section;
        this.DarK = DarK;

        initialize();
    }

    /**
     * 프레임 내용 초기화 메소드
     */
    private void initialize() {
    	JSONObject data = new JSONObject();
        TodayDate todayDate = new TodayDate();
        
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }


        frame = new JFrame();
        frame.setBounds(100, 100, 650, 800); // 프레임 위치 및 크기 설정
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // 닫기 버튼 동작 설정
        frame.getContentPane().setLayout(null);

    	FrameManager.addFrame(frame);
    	
        // 테두리 스타일 설정
        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        Border borderBlack = BorderFactory.createLineBorder(new Color(0, 0, 0), 1);

        JPanel panel = new JPanel();
        panel.setBounds(5, 0, 625, 755);
        frame.getContentPane().add(panel);
        panel.setLayout(null);
        panel.setBackground(colors.Ground); // 배경색 설정

        // 에브리소통 그림2
        String everyTimeIMG = "src/img/everygood.png";
        if(DarK == 1) {
        	everyTimeIMG = "src/img/everygoodDark.png";
        }
        ImageIcon everyImageIcon = new ImageIcon(everyTimeIMG);
        Image everyImage = everyImageIcon.getImage();
        Image every1Image = everyImage.getScaledInstance(120, 30, Image.SCALE_SMOOTH);
        ImageIcon every1ImageIcon = new ImageIcon(every1Image);
        JButton image1Button = new JButton(every1ImageIcon);
        image1Button.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        image1Button.setBounds(30, 40, 120, 30);
        image1Button.setBorder(borderWhite);
        image1Button.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                boardclass b = new boardclass(userIDD, Section, DarK);
                b.showFrame();
                frame.dispose();
            }
        });
        panel.add(image1Button);

        // 게시판 버튼
        JButton btnClickMe = new JButton("게시판"); // 버튼 생성 및 텍스트 설정
        btnClickMe.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                boardclass b = new boardclass(userIDD, Section, DarK); 
                b.showFrame();
                frame.dispose();
            }
        });
        btnClickMe.setBounds(210, 32, 100, 45); // 버튼 위치 및 크기 설정
        btnClickMe.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        btnClickMe.setForeground(colors.Text); // 텍스트 색상(흰색)
        panel.add(btnClickMe); // 패널에 버튼 추가
        Font buttonFont = new Font(btnClickMe.getFont().getName(), Font.BOLD, 18);
        btnClickMe.setFont(buttonFont);
        btnClickMe.setBorder(borderWhite); // 테두리 설정
        btnClickMe.setContentAreaFilled(false);
        btnClickMe.setFocusPainted(false);
        btnClickMe.setOpaque(true);

        // 시간표 버튼
        JButton Schedule = new JButton("시간표"); // 버튼 생성 및 텍스트 설정
        Schedule.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                schedule a = new schedule(userIDD, Section, DarK); 
                a.showFrame();
                frame.dispose();
            }
        });
        Schedule.setBounds(320, 32, 100, 45); // 버튼 위치 및 크기 설정
        Schedule.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        Schedule.setForeground(colors.Text); // 텍스트 색상(흰색)
        panel.add(Schedule); // 패널에 버튼 추가
        Font ScheduleFont = new Font(Schedule.getFont().getName(), Font.PLAIN, 18);
        Schedule.setFont(ScheduleFont);
        Schedule.setBorder(borderWhite); // 테두리 설정
        Schedule.setContentAreaFilled(false);
        Schedule.setFocusPainted(false);
        Schedule.setOpaque(true);

        // 회원 버튼
        JButton member = new JButton("설정"); // 버튼 생성 및 텍스트 설정
        member.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                mypage my = new mypage(userIDD, Section, DarK);
                my.showFrame();
                frame.dispose();
            }
        });
        member.setBounds(530, 30, 70, 30); // 버튼 위치 및 크기 설정
        member.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        member.setForeground(colors.Text); // 텍스트 색상(흰색)
        panel.add(member); // 패널에 버튼 추가
        Font memberbuttonFont = new Font(member.getFont().getName(), Font.BOLD, 12);
        member.setFont(memberbuttonFont);
        member.setBorder(borderWhite); // 테두리 설정
        member.setContentAreaFilled(false);
        member.setFocusPainted(false);
        member.setOpaque(true);

        Font contentFont = new Font(member.getFont().getName(), Font.BOLD, 10);

        
        data.put("table", "board");
        data.put("want", "BoardName");
        data.put("what", "BoardID");
        data.put("user_id", boardID);
        Post po = new Post();
    	JSONObject SearchBoardname1 = po.jsonpost("/find_user_information", data);
    	String SearchBoardname = SearchBoardname1.getString("BoardName");
    		
        // 게시판 라벨
        JLabel BoardnameLabel = new JLabel(SearchBoardname);
        BoardnameLabel.setBounds(253, 95, 150, 30); // Adjust the position and size as needed
        BoardnameLabel.setForeground(new Color(100, 100, 100)); // Set label text color
        Font labelFont2 = new Font(BoardnameLabel.getFont().getName(), Font.BOLD, 22);
        BoardnameLabel.setFont(labelFont2);
        panel.add(BoardnameLabel);

        Font TimeFont = new Font(BoardnameLabel.getFont().getName(), Font.BOLD, 8);

        // 글쓰기 버튼
        RoundedButton writePostbutton = new RoundedButton("글쓰기");
        writePostbutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // DBConnection.ChangeUser("users", "UserID", userIDD, "LimitDate", "20240801");           	
                data.put("table", "users");
                data.put("want", "LimitDate");
                data.put("what", "UserID");
                data.put("user_id", userIDD);
                Post po = new Post();
            	JSONObject SearchBdate1 = po.jsonpost("/find_user_information", data);
            	long SearchBdate = SearchBdate1.getLong("LimitDate");
                long NowDateTime = todayDate.TodayDate();
                if (NowDateTime > SearchBdate) {
                    NewPostDialog();

                } else {
                    LimitDialog(userIDD);
                }
                // NewPostDialog();
            }
        });
        writePostbutton.setBackground(new Color(200, 50, 50));// 배경색 설정 (빨간색)
        writePostbutton.setForeground(colors.Ground); // 텍스트 색상(흰색)
        writePostbutton.setBounds(470, 105, 70, 25);
        Font RedFont = new Font(writePostbutton.getFont().getName(), Font.BOLD, 13);
        writePostbutton.setFont(RedFont);
        panel.add(writePostbutton);
        
        //관리자 학교변경
        if (userIDD.equals("admin")){
            RoundedButton AdChangeUbutton = new RoundedButton("학교 변경");
            AdChangeUbutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	Schoolchange schoolDialog = new Schoolchange(userIDD, frame, Section, DarK);
                }
            });
            AdChangeUbutton.setBackground(new Color(200, 100, 100));// 배경색 설정 (빨간색)
            AdChangeUbutton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
            AdChangeUbutton.setBounds(470, 70, 70, 20);
            panel.add(AdChangeUbutton);
        }
    
        data.put("table", "users");
        data.put("want", "UID");
        data.put("what", "UserID");
        data.put("user_id", userIDD);
    	JSONObject UserUID1 = po.jsonpost("/find_user_information", data);
    	String UserUID = UserUID1.getString("UID");
    	
        String cutUserUIDD = UserUID.substring(0, UserUID.length() - 2);
        
        data.put("table", "bulletin");
        data.put("want", "BoardID");
        data.put("boardID", boardID);
    	JSONObject SearchCount1 = po.jsonpost("/board_find_post_id", data);
    	int SearchCount = SearchCount1.getInt("count");
        
        // 패널 생성
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(colors.Ground);
        int hight = 615;
        if (SearchCount > 9) {
            hight = 5 + 62 * SearchCount;
        }
        panel_1.setBounds(73, 140, 480, hight);
        panel.add(panel_1);
        panel_1.setLayout(null);
        panel_1.setBorder(borderWhite); // 테두리 설정
        RoundedBorder roundedBorder = new RoundedBorder(20);
        panel_1.setPreferredSize(new Dimension(480, hight));
        
        GetUsers  getUsers  = new GetUsers ();
        List<List<String>> users = getUsers.getAllUsers();

        GetBulletins getBulletins = new GetBulletins();
        List<List<String>> bulletins = getBulletins.getAllBulletins();
        
        Map<String, String> userMap = new HashMap<>();
        for (List<String> user : users) {
            String userID = user.get(0);
            String nickname = user.get(3);
            userMap.put(userID, nickname);
        }

        int COUNT = 0;

        for (int a = bulletins.size() - 1; a >= 0; a--) {

            String ShowTitle = null;
            String ShowContent = null;
            String ShowNicname = null;
            List<String> bulletin = bulletins.get(a);

            String BulletinID = bulletin.get(0);
            String SearchBoardID = bulletin.get(3);
            String SearchTitle = bulletin.get(4);
            String SearchContent = bulletin.get(5);
            long SearchBdate = Long.parseLong(bulletin.get(6));
            String SearchUser = bulletin.get(1);
            String bulletinUIDD = bulletin.get(2);
            String cutUIDD = bulletinUIDD.substring(0, bulletinUIDD.length() - 2);
            
            
            String SearchNickname = userMap.get(SearchUser);
            
            if (SearchBoardID.equals(boardID) && cutUserUIDD.equals(cutUIDD)) {
                // 게시물 페널
                JPanel Postpanel = new JPanel();
                Postpanel.setBackground(colors.Ground);
                Postpanel.setBounds(73, 5 + (62 * COUNT), 474, 60);
                panel_1.add(Postpanel);
                Postpanel.setLayout(null);
                Postpanel.setBorder(borderBlack); // 테두리 설정
                Postpanel.setBorder(roundedBorder);

                // 변수 설정
                ShowNicname = SearchNickname;
                ShowTitle = SearchTitle;
                ShowContent = SearchContent;

                long NewDateTime = todayDate.TodayDate();
                long newMinte = NewDateTime % 100;
                long searchMinte = SearchBdate % 100;
                long minute = newMinte - searchMinte;

                long newHour = (NewDateTime % 10000) / 100;
                long searchHour = (SearchBdate % 10000) / 100;
                long hour = newHour - searchHour;
                if (minute < 0) {
                    minute += 60;
                    hour -= 1; // 분에서 빼준 만큼 시간을 조정
                }
                long newDay = (NewDateTime % 1000000) / 10000;
                long searchDay = (SearchBdate % 1000000) / 10000;
                long day = newDay - searchDay;
                if (hour < 0) {
                    hour += 24;
                    day -= 1; // 시간에서 빼준 만큼 날짜를 조정
                }
                long newmonth = (NewDateTime % 100000000) / 1000000;
                long searchmonth = (SearchBdate % 100000000) / 1000000;
                long month = newmonth - searchmonth;
                if (day < 0) {
                    day += 30;  // 필요 시 해당 달의 일수로 조정해야 할 수도 있음
                    month -= 1;
                }
                long newyear = NewDateTime / 100000000;
                long searchyear = SearchBdate / 100000000;
                long year = newyear - searchyear;
                if (month < 0) {
                    month += 12;
                    year -= 1;
                }
                String dayLabel = null;
                if (year > 0) {
                    dayLabel = searchyear + " " + searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (month > 0) {
                    dayLabel = searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (day > 0) {
                    dayLabel = searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (day == 0 && hour > 0) {
                    dayLabel = hour + "시간" + minute + "분 전";
                } else {
                    dayLabel = minute + "분 전";
                }

                // 시간 라벨
                JLabel TimeLabel = new JLabel(dayLabel);
                TimeLabel.setBounds(33, 39, 55, 15); // Adjust the position and size as needed
                TimeLabel.setForeground(new Color(100, 100, 100)); // Set label text color
                TimeLabel.setFont(TimeFont);
                Postpanel.add(TimeLabel);
                
                
                String CommentIMG = "src/img/comments.png";
                ImageIcon CommentImageIcon = new ImageIcon(CommentIMG);
                Image CommentImage = CommentImageIcon.getImage();
                Image Comment1Image = CommentImage.getScaledInstance(12, 10, Image.SCALE_SMOOTH);
                ImageIcon Cdeclaration1ImageIcon = new ImageIcon(Comment1Image);
                JLabel CommentNumLabel = new JLabel(Cdeclaration1ImageIcon);
                CommentNumLabel.setBounds(8, 42, 12, 10); // Adjust the position and size as needed
                CommentNumLabel.setForeground(new Color(100, 100, 100)); // Set label text color
                CommentNumLabel.setFont(TimeFont);
                Postpanel.add(CommentNumLabel);
                
                data.put("table", "comments");
                data.put("where", "BulletinID");
                data.put("what", BulletinID);
				JSONObject isDuplicate = po.jsonpost("/check_exists3", data);
				int isDuplicate1 = isDuplicate.getInt("count");
				String isDuplicate2 = Integer.toString(isDuplicate1);
                JLabel CommentNumLabel1 = new JLabel(isDuplicate2);
                CommentNumLabel1.setBounds(21, 41, 10, 10); // Adjust the position and size as needed
                CommentNumLabel1.setForeground(new Color(100, 100, 100)); // Set label text color
                Font CommentNumLabelFont = new Font(CommentNumLabel1.getFont().getName(), Font.BOLD, 10);
                CommentNumLabel1.setFont(CommentNumLabelFont);
                Postpanel.add(CommentNumLabel1);

                // 제목 버튼
                JButton postbutton = new JButton(ShowTitle);
                postbutton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        showPost b = new showPost(userIDD, SearchUser, BulletinID, "일반", Section, DarK);
                        b.showFrame();
                        frame.dispose();
                    }
                });
                postbutton.setHorizontalAlignment(SwingConstants.LEFT);
                postbutton.setBorder(borderWhite);
                postbutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
                postbutton.setForeground(colors.Text); // 텍스트 색상(흰색)
                postbutton.setBounds(6, 2, 410, 20);
                postbutton.setFont(memberbuttonFont);
                postbutton.setContentAreaFilled(false);
                postbutton.setFocusPainted(false);
                postbutton.setOpaque(true);
                Postpanel.add(postbutton);
                // 내용 버튼
                JButton contentbutton = new JButton(ShowContent);
                contentbutton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        showPost b = new showPost(userIDD, SearchUser, BulletinID, "일반", Section, DarK);
                        b.showFrame();
                        frame.dispose();
                    }
                });
                contentbutton.setHorizontalAlignment(SwingConstants.LEFT);
                contentbutton.setBorder(borderWhite);
                contentbutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
                contentbutton.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
                contentbutton.setBounds(7, 22, 420, 15);
                contentbutton.setFont(contentFont);
                contentbutton.setContentAreaFilled(false);
                contentbutton.setFocusPainted(false);
                contentbutton.setOpaque(true);
                Postpanel.add(contentbutton);

                // 닉네임
                JButton Nicknamebutton = new JButton(ShowNicname);
                Nicknamebutton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                    	UserInfo userDialog = new UserInfo(userIDD, SearchUser, DarK);
                    }
                });
                Nicknamebutton.setBorder(borderWhite);
                Nicknamebutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
                Nicknamebutton.setForeground(new Color(80, 80, 80)); // 텍스트 색상(흰색)
                Nicknamebutton.setBounds(420, 8, 50, 15);
                Nicknamebutton.setFont(contentFont);
                Nicknamebutton.setContentAreaFilled(false);
                Nicknamebutton.setFocusPainted(false);
                Nicknamebutton.setOpaque(true);
                Postpanel.add(Nicknamebutton);
                
                if (SearchUser.equals(userIDD)|| userIDD.equals("admin")) {
                    RoundedButton CDeletebutton = new RoundedButton("삭제");
                    CDeletebutton.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                            DeletePost deletePost = new DeletePost(BulletinID, userIDD, Section, DarK);
                        }
                    });
                    CDeletebutton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
                    CDeletebutton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
                    CDeletebutton.setBounds(432, 35, 30, 15);
                    Postpanel.add(CDeletebutton);

                } 

                COUNT++;
            }
        }

        // 스크롤바 추가
        JScrollPane scrollPane = new JScrollPane(panel_1);
        scrollPane.setBounds(0, 140, 625, 617); // JScrollPane의 위치 및 크기 설정
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        // 가로 스크롤바를 비활성화합니다.
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        // 세로 스크롤바의 UI 변경
        scrollPane.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = new Color(100, 100, 100); // 스크롤바 색상 설정
            }

            @Override
            protected JButton createDecreaseButton(int orientation) {
                return new JButton() {
                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension(0, 0); // 위 버튼 크기 0으로 설정하여 숨김
                    }
                };
            }

            @Override
            protected JButton createIncreaseButton(int orientation) {
                return new JButton() {
                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension(0, 0); // 아래 버튼 크기 0으로 설정하여 숨김
                    }
                };
            }

            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // 둥근 모양의 스크롤바
                g2.setColor(Color.LIGHT_GRAY); // 색상 변경
                g2.fillRoundRect(thumbBounds.x, thumbBounds.y, thumbBounds.width, thumbBounds.height, 10, 10);

                g2.dispose();
            }
        });
        scrollPane.setVisible(true);

        panel.add(scrollPane);

        frame.getContentPane().add(panel);

        // 다이얼로그 표시
        frame.setVisible(true);

    }


    // 글쓰기
    private void NewPostDialog() {
    	JSONObject data = new JSONObject();
        TodayDate todayDate = new TodayDate();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }

        // 테두리 스타일 설정
        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        Border borderBlack = BorderFactory.createLineBorder(colors.Text, 1);

        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(200, 273, 450, 500);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        // dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 100, 100);
        frame.getContentPane().add(dialogPanel);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogFrame.add(dialogPanel);

        // 변경 라벨
        JLabel ChangePWLabel = new JLabel("게시물 작성");
        ChangePWLabel.setBounds(180, 11, 150, 30); // Adjust the position and size as needed
        ChangePWLabel.setForeground(new Color(100, 100, 100)); // Set label text color
        Font ChangePWFont = new Font(ChangePWLabel.getFont().getName(), Font.BOLD, 14);
        ChangePWLabel.setFont(ChangePWFont);
        dialogPanel.add(ChangePWLabel);

        // 취소 버튼
        JButton BackButton = new JButton("취소"); // 버튼 생성 및 텍스트 설정
        BackButton.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                dialogFrame.dispose();
            }
        });
        BackButton.setBounds(382, 10, 60, 20); // 버튼 위치 및 크기 설정
        BackButton.setBackground(colors.Ground);// 배경색 설정
        BackButton.setForeground(colors.Text); // 텍스트 색상(흰색)
        dialogPanel.add(BackButton); // 패널에 버튼 추가
        Font memberbuttonFont = new Font(BackButton.getFont().getName(), Font.BOLD, 11);
        BackButton.setFont(memberbuttonFont);
        BackButton.setContentAreaFilled(false);
        BackButton.setFocusPainted(false);
        BackButton.setOpaque(true);
        BackButton.setBorder(borderWhite); // 테두리 설정

        // 제목 필드
        RoundtextField TitleField = new RoundtextField();
        TitleField.setBounds(50, 75, 340, 35);
        TitleField.setBackground(colors.BoardPanel);
        TitleField.setForeground(colors.Text);
        dialogPanel.add(TitleField);
        TitleField.setColumns(10);
        TitleField.setBorder(borderWhite);
        TitleField.setText(null);
        TitleField.setDefaultText("  제목"); // 기본 텍스트 설정

        // 내용페널
        JPanel Contentpanel = new JPanel();
        Contentpanel.setBackground(colors.Ground);
        Contentpanel.setBounds(50, 130, 340, 250);
        dialogPanel.add(Contentpanel);
        Contentpanel.setLayout(null);
        Contentpanel.setBorder(borderBlack); // 테두리 설정
        RoundedBorder roundedBorder = new RoundedBorder(20);
        Contentpanel.setBorder(roundedBorder);

        // 내용 필드
        JTextArea ContentField = new JTextArea();
        ContentField.setBounds(5, 5, 330, 240);
        ContentField.setBackground(colors.Ground);
        ContentField.setForeground(colors.Text);
        ContentField.setLineWrap(true);
        ContentField.setWrapStyleWord(true);


        JLabel TextLabel = new JLabel("");
        Font TextFont = new Font(BackButton.getFont().getName(), Font.BOLD, 11);
        TextLabel.setFont(TextFont);
        dialogPanel.add(TextLabel);
        TextLabel.setBounds(340, 385, 100, 15);
        // DocumentListener를 사용하여 내용이 변경될 때마다 이벤트 처리
        ContentField.getDocument().addDocumentListener(new DocumentListener() {

            private void checkCharacterLimit() {
                if (ContentField.getText().length() > 400) {
                    String truncatedText = ContentField.getText().substring(0, 400);
                    ContentField.setText(truncatedText);
                }
            }

            private void updateCharacterCount() {
                int characterCount = ContentField.getText().length();
                // 원하는 위치에 텍스트 개수를 보여주는 JLabel 또는 다른 방법으로 표시하면 됩니다.
                if (characterCount > 400) {
                    characterCount = 400;
                }
                TextLabel.setText(characterCount + "/400");
            }

            @Override
            public void insertUpdate(DocumentEvent e) {
                updateCharacterCount();
                checkCharacterLimit();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                updateCharacterCount();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                updateCharacterCount();
            }
        });
        Contentpanel.add(ContentField);
        ContentField.setColumns(10);
        ContentField.setBorder(borderWhite);
        ContentField.setText(null);
        
        data.put("table", "users");
        data.put("want", "UID");
        data.put("what", "UserID");
        data.put("user_id", userIDD);
        Post po = new Post();
    	JSONObject SearchSchoolcode1 = po.jsonpost("/find_user_information", data);
    	String SearchSchoolcode = SearchSchoolcode1.getString("UID");
                
        data.put("table", "bulletin");
        data.put("want", "BulletinID");
    	JSONObject SearchBulletinID1 = po.jsonpost("/find_post_id", data);
    	int SearchBulletinID = SearchBulletinID1.getInt("maxBulletinID");
        
        int newBulletinID = SearchBulletinID + 1;

        // 작성하기 버튼
        RoundedButton confirmButton = new RoundedButton("작성하기");
        confirmButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                String Title = TitleField.getText();
                String Content = ContentField.getText();
                long currentDateTime = todayDate.TodayDate();
                
                data.put("BulletinID", newBulletinID);
                data.put("UserID", userIDD);
                data.put("UID", SearchSchoolcode);
                data.put("BoardID", boardID);
                data.put("BulletinTitle", Title);
                data.put("Bcontent", Content);
                data.put("Bdate", currentDateTime);
				JSONObject change_check = po.jsonpost("/register_post", data);
				boolean success = change_check.getBoolean("success"); 
				System.out.println("게시물 등록 성공 여부: " + success);
                
                
                freeboardclass bo = new freeboardclass(userIDD, boardID, Section, DarK);
                bo.showFrame();
                frame.dispose();
                dialogFrame.dispose();

            }
        });
        confirmButton.setBackground(new Color(255, 0, 0));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.setBounds(185, 400, 65, 25);
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }

    // 제한일
    private void LimitDialog(String UserID) {
    	JSONObject data = new JSONObject();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }
        Border borderGray = BorderFactory.createLineBorder(colors.BoardPanel, 1);
        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        Border borderBlack = BorderFactory.createLineBorder(new Color(0, 0, 0), 1);
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(250, 320, 350, 220);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 326, 178);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(borderWhite); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel MyPostLabel = new JLabel("※이용 제한※");
        MyPostLabel.setBounds(100, 25, 200, 20);
        MyPostLabel.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
        Font MyPostFont = new Font(MyPostLabel.getFont().getName(), Font.BOLD, 18);
        MyPostLabel.setFont(MyPostFont);
        dialogPanel.add(MyPostLabel);

        data.put("table", "users");
        data.put("want", "LimitDate");
        data.put("what", "UserID");
        data.put("user_id", UserID);
        Post po = new Post();
    	JSONObject LimitDate1 = po.jsonpost("/find_user_information", data);
    	long LimitDate = LimitDate1.getLong("LimitDate");
        
    	 long minute = LimitDate % 100;

         long Hour = (LimitDate % 10000) / 100;
     	
         long day = (LimitDate % 1000000) / 10000;

         long month = (LimitDate % 100000000) / 1000000;

         long year = LimitDate / 100000000;

         String dayLabel = year + "년 " + month + "월 " + day + "일" + Hour + "시" + minute +"분 까지";

        if (LimitDate != 0) {
            JLabel LimitLabel = new JLabel(dayLabel);
            LimitLabel.setBounds(75, 70, 200, 20);
            LimitLabel.setForeground(new Color(150, 100, 100)); // 텍스트 색상(흰색)
            Font LimitFont = new Font(LimitLabel.getFont().getName(), Font.BOLD, 14);
            LimitLabel.setFont(LimitFont);
            dialogPanel.add(LimitLabel);
        } else {
            JLabel LimitLabel = new JLabel("이용 제한 내역 없음");
            LimitLabel.setBounds(100, 70, 200, 20);
            LimitLabel.setForeground(new Color(100, 100, 150)); // 텍스트 색상(흰색)
            Font LimitFont = new Font(LimitLabel.getFont().getName(), Font.BOLD, 14);
            LimitLabel.setFont(LimitFont);
            dialogPanel.add(LimitLabel);
        }

        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("확인");
        confirmButton.setBounds(128, 140, 65, 20);
        confirmButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        confirmButton.setForeground(colors.Text); // 텍스트 색상(흰색)
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                dialogFrame.dispose();
            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }


    public void showFrame() {
        frame.setVisible(true);
    }

}
