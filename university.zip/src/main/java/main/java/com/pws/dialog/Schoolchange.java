package main.java.com.pws.dialog;

import javax.swing.*;
import javax.swing.border.Border;

import org.json.JSONObject;

import main.java.com.pws.Board.boardclass;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.RoundtextField;
import main.java.com.pws.Thing.collor;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Schoolchange {
    private String userIDD;
    private String Section;
    private int DarK;
	
    private JFrame parentFrame;

    public Schoolchange(String userIDD, JFrame parentFrame, String Section, int DarK) {
        this.userIDD = userIDD;
        this.Section = Section;
        this.parentFrame = parentFrame;
        this.DarK = DarK;

        initialize();
    }

    private void initialize() {
        JSONObject data = new JSONObject();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }
        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        Border borderBlack = BorderFactory.createLineBorder(colors.BoardPanel, 2);
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(250, 350, 350, 220);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 326, 178);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(borderWhite); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel MyPostLabel = new JLabel("학교 설정");
        MyPostLabel.setBounds(122, 25, 200, 20);
        MyPostLabel.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
        Font MyPostFont = new Font(MyPostLabel.getFont().getName(), Font.BOLD, 18);
        MyPostLabel.setFont(MyPostFont);
        dialogPanel.add(MyPostLabel);
        
        data.put("table", "users");
        data.put("want", "UID");
        data.put("what", "UserID");
        data.put("user_id", userIDD);
        Post po = new Post();
        JSONObject UserUID1 = po.jsonpost("/find_user_information", data);
        String UserUID = UserUID1.getString("UID");
        
        data.put("what", UserUID);
        JSONObject universityInfo = po.jsonpost("/get_university_info", data);
        String getUName = universityInfo.getString("uName");
        
        // 중복 라벨
        JLabel NickduplicationLabel = new JLabel("현재 학교: " + getUName);
        NickduplicationLabel.setBounds(117, 105, 150, 15); // 위치 및 크기 조정
        NickduplicationLabel.setForeground(new Color(100, 100, 150)); // 라벨 텍스트 색상 설정
        Font labelFont2 = new Font(NickduplicationLabel.getFont().getName(), Font.BOLD, 9);
        NickduplicationLabel.setFont(labelFont2);
        dialogPanel.add(NickduplicationLabel);
        
        // 학과 입력 필드
        RoundtextField UniversityField = new RoundtextField();
        UniversityField.setBounds(60, 70, 200, 20);
        UniversityField.setBackground(colors.BoardPanel);
        UniversityField.setForeground(colors.Text);
        dialogPanel.add(UniversityField);
        UniversityField.setColumns(10);
        UniversityField.setBorder(borderBlack);
        UniversityField.setDefaultText("  학교");

        // 별명중복 확인 버튼 (원래 중복 확인 기능은 여기에 넣어도 됨)
        RoundedButton NicknameDuplicationButton = new RoundedButton("검색");
        NicknameDuplicationButton.setBounds(260, 71, 30, 20);
        Font checkFont1 = new Font(NicknameDuplicationButton.getFont().getName(), Font.PLAIN, 10);
        NicknameDuplicationButton.setFont(checkFont1);

        NicknameDuplicationButton.setBackground(colors.Ground); // 배경색 설정
        NicknameDuplicationButton.setForeground(colors.Text); // 텍스트 색상
        dialogPanel.add(NicknameDuplicationButton); // 패널에 버튼 추가
        NicknameDuplicationButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent en) {
                // 여기서 데이터베이스 조회하여 중복 여부 확인
                String cutDepartment = UserUID.substring(UserUID.length() - 2);                
                String Universitysave = UniversityField.getText();
                String newUID = Universitysave + cutDepartment;  
                try {
                    Integer.parseInt(Universitysave);                
                    System.out.println("입력한 내용은 정수입니다." + newUID);
                    data.put("what", newUID);
                    JSONObject universityInfo = po.jsonpost("/get_university_info", data);
                    String getUName = universityInfo.getString("uName"); 
                    if (getUName.equals("정보")) {
                        NickduplicationLabel.setText("학교 코드를 정확히 입력해 주세요.");
                        NickduplicationLabel.setForeground(new Color(150, 100, 100));
                        NickduplicationLabel.setBounds(92, 105, 150, 15);
                    } else {
                        NickduplicationLabel.setText(getUName);
                        NickduplicationLabel.setForeground(new Color(100, 100, 150));
                        NickduplicationLabel.setBounds(137, 105, 150, 15);
                    }
                } catch (NumberFormatException e) {
                    System.out.println("입력한 내용은 문자열입니다.");
                    data.put("table", "university");
                    data.put("want", "UID");
                    data.put("where1", "UID");
                    data.put("what1", cutDepartment);
                    data.put("where2", "UName");
                    data.put("what2", Universitysave);
                    JSONObject SearchUID1 = po.jsonpost("/find_like_wnat", data);
                    boolean DepartDuplicate = SearchUID1.getBoolean("check");

                    if (DepartDuplicate) {
                        NickduplicationLabel.setText(Universitysave);
                        NickduplicationLabel.setForeground(new Color(100, 100, 150));
                        NickduplicationLabel.setBounds(137, 105, 150, 15);
                    } else {
                        NickduplicationLabel.setText("학교 정보를 정확히 입력해 주세요.");
                        NickduplicationLabel.setForeground(new Color(150, 100, 100));
                        NickduplicationLabel.setBounds(92, 105, 150, 15);
                    }
                }
            }
        });
        
        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("변경");
        confirmButton.setBounds(128, 140, 65, 20);
        confirmButton.setBackground(new Color(100, 100, 100)); // 배경색 설정
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String cutDepartment = UserUID.substring(UserUID.length() - 2);                
                String Universitysave = UniversityField.getText();
                String newUID = Universitysave + cutDepartment;  
                try {
                    Integer.parseInt(Universitysave);                
                    System.out.println("입력한 내용은 정수입니다." + newUID);
                    data.put("what", newUID);
                    JSONObject universityInfo = po.jsonpost("/get_university_info", data);
                    String getUName = universityInfo.getString("uName"); 
                    if (getUName.equals("정보")) {
                        NickduplicationLabel.setText("학교 코드를 정확히 입력해 주세요.");
                        NickduplicationLabel.setForeground(new Color(150, 100, 100));
                        NickduplicationLabel.setBounds(92, 105, 150, 15);
                    } else {
                    	data.put("table", "users");
                        data.put("this1", "UserID");
                        data.put("this2", userIDD);
                        data.put("what", "UID");
                        data.put("change", newUID);
        				JSONObject change_check = po.jsonpost("/change_user", data);
        				boolean success = change_check.getBoolean("success"); 
        				System.out.println("변경 성공 여부: " + success);
        				
                        boardclass bo = new boardclass(userIDD, Section, DarK);
                        bo.showFrame();
                        parentFrame.dispose();
                    }
                } catch (NumberFormatException s) {
                    System.out.println("입력한 내용은 문자열입니다.");
                    data.put("table", "university");
                    data.put("want", "UID");
                    data.put("where1", "UID");
                    data.put("what1", cutDepartment);
                    data.put("where2", "UName");
                    data.put("what2", Universitysave);
                    JSONObject SearchUID1 = po.jsonpost("/find_like_wnat", data);
                    boolean DepartDuplicate = SearchUID1.getBoolean("check");
                    String searchUID = SearchUID1.optString("UID", null);

                    if (DepartDuplicate) {
                    	data.put("table", "users");
                        data.put("this1", "UserID");
                        data.put("this2", userIDD);
                        data.put("what", "UID");
                        data.put("change", searchUID);
        				JSONObject change_check = po.jsonpost("/change_user", data);
        				boolean success = change_check.getBoolean("success"); 
        				System.out.println("변경 성공 여부: " + success);
                           	
                        boardclass bo = new boardclass(userIDD, Section, DarK);
                        bo.showFrame();
                        parentFrame.dispose();
                    } else {
                        NickduplicationLabel.setText("학교 정보를 정확히 입력해 주세요.");
                        NickduplicationLabel.setForeground(new Color(150, 100, 100));
                        NickduplicationLabel.setBounds(92, 105, 150, 15);
                    }
                }
            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
}
