package main.java.com.pws.Schedule;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicScrollBarUI;

import org.json.JSONArray;
import org.json.JSONObject;

import main.java.com.pws.Thing.FrameManager;
import main.java.com.pws.Thing.GetLecture;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundedBorder;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.RoundedComboBox;
import main.java.com.pws.Thing.RoundtextField;
import main.java.com.pws.Thing.collor;

public class LectureList{
	private String userIDD;
	private String[] SearchLectures;
	private String lectureID;
	private String Section;
	private String Frame;
	private int DarK;

	int A;

    public LectureList(String userIDD, String[] SearchLectures, String Section, String Frame, int DarK) {
        this.userIDD = userIDD;
        this.SearchLectures = SearchLectures;
        this.Section = Section;
        this.Frame = Frame;
        this.DarK = DarK;

        initialize();
    }

    private void initialize() {
	    JSONObject data = new JSONObject();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }


	    data.put("table", "users");
	    data.put("want", "UID");
	    data.put("what", "UserID");
	    data.put("user_id", userIDD);
	    Post po = new Post();
		JSONObject SearchNickname1 = po.jsonpost("/find_user_information", data);
		String AdminUID = SearchNickname1.getString("UID");
        String SchoolID = AdminUID.substring(0, AdminUID.length() - 2);
	
        Border borderBlue = BorderFactory.createLineBorder(new Color(155, 155, 155), 2);
        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        Border borderBlack = BorderFactory.createLineBorder(colors.BoardPanel, 1);
	
	    // 다이얼로그 프레임 생성
	    JFrame dialogFrame = new JFrame();
	    dialogFrame.setBounds(150, 240, 550, 570);
	    dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	    dialogFrame.getContentPane().setLayout(null);
	
    	FrameManager.addFrame(dialogFrame);

	    // 다이얼로그 패널 생성
	    JPanel dialogPanel = new JPanel();
	    dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
	    dialogPanel.setBounds(5, 0, 526, 528);
	    dialogPanel.setLayout(null);
	    dialogPanel.setBackground(colors.Ground); // 배경색 설정
	    dialogPanel.setBorder(borderWhite); // 테두리 설정
	    dialogFrame.getContentPane().add(dialogPanel);
	
	    // 다이얼로그 라벨 생성
	    JLabel MyPostLabel = new JLabel("강의 목록");
	    MyPostLabel.setBounds(220, 25, 200, 20);
	    MyPostLabel.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
	    Font MyPostFont = new Font(MyPostLabel.getFont().getName(), Font.BOLD, 20);
	    MyPostLabel.setFont(MyPostFont);
	    dialogPanel.add(MyPostLabel);
	    
	    
	    JLabel ShowIDLabel = new JLabel("코드");
	    ShowIDLabel.setBounds(81, 110, 100, 20);
	    ShowIDLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
	    Font ShowInfoFont = new Font(ShowIDLabel.getFont().getName(), Font.BOLD, 15);
	    ShowIDLabel.setFont(ShowInfoFont);
	    dialogPanel.add(ShowIDLabel);
	    
	    JLabel ShowNameLabel = new JLabel("강의");
	    ShowNameLabel.setBounds(251, 110, 100, 20);
	    ShowNameLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
	    ShowNameLabel.setFont(ShowInfoFont);
	    dialogPanel.add(ShowNameLabel);
	    
	    JLabel ShowDeptLabel = new JLabel("교수");
	    ShowDeptLabel.setBounds(394, 110, 100, 20);
	    ShowDeptLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
	    ShowDeptLabel.setFont(ShowInfoFont);
	    dialogPanel.add(ShowDeptLabel);
	    
	    if (userIDD.equals("admin")) {
	        RoundedButton AddInstructorbutton = new RoundedButton("강의 추가");
	        AddInstructorbutton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	AddLecture ShowAddLecture = new AddLecture(userIDD, Section, Frame, DarK);
	            }
	        });
	        AddInstructorbutton.setBackground(new Color(200, 100, 150));// 배경색 설정 (빨간색)
	        AddInstructorbutton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
	        AddInstructorbutton.setBounds(440, 15, 70, 20);
	        dialogPanel.add(AddInstructorbutton);
        	
	    }
	    	
	    String[] object = {"제목", "교수", "전공", "코드"};
        
        RoundedComboBox<String> Searchchoice = new RoundedComboBox<>(
        		object, colors.Ground, colors.Text, Color.GRAY);
        Searchchoice.setBounds(55, 60, 60, 20);
        dialogPanel.add(Searchchoice);
        // 검색창 박스
        RoundtextField textField = new RoundtextField(); // 텍스트 필드 생성
        textField.setBounds(123, 50, 280, 43); // 텍스트 필드 위치 및 크기 설정
        textField.setBackground(colors.BoardPanel); // 배경색 설정
        textField.setForeground(colors.Text); // 텍스트 색상(흰색)
        dialogPanel.add(textField); // 패널에 텍스트 필드 추가
        textField.setColumns(10); // 텍스트 필드 컬럼 수 설정
        textField.setBorder(borderBlue); // 테두리 설정
        textField.setDefaultText("  검색"); // 기본 텍스트 설정
	            
        // 검색 버튼
        JButton lblId = new JButton("검색"); // 레이블 생성 및 텍스트 설정
        lblId.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                String SearchTextField = textField.getText();
              
            	String Choice = Searchchoice.getSelectedItem().toString();
            	if(Choice.equals("제목")) {
            	    data.put("what", "lecture_name");                   
            	} else if(Choice.equals("교수")) {
            	    data.put("table", "instructor");
            	    data.put("want", "instructor_id");
            	    data.put("what", "name");
            	    data.put("user_id", SearchTextField);
            	    Post po = new Post();
            		JSONObject SearchTextField1 = po.jsonpost("/find_All", data);
            		JSONArray SearchTextField2 = SearchTextField1.getJSONArray("instructor_id");
    	    		SearchTextField = SearchTextField2.getString(0);
    	    		System.out.println("교수아이디: " +SearchTextField);

            	    data.put("what", "instructor_id");                   
            	} else if(Choice.equals("전공")) {
    	    	    data.put("table", "university");
    	    	    data.put("want", "UID");
    	    	    data.put("what", "department");
    	    	    data.put("user_id", SearchTextField);
            	    Post po = new Post();
    	    		JSONObject getUID1 = po.jsonpost("/find_All", data);
    	    		JSONArray getUID2 = getUID1.getJSONArray("UID");
    	    		String NUULL = getUID2.getString(0);
    	    		String getUID = "없음"; 
    	    		if(!NUULL.equals("없음")) {
	    	    		for (int i = 0; i < getUID2.length(); i++) {
	    	    		    String uid = getUID2.getString(i).substring(0, getUID2.getString(i).length() - 2);;	
	    	    		    if (uid.equals(SchoolID)) { // UID가 "123"으로 시작하는지 확인
	    	    		        getUID = "1"+getUID2.getString(i).substring(3, getUID2.getString(i).length() - 0);
	    	    		        break; // 조건을 만족하면 반복문을 종료
	    	    		    }
	    	    		}
    	    		}
    	    		SearchTextField = getUID;
    	    		System.out.println("검색전공: " +SearchTextField);    	    		
            	    data.put("what", "lecture_id");                   
            	} else if(Choice.equals("코드")) {            		
            	    data.put("what", "lecture_id");                   
            	}
           	    data.put("table", "lecture_info");
        	    data.put("want", "lecture_id");
        	    data.put("user_id", SearchTextField);
        	    Post po = new Post();
        		JSONObject GetLectureId1 = po.jsonpost("/find_All", data);
        		JSONArray lectureIds = GetLectureId1.getJSONArray("lecture_id");        		

                List<String> filteredList = new ArrayList<>();

                for (int a = 0; a < lectureIds.length(); a++) {
                    filteredList.add(lectureIds.getString(a)); // 중복되지 않은 항목을 추가합니다.

                    if (a < lectureIds.length() - 1 && lectureIds.getString(a).equals(lectureIds.getString(a + 1))) {
                        a++; // 중복된 항목을 건너뜁니다.
                    }
                }

                // ArrayList를 배열로 변환
                SearchLectures = new String[filteredList.size()];
	    		System.out.println("배열의 크기: " +filteredList.size());

                filteredList.toArray(SearchLectures);
            	
            	LectureList adminlecture = new LectureList(userIDD, SearchLectures, Section, Frame, DarK);
                dialogFrame.dispose();


            }
        });
        lblId.setBounds(410, 58, 40, 25); // 레이블 위치 및 크기 설정
        lblId.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        lblId.setForeground(new Color(130, 130, 130)); // 텍스트 색상(흰색)
        lblId.setBorder(borderWhite); // 테두리 설정
        lblId.setContentAreaFilled(false);
        lblId.setFocusPainted(false);
        lblId.setOpaque(true);
        dialogPanel.add(lblId); // 패널에 텍스트 필드 추가

        GetLecture  getLecture  = new GetLecture ();
        List<List<String>> Lectures = getLecture.GetLecture();

	    // 패널 생성
	    JPanel panel_1 = new JPanel();
	    panel_1.setBackground(colors.Ground);
	    int hight = 408;
	    if (Lectures.size() > 9) {
	        hight = 5 + 42 * Lectures.size();
	    }
	    panel_1.setBounds(24, 140, 480, hight);
	    dialogPanel.add(panel_1);
	    panel_1.setLayout(null);
	    panel_1.setBorder(borderWhite); // 테두리 설정
	    RoundedBorder roundedBorder = new RoundedBorder(20);
	    panel_1.setPreferredSize(new Dimension(480, hight));
	    
	    
        String lectureID2 = "not";
        String name = null ;
        String instrucID = null;
        String SectionID = null;

	    int COUNT = 0;
	    int aa = Lectures.size() -1 ;
	    for (int a = 1; a <= Lectures.size(); a++) {
	        List<String> Lecture = Lectures.get(aa);

	        if (SearchLectures.length == 0 || SearchLectures[0].equals("없음")) {
	            lectureID = Lecture.get(1);

	            lectureID2 = "not";
	            if (aa > 0) {
	                List<String> Lecture2 = Lectures.get(aa - 1);
	                lectureID2 = Lecture2.get(1);
	            }
	            name = Lecture.get(4);
	            instrucID = Lecture.get(6);
	            SectionID = Lecture.get(7);
	        
		        if(lectureID.equals(lectureID2)) {
		        	aa = aa-2;
		        	a = a+1;
		        }else {
			        aa--;
		        }
		        A = aa+1;
		        
	        } else if (a - 1 < SearchLectures.length) {
	            lectureID = SearchLectures[a - 1];
	            System.out.println("받아온 강의: " + lectureID);

	            // lectureID에 해당하는 Lectures 배열의 인덱스를 찾기
	            int originalIndex = -1;
	            for (int i = 0; i < Lectures.size(); i++) {
	                if (Lectures.get(i).get(1).equals(lectureID)) {
	                    originalIndex = i;
	                    break;
	                }
	            }
	            
	            if (originalIndex == -1) {
	                System.out.println("강의를 찾을 수 없습니다: " + lectureID);
	                continue; // 강의를 찾을 수 없으면 다음 반복으로 넘어감
	            }

	            data.put("table", "lecture_info");
	            data.put("want", "lecture_name");
	            data.put("what", "lecture_id");
	            data.put("user_id", lectureID);
	            JSONObject name1 = po.jsonpost("/find_All", data);
	            JSONArray lectureNames = name1.getJSONArray("lecture_name");
	            name = lectureNames.getString(0);

	            data.put("want", "instructor_id");
	            JSONObject instrucID1 = po.jsonpost("/find_All", data);
	            JSONArray InstructorIDs = instrucID1.getJSONArray("instructor_id");
	            instrucID = InstructorIDs.getString(0);

	            data.put("want", "section_id");
	            JSONObject SectionID1 = po.jsonpost("/find_All", data);
	            JSONArray SectionIDs = SectionID1.getJSONArray("section_id");
	            SectionID = SectionIDs.getString(0);

	            A = originalIndex; // 원래 배열의 인덱스를 사용
	        } else {
	    	    JLabel SectionNotLabel = new JLabel("학기정보를 확인해 주세요.");
	    	    SectionNotLabel.setBounds(118, 20, 300, 20);
	    	    SectionNotLabel.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
	    	    SectionNotLabel.setFont(ShowInfoFont);
	    	    SectionNotLabel.setHorizontalAlignment(JLabel.CENTER);
	    	    panel_1.add(SectionNotLabel);
	            System.out.println("인덱스 범위 초과: " + (a - 1));
	            break;
	            
	        }
	        int B = A;

	        String UserSchoolID = instrucID.substring(0, instrucID.length() - 2);

            System.out.println("전달하는 번호1: "+ A);

        if (UserSchoolID.equals(SchoolID) && SectionID.equals(Section)) {

            // 게시물 페널
            JPanel Lecturepanel = new JPanel();
            Lecturepanel.setBackground(colors.Ground);
            Lecturepanel.setBounds(25, 5 + (42 * COUNT), 474, 40);
            panel_1.add(Lecturepanel);
            Lecturepanel.setLayout(null);
            Lecturepanel.setBorder(borderBlack); // 테두리 설정
            Lecturepanel.setBorder(roundedBorder);


            // 코드 버튼
            JButton Codebutton = new JButton(lectureID);
            Codebutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	LectureInfo lectureInfo = new LectureInfo(userIDD, Section, B, DarK, "리스트");
                }
            });
            Codebutton.setBorder(borderWhite);
            Codebutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
            Codebutton.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
            Codebutton.setBounds(20, 5, 105, 30);
            Font contentFont = new Font(Codebutton.getFont().getName(), Font.BOLD, 14);
            Codebutton.setFont(contentFont);
            Codebutton.setContentAreaFilled(false);
            Codebutton.setFocusPainted(false);
            Codebutton.setOpaque(true);
            Lecturepanel.add(Codebutton);
            
            // 이름 버튼
            JButton LectureNamebutton = new JButton(name);
            LectureNamebutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	LectureInfo lectureInfo = new LectureInfo(userIDD, Section, B, DarK, "리스트");
                }
            });
            LectureNamebutton.setBorder(borderWhite);
            LectureNamebutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
            LectureNamebutton.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
            LectureNamebutton.setBounds(140, 5, 205, 30);
            LectureNamebutton.setFont(contentFont);
            LectureNamebutton.setContentAreaFilled(false);
            LectureNamebutton.setFocusPainted(false);
            LectureNamebutton.setOpaque(true);
            Lecturepanel.add(LectureNamebutton);

    	    data.put("table", "instructor");
    	    data.put("want", "name");
    	    data.put("what", "instructor_id");
    	    data.put("user_id", instrucID);
    		JSONObject Instrucname1 = po.jsonpost("/find_user_information", data);
    		String Instrucname = Instrucname1.getString("name");
    		
            // 교수 버튼
            JButton Instrucnamebutton = new JButton(Instrucname);
            Instrucnamebutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	LectureInfo lectureInfo = new LectureInfo(userIDD, Section, B, DarK, "리스트");
                }
            });
            Instrucnamebutton.setBorder(borderWhite);
            Instrucnamebutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
            Instrucnamebutton.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
            Instrucnamebutton.setBounds(335, 5, 100, 30);
            Instrucnamebutton.setFont(contentFont);
            Instrucnamebutton.setContentAreaFilled(false);
            Instrucnamebutton.setFocusPainted(false);
            Instrucnamebutton.setOpaque(true);
            Lecturepanel.add(Instrucnamebutton);
            
        	String Showname = name;
        	String AddSectionID = SectionID;
        	String AddlectureID = lectureID;

            if(Frame.equals("강의실")) {
                
                JButton AddLecturebutton = new JButton("✚");
                AddLecturebutton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        data.put("table", "lecture");
                        data.put("where", "lecture_id");
                        data.put("what", AddlectureID);
                        data.put("where2", "UserID");
                        data.put("what2", userIDD);
        				JSONObject isDuplicate = po.jsonpost("/check_exists2", data);
        				boolean isDuplicate1;
        				isDuplicate1 = isDuplicate.getBoolean("exists");
                        if (isDuplicate1) {
                        	AddNotDialog();
                        } else {
                        	AddCheckDialog(Showname, AddlectureID, userIDD, AddSectionID);

                        }                    	
                    }
                });
                AddLecturebutton.setBorder(borderWhite);
                AddLecturebutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
                AddLecturebutton.setForeground(new Color(230, 50, 50)); // 텍스트 색상(흰색)
                AddLecturebutton.setBounds(435, 4, 30, 30);
                AddLecturebutton.setFont(contentFont);
                AddLecturebutton.setContentAreaFilled(false);
                AddLecturebutton.setFocusPainted(false);
                AddLecturebutton.setOpaque(true);
                Lecturepanel.add(AddLecturebutton);
                
                data.put("table", "lecture");
                data.put("where", "lecture_id");
                data.put("what", AddlectureID);
                data.put("where2", "UserID");
                data.put("what2", userIDD);
				JSONObject isDuplicate = po.jsonpost("/check_exists2", data);
				boolean isDuplicate1;
				isDuplicate1 = isDuplicate.getBoolean("exists");
                
				System.out.println("중복강의: " +isDuplicate1);
                if (isDuplicate1) {
                    JLabel alreadyLabel = new JLabel("✓");
                    alreadyLabel.setBounds(2, 4, 15, 30); // Adjust the position and size as needed
                    alreadyLabel.setForeground(new Color(120, 120, 120)); // Set label text color
                    Font labelFont6 = new Font(alreadyLabel.getFont().getName(), Font.BOLD, 10);
                    alreadyLabel.setFont(labelFont6);
                    alreadyLabel.setHorizontalAlignment(JLabel.CENTER);
                    Lecturepanel.add(alreadyLabel);
                }
                
            }

    		if(!SearchLectures[0].equals("없음") && a == SearchLectures.length) {
    			break;
    		}
            COUNT++;
        }

    	}
        // 스크롤바 추가
        JScrollPane scrollPane = new JScrollPane(panel_1);
        scrollPane.setBounds(0, 140, 625, 408); // JScrollPane의 위치 및 크기 설정
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        // 가로 스크롤바를 비활성화합니다.
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        // 세로 스크롤바의 UI 변경
        scrollPane.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = new Color(100, 100, 100); // 스크롤바 색상 설정
            }

            @Override
            protected JButton createDecreaseButton(int orientation) {
                return new JButton() {
                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension(0, 0); // 위 버튼 크기 0으로 설정하여 숨김
                    }
                };
            }

            @Override
            protected JButton createIncreaseButton(int orientation) {
                return new JButton() {
                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension(0, 0); // 아래 버튼 크기 0으로 설정하여 숨김
                    }
                };
            }

            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // 둥근 모양의 스크롤바
                g2.setColor(Color.LIGHT_GRAY); // 색상 변경
                g2.fillRoundRect(thumbBounds.x, thumbBounds.y, thumbBounds.width, thumbBounds.height, 10, 10);

                g2.dispose();
            }
        });
        scrollPane.setVisible(true);

        dialogPanel.add(scrollPane);
        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
	
    private void AddCheckDialog(String Lecturnmae,String lecture_id,
    		String UserID, String section_id) {
        JSONObject data = new JSONObject();
        Post po = new Post();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(31, 31, 31);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(70, 70, 70);
            colors.buttonBackground = new Color(50, 50, 50);
            colors.postbuttonColor = new Color(40, 40, 40);
            colors.RedText = new Color(200, 100, 100);
        }
        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);

        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(270, 400, 300, 150);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null); 

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 276, 110);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(borderWhite); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel dialogLabel = new JLabel(Lecturnmae + ": " +lecture_id);
        dialogLabel.setBounds(15, 23, 250, 20);
        dialogLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
        dialogLabel.setHorizontalAlignment(JLabel.CENTER);
        dialogPanel.add(dialogLabel);
        
        // 다이얼로그 라벨 생성
        JLabel dialog2Label = new JLabel("강의를 추가 하시겠습니까?");
        dialog2Label.setBounds(15, 43, 250, 20);
        dialog2Label.setForeground(colors.Text); // 텍스트 색상(흰색)
        dialog2Label.setHorizontalAlignment(JLabel.CENTER);
        dialogPanel.add(dialog2Label);
        
        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("추가");
        confirmButton.setBounds(110, 80, 65, 20);
        confirmButton.setBackground(new Color(230, 30, 30));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                data.put("lecture_id", lecture_id);
                data.put("UserID", UserID);
                data.put("section_id", section_id);
                data.put("credits_grade", "A+");
				JSONObject change_check = po.jsonpost("/register_User_Lecture", data);
				boolean success = change_check.getBoolean("success"); 
				System.out.println("강의추가 성공 여부: " + success);
            	
            	
            	
                dialogFrame.dispose();
                FrameManager.closeAllFrames(); // 모든 프레임 닫기
            	UserLecture ShowuserLecture = new UserLecture(userIDD, Section, DarK); 
            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
    
    private void AddNotDialog() {
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(31, 31, 31);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(70, 70, 70);
            colors.buttonBackground = new Color(50, 50, 50);
            colors.postbuttonColor = new Color(40, 40, 40);
            colors.RedText = new Color(200, 100, 100);
        }
        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(270, 400, 300, 150);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null); 

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 276, 110);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(borderWhite); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        
        // 다이얼로그 라벨 생성
        JLabel dialog2Label = new JLabel("이미 수강중인 강의입니다");
        dialog2Label.setBounds(15, 33, 250, 20);
        dialog2Label.setForeground(colors.Text); // 텍스트 색상(흰색)
        dialog2Label.setHorizontalAlignment(JLabel.CENTER);
        dialogPanel.add(dialog2Label);
        

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
}
