package main.java.com.pws.DBpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DBConnection {

    public static void main(String[] args) {
        retrieveUserData();
    }

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/UniversityCommunity";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "1234"; // MySQL 계정 비밀번호

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void retrieveUserData() {
        try (
                Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT * FROM users";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String UserID = resultSet.getString("UserID");
                        String UserPW = resultSet.getString("UserPW");
                        String UID = resultSet.getString("UID");
                        String Nickname = resultSet.getString("Nickname");
                        String LimitDate = resultSet.getString("LimitDate");
                        // 학교 및 학과 정보 조회
                        UniversityInfo universityInfo = getUniversityInfo(UID, "UID");

                        System.out.println(", 아이디: " + UserID + ", 비번: " + UserPW +
                                ", 학교코드: " + UID + ", 학교: " + universityInfo.getUName() +
                                ", 학과: " + universityInfo.getDepartment() +
                                ", 별명: " + Nickname + ", 제한날짜: " + LimitDate);

                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 유저정보 중복확인 메소드
    public static boolean checkIfIDExists(String where, String what) {
        boolean isDuplicate = false;

        try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT COUNT(*) FROM users WHERE " + where + " = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, what);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        int count = resultSet.getInt(1);
                        isDuplicate = (count > 0);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return isDuplicate;
    }

    // 학교정보 및 학과 정보를 저장하는 클래스 gg
    public static class UniversityInfo {
        private String uName;
        private String department;

        public UniversityInfo(String uName, String department) {
            this.uName = uName;
            this.department = department;
        }

        public String getUName() {
            return uName;
        }

        public String getDepartment() {
            return department;
        }
    }

    // UID를 이용해 학교정보 및 학과를 조회하는 메소드
    public static UniversityInfo getUniversityInfo(String uid, String what) {
        UniversityInfo universityInfo = null;

        try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT UName, department FROM university WHERE " + what + " = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, uid);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        String uName = resultSet.getString("UName");
                        String department = resultSet.getString("department");
                        universityInfo = new UniversityInfo(uName, department);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return universityInfo;
    }

    // 새로운 사용자를 users 테이블에 추가하는 메소드
    public static boolean registerUser(String userID, String userPW, String uid, String nickname, long date) {
        boolean isRegistrationSuccessful = false;

        try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
            String sql = "INSERT INTO users (UserID, UserPW, UID, Nickname, LimitDate) VALUES (?, ?, ?, ?, ?)";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, userID);
                preparedStatement.setString(2, userPW);
                preparedStatement.setString(3, uid);
                preparedStatement.setString(4, nickname);
                preparedStatement.setLong(5, date);

                int rowsAffected = preparedStatement.executeUpdate();
                isRegistrationSuccessful = (rowsAffected > 0);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return isRegistrationSuccessful;
    }

    // 새로운 게시물을 bulletin 테이블에 추가하는 메소드
    public static boolean registerPost(int BulletinID, String UserID, String UID,
            String BoardID, String BulletinTitle, String Bcontent, long Bdate) {
        boolean isRegistrationSuccessful = false;

        try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
            String sql = "INSERT INTO bulletin (BulletinID, UserID, UID, BoardID, BulletinTitle, Bcontent, Bdate) VALUES (?, ?, ?, ?, ?, ?, ?)";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, BulletinID);
                preparedStatement.setString(2, UserID);
                preparedStatement.setString(3, UID);
                preparedStatement.setString(4, BoardID);
                preparedStatement.setString(5, BulletinTitle);
                preparedStatement.setString(6, Bcontent);
                preparedStatement.setLong(7, Bdate);

                int rowsAffected = preparedStatement.executeUpdate();
                isRegistrationSuccessful = (rowsAffected > 0);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return isRegistrationSuccessful;
    }

    // 로그인 중복확인 및 인증 메소드
    public static boolean authenticateUser(String ID, String PW) {
        boolean isAuthenticated = false;
        try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
            String sqlAuth = "SELECT COUNT(*) FROM users WHERE UserID = ? AND UserPW = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sqlAuth)) {
                preparedStatement.setString(1, ID);
                preparedStatement.setString(2, PW);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        int count = resultSet.getInt(1);
                        isAuthenticated = (count > 0);
                    }
                }
            }
        } catch (SQLException log) {
            log.printStackTrace();
        }
        return isAuthenticated;
    }

    // 특정 정보를 검색하는 메소드
    public static String FindUserInformation(String table, String want, String what, String ID) {
        String result = null;
        try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
            // 쿼리를 수정하여 바인딩 및 조건 오류를 수정함
            String sql = "SELECT " + want + " FROM " + table + " WHERE " + what + " = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, ID); // UserID를 ?에 바인딩

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        result = resultSet.getString(want);
                    } else {
                        System.out.println("다음과 같은 sql문을 찾을 수 없습니다: " + sql);
                    }
                }
            }
        } catch (SQLException user) {
            user.printStackTrace();
        }
        return result;
    }

    // 특정 정보를 검색하는 메소드2
    public static String FindUser(String table, String want, String what, String ID) {
        String result = null;
        try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
            // 쿼리를 수정하여 바인딩 및 조건 오류를 수정함
            String sql = "SELECT " + want + " FROM " + table + " WHERE " + what + " = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, ID); // UserID를 ?에 바인딩

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        result = resultSet.getString(want);
                    } else {
                        System.out.println("다음과 같은 sql문을 찾을 수 없습니다: " + sql);
                    }
                }
            }
        } catch (SQLException user) {
            user.printStackTrace();
            // 예외 처리를 여기에 추가하시기 바랍니다.
        }
        return result;
    }

    // 특정 정보를 검색하는 메소드(long 형)
    public static long Findint(String table, String want, String what, String ID) {
        long result = 0;
        try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
            // 쿼리를 수정하여 바인딩 및 조건 오류를 수정함
            String sql = "SELECT " + want + " FROM " + table + " WHERE " + what + " = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, ID); // UserID를 ?에 바인딩

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        result = resultSet.getLong(want);
                    } else {
                        System.out.println("No results found for query: " + sql);
                    }
                }
            }
        } catch (SQLException user) {
            user.printStackTrace();
            // 예외 처리를 여기에 추가하시기 바랍니다.
        }
        return result;
    }

    // 특정 정보 바꾸기
    public static boolean ChangeUser(String table, String This1, String This2, String what, String change) {
        boolean changeSuccessful = false;

        try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
            // 사용자 정보 업데이트 쿼리
            String sql = "UPDATE " + table + " SET " + what + " = ? WHERE " + This1 + " = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, change);
                preparedStatement.setString(2, This2);

                // 쿼리 실행
                int affectedRows = preparedStatement.executeUpdate();

                // 변경이 성공적으로 이루어졌는지 확인
                if (affectedRows > 0) {
                    changeSuccessful = true;
                    System.out.println("정보 변경 성공!");
                } else {
                    System.out.println("정보 변경 실패: 해당하는 사용자를 찾을 수 없음");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // 예외 처리를 여기에 추가하시기 바랍니다.
        }

        return changeSuccessful;
    }

    // 게시물아이디 만드는 메소드 (가장 큰 게시물 아이디를 가져옴)
    public static int FindPostID(String table, String want) {
        int maxBulletinID = 0;
        try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
            // 쿼리를 수정하여 바인딩 및 조건 오류를 수정함
            String sql = "SELECT MAX(" + want + ") AS MaxBulletinID FROM " + table;

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        maxBulletinID = resultSet.getInt("MaxBulletinID");
                    } else {
                        System.out.println("No results found for query: " + sql);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // 예외 처리를 여기에 추가하시기 바랍니다.
        }
        return maxBulletinID;
    }

    // 모든 게시물의 갯수를 반환
    public static int boardFindPostID(String table, String want, String boardID) {
        int Count = 0;
        String query = "SELECT COUNT(*) AS count FROM " + table + " WHERE " + want + " = ?";

        try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD);
                PreparedStatement statement = connection.prepareStatement(query)) {
            // PreparedStatement를 사용하여 쿼리 준비
            statement.setString(1, boardID); // 매개변수 boardID를 설정

            try (ResultSet resultSet = statement.executeQuery()) {
                // 쿼리 실행 및 결과 가져오기
                if (resultSet.next()) {
                    Count = resultSet.getInt("count"); // 결과에서 count 가져오기
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // 예외 처리
        }
        return Count;
    }

    // 특정 컬럼의 개수를 반환하는 메소드
    public static int countRowsByColumnValue(String table, String column, String value) {
        int rowCount = 0;

        try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
            // 쿼리를 수정하여 바인딩 및 조건 오류를 수정함
            String sql = "SELECT COUNT(*) FROM " + table + " WHERE " + column + " = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, value);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        rowCount = resultSet.getInt(1);
                    } else {
                        System.out.println("No results found for query: " + sql);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // 예외 처리를 여기에 추가하시기 바랍니다.
        }

        return rowCount;
    }

    // 댓글 추가하느 코드
    public static boolean registerComments(int CommentsID, String UserID, String Ccontent,
            long Cdate, int likes, int BulletinID) {
        boolean isRegistrationSuccessful = false;

        try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
            String sql = "INSERT INTO comments (CommentsID, UserID, Ccontent, Cdate, likes, BulletinID) VALUES (?, ?, ?, ?, ?, ?)";

            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, CommentsID);
                preparedStatement.setString(2, UserID);
                preparedStatement.setString(3, Ccontent);
                preparedStatement.setLong(4, Cdate);
                preparedStatement.setInt(5, likes);
                preparedStatement.setInt(6, BulletinID);

                int rowsAffected = preparedStatement.executeUpdate();
                isRegistrationSuccessful = (rowsAffected > 0);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // 예외 처리를 여기에 추가하시기 바랍니다.
        }

        return isRegistrationSuccessful;
    }

    // 원하는 테이블 삭제
    public static boolean deleteColumn(String table, String what, String column) {
        boolean deletionSuccessful = false;

        try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
            String sql = "DELETE FROM " + table + " WHERE " + what + " = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, column);
                int rowsAffected = preparedStatement.executeUpdate();
                deletionSuccessful = (rowsAffected > 0);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // 예외 처리를 여기에 추가하시기 바랍니다.
        }

        return deletionSuccessful;
    }

    public static List<Integer> search(String keyword) {
        List<Integer> bulletinIDs = null;
        bulletinIDs = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
            // SQL 쿼리를 작성합니다.
            // BulletinTitle 또는 Bcontent 열에서 주어진 키워드를 포함하는 행의 BulletinID를 선택합니다.
            String sql = "SELECT BulletinID FROM bulletin WHERE BulletinTitle LIKE ? OR Bcontent LIKE ?";

            // 준비된 문장을 사용하여 SQL 쿼리를 실행하기 위한 PreparedStatement를 생성합니다.
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                // 첫 번째 바인딩 변수에 키워드를 설정합니다. BulletinTitle 열에서 키워드를 포함하는 행을 검색합니다.
                preparedStatement.setString(1, "%" + keyword + "%");
                // 두 번째 바인딩 변수에도 동일한 키워드를 설정합니다. Bcontent 열에서 키워드를 포함하는 행을 검색합니다.
                preparedStatement.setString(2, "%" + keyword + "%");

                // SQL 쿼리를 실행하고 결과 집합을 얻습니다.
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    // 결과 집합에서 다음 행을 반복하여 처리합니다.
                    while (resultSet.next()) {
                        // 결과 집합에서 BulletinID를 추출하여 리스트에 추가합니다.
                        int bulletinID = resultSet.getInt("BulletinID");
                        bulletinIDs.add(bulletinID);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // 예외 처리를 여기에 추가하시기 바랍니다.
        }

        // 검색된 BulletinID를 포함하는 리스트를 반환합니다.
        return bulletinIDs;
    }

    // 모든 게시물 정보를 가져오는 메소드
    public static List<List<String>> getAllBulletins() {
        List<List<String>> bulletins = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT * FROM bulletin";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        List<String> bulletin = new ArrayList<>();
                        bulletin.add(resultSet.getString("BulletinID"));
                        bulletin.add(resultSet.getString("UserID"));
                        bulletin.add(resultSet.getString("UID"));
                        bulletin.add(resultSet.getString("BoardID"));
                        bulletin.add(resultSet.getString("BulletinTitle"));
                        bulletin.add(resultSet.getString("Bcontent"));
                        bulletin.add(resultSet.getString("Bdate"));
                        bulletins.add(bulletin);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return bulletins;
    }
}
