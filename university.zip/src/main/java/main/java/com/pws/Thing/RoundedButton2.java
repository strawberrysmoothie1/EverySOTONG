package main.java.com.pws.Thing;

import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;

import javax.swing.Icon;
import javax.swing.JButton;

public class RoundedButton2 extends JButton {
    public RoundedButton2() {
        super();
        decorate();
    }

    public RoundedButton2(String text) {
        super("<html><div style='text-align: center;'>" + text.replaceAll("\n", "<br>") + "</div></html>");
        decorate();
    }

    public RoundedButton2(Icon icon) {
        super(icon);
        decorate();
    }

    public RoundedButton2(String text, Icon icon) {
        super("<html><div style='text-align: center;'>" + text.replaceAll("\n", "<br>") + "</div></html>", icon);
        decorate();
    }

    protected void decorate() {
        setBorderPainted(false);
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        int width = getWidth();
        int height = getHeight();
        Graphics2D graphics = (Graphics2D) g;
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        if (getModel().isArmed()) {
            graphics.setColor(getBackground().darker());
        } else if (getModel().isRollover()) {
            graphics.setColor(getBackground().brighter());
        } else {
            graphics.setColor(getBackground());
        }

        graphics.fillRoundRect(0, 0, width, height, 10, 10);
        FontMetrics fontMetrics = graphics.getFontMetrics();
        Rectangle stringBounds = fontMetrics.getStringBounds(getText(), graphics).getBounds();

        int textX = (width - stringBounds.width) / 2;
        int textY = (height - stringBounds.height) / 2 + fontMetrics.getAscent();

        graphics.setColor(getForeground());
        graphics.setFont(getFont());

        // Note: As the text is now HTML, the actual drawing of the string is handled by Swing,
        // so we don't need to manually draw the string here. We leave it up to Swing to handle it.

        super.paintComponent(g); // This will take care of the text painting
        graphics.dispose();
    }
}
