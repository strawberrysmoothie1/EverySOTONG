package main.java.com.pws.Login;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.border.Border;

import org.json.JSONObject;

import main.java.com.pws.Board.boardclass;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.RoundPasswordField;
import main.java.com.pws.Thing.RoundtextField;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.*;
import java.awt.*;

class UniversityCommunityApp {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> createAndShowGUI());
    }

    private static void createAndShowGUI() {
        login login = new login();
        String userIDD = login.getUserIDD();
        login.showFrame();
    }
}

public class login {

    String userIDD;
    private String Section;

    public JFrame frame;

    /**
     * 어플리케이션 실행 메소드
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    login window = new login();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }

    /**
     * 어플리케이션 생성자
     */
    public login() {
        initialize();
    }

    /**
     * 프레임 내용 초기화 메소드
     */
    private void initialize() {
        JSONObject data = new JSONObject();
        frame = new JFrame();
        frame.setBounds(100, 100, 650, 800); // 프레임 위치 및 크기 설정
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // 닫기 버튼 동작 설정
        frame.getContentPane().setLayout(null);

        // 테두리 스타일 설정
        Border borderRed = BorderFactory.createLineBorder(new Color(255, 0, 0), 2);
        Border borderWhite = BorderFactory.createLineBorder(new Color(255, 255, 255), 2);
        Border borderBlack = BorderFactory.createLineBorder(new Color(0, 0, 0), 1);

        JPanel panel = new JPanel();
        panel.setBounds(5, 0, 625, 755);
        frame.getContentPane().add(panel);
        panel.setLayout(null);
        panel.setBackground(new Color(255, 255, 255)); // 배경색 설정

        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(250, 250, 250));
        panel_1.setBounds(0, 0, 625, 755);
        panel.add(panel_1);
        panel_1.setLayout(null);
        panel_1.setBorder(borderRed); // 테두리 설정

        // 그림
        ImageIcon originalImageIcon = new ImageIcon("src/img/everygood.png");
        Image originalImage = originalImageIcon.getImage();
        Image scaledImage = originalImage.getScaledInstance(187, 47, Image.SCALE_SMOOTH);
        ImageIcon scaledImageIcon = new ImageIcon(scaledImage);
        JLabel imageLabel = new JLabel(scaledImageIcon);
        imageLabel.setBounds(230, 235, 187, 47);
        panel_1.add(imageLabel);


        
        // 계정 찾기 버튼
        JButton findbutton = new JButton("아이디/비밀번호 찾기"); // 버튼 생성 및 텍스트 설정
        findbutton.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                findlog f = new findlog();
                f.showFrame();
                frame.dispose();
            }
        });
        findbutton.setBounds(300, 420, 130, 30); // 버튼 위치 및 크기 설정
        findbutton.setBackground(new Color(255, 255, 255));// 배경색 설정 (빨간색)
        findbutton.setForeground(new Color(200, 200, 200)); // 텍스트 색상(흰색)
        panel_1.add(findbutton); // 패널에 버튼 추가
        Font findbuttonFont = new Font(findbutton.getFont().getName(), Font.BOLD, 12);
        findbutton.setFont(findbuttonFont);
        findbutton.setBorder(borderWhite); // 테두리 설정
        findbutton.requestFocusInWindow(); // 다른 컴포넌트에 포커스 설정
        findbutton.setContentAreaFilled(false);
        findbutton.setFocusPainted(false);
        findbutton.setOpaque(true);

        // 아이디 입력 필드
        RoundtextField IDfield = new RoundtextField(); // 텍스트 필드 생성
        IDfield.setBounds(225, 300, 200, 35); // 텍스트 필드 위치 및 크기 설정
        IDfield.setBackground(new Color(180, 180, 180)); // 배경색 설정
        IDfield.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        panel_1.add(IDfield); // 패널에 텍스트 필드 추가
        IDfield.setColumns(10); // 텍스트 필드 컬럼 수 설정
        IDfield.setBorder(borderBlack); // 테두리 설정
        IDfield.setDefaultText("  아이디"); // 기본 텍스트 설정

        // 비번 입력 필드
        RoundPasswordField PWfield = new RoundPasswordField(); // 텍스트 필드 생성
        PWfield.setBounds(225, 340, 200, 35); // 텍스트 필드 위치 및 크기 설정
        PWfield.setBackground(new Color(180, 180, 180)); // 배경색 설정
        PWfield.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        panel_1.add(PWfield); // 패널에 텍스트 필드 추가
        PWfield.setColumns(10); // 텍스트 필드 컬럼 수 설정
        PWfield.setBorder(borderBlack); // 테두리 설정

        // 로그인 실패 라벨
        JLabel loginduplicationLabel = new JLabel("");
        loginduplicationLabel.setBounds(245, 280, 200, 15); // Adjust the position and size as needed
        loginduplicationLabel.setForeground(new Color(0, 0, 255)); // Set label text color
        Font loginFont = new Font(loginduplicationLabel.getFont().getName(), Font.BOLD, 10);
        loginduplicationLabel.setFont(loginFont);
        panel_1.add(loginduplicationLabel);

        // 로그인 버튼
        RoundedButton loginButton = new RoundedButton("로그인"); // 버튼 생성 및 텍스트 설정
        loginButton.setBounds(225, 380, 200, 35); // 버튼 위치 및 크기 설정
        loginButton.setBackground(new Color(255, 0, 0)); // 배경색 설정
        loginButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        // 테두리 설정
        Border roundedBorder = BorderFactory.createLineBorder(new Color(255, 0, 0), 2, true);
        loginButton.setBorder(roundedBorder);
        panel_1.add(loginButton); // 패널에 버튼 추가
        Font buttonFont = new Font(loginButton.getFont().getName(), Font.PLAIN, 18);
        loginButton.setFont(buttonFont);

        // 로그인 기능을 수행하는 메서드
        ActionListener loginActionListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                userIDD = IDfield.getText();
                String userPW = PWfield.getText();

                data.put("table", "users");
                data.put("where", "UserID");
                data.put("what", userIDD);
                Post po = new Post();
    			JSONObject isDuplicate = po.jsonpost("/check_exists", data);
    			boolean isDuplicate1 = isDuplicate.getBoolean("exists");
                if (!isDuplicate1) { //안읽은거 있을 때
                    loginduplicationLabel.setText("아이디 또는 비밀번호가 틀렸습니다.");
                    loginduplicationLabel.setForeground(new Color(255, 0, 0));
                }else {
                
	                data.put("userIDD", userIDD);
	                JSONObject loginDuplicate = po.jsonpost("/authenticate_user", data);
	                String password = loginDuplicate.getString("pw");
	
	                if (password.equals(userPW)) {
	                    boardclass bo = new boardclass(userIDD, Section, 0);
	                    bo.showFrame();
	                    frame.dispose();
	                } else {
	                    loginduplicationLabel.setText("아이디 또는 비밀번호가 틀렸습니다.");
	                    loginduplicationLabel.setForeground(new Color(255, 0, 0));
	                }
                }
            }
        };

        // 로그인 버튼에 ActionListener 추가
        loginButton.addActionListener(loginActionListener);

        // ID와 비밀번호 입력 필드에 ActionListener 추가하여 엔터키로 로그인 수행
        IDfield.addActionListener(loginActionListener);
        PWfield.addActionListener(loginActionListener);

        // 회원가입 버튼
        JButton joinbutton = new JButton("회원가입"); // 버튼 생성 및 텍스트 설정
        joinbutton.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                join j = new join();
                j.showFrame();
                frame.dispose();
            }
        });
        joinbutton.setBounds(287, 450, 70, 30); // 버튼 위치 및 크기 설정
        joinbutton.setBackground(new Color(255, 255, 255));// 배경색 설정 (빨간색)
        joinbutton.setForeground(new Color(255, 0, 0)); // 텍스트 색상(흰색)
        panel_1.add(joinbutton); // 패널에 버튼 추가
        Font joinbuttonFont = new Font(joinbutton.getFont().getName(), Font.BOLD, 12);
        joinbutton.setFont(joinbuttonFont);
        joinbutton.setBorder(borderWhite); // 테두리 설정
        joinbutton.setContentAreaFilled(false);
        joinbutton.setFocusPainted(false);
        joinbutton.setOpaque(true);

    }

    public void showFrame() {
        frame.setVisible(true);
    }

    public String getUserIDD() {
        return userIDD;
    }
}
