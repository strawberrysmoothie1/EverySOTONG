package main.java.com.pws.User;

import javax.swing.border.Border;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.plaf.basic.BasicScrollBarUI;

import org.json.JSONObject;

import main.java.com.pws.Board.boardclass;
import main.java.com.pws.Board.showPost;
import main.java.com.pws.Login.login;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.RoundedBorder;
import main.java.com.pws.Thing.RoundtextField;
import main.java.com.pws.Thing.TodayDate;
import main.java.com.pws.Thing.collor;
import main.java.com.pws.dialog.MyPostDialog;
import main.java.com.pws.dialog.MycommentsDialog;
import main.java.com.pws.dialog.UserLimit;
import main.java.com.pws.Thing.RoundPasswordField;

import main.java.com.pws.Schedule.schedule;
import main.java.com.pws.Thing.FrameManager;
import main.java.com.pws.Thing.GetBulletins;
import main.java.com.pws.Thing.GetComments;
import main.java.com.pws.Thing.Post;

import java.awt.event.ActionListener;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.*;

import javax.swing.*;


public class mypage {
	private String userIDD;
    private String Section;
    private int DarK;

    JFrame frame;
    // 이미지
    String imagePath = "LoginSystem/src/img/22.png";

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    login window = new login();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }


    public mypage(String userIDD, String Section, int DarK) {
        this.userIDD = userIDD;
        this.Section = Section;
        this.DarK = DarK;

        initialize();
    }

    private void initialize() {
    	JSONObject data = new JSONObject();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
            colors.ToggleBtn = new Color(70, 70, 70);

        }
        
        frame = new JFrame();
        frame.setBounds(100, 100, 650, 800); // 프레임 위치 및 크기 설정
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // 닫기 버튼 동작 설정
        frame.getContentPane().setLayout(null); 
        
    	FrameManager.addFrame(frame);

        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        Border borderblack = BorderFactory.createLineBorder(colors.BoardPanel, 2);

        Border border = BorderFactory.createLineBorder(new Color(255, 0, 0), 2);

        JPanel panel = new JPanel();
        panel.setBounds(5, 0, 625, 755);
        frame.getContentPane().add(panel);
        panel.setLayout(null);
        panel.setBackground(colors.Ground); // 배경색 설정

        // 마이 페이지 라벨
        JLabel mypageLabel = new JLabel("설정");
        mypageLabel.setBounds(290, 95, 150, 30); // Adjust the position and size as needed
        mypageLabel.setForeground(new Color(100, 100, 100)); // Set label text color
        Font labelFont2 = new Font(mypageLabel.getFont().getName(), Font.BOLD, 22);
        mypageLabel.setFont(labelFont2);
        panel.add(mypageLabel);

        // 게시판 버튼
        JButton btnClickMe = new JButton("게시판"); // 버튼 생성 및 텍스트 설정
        btnClickMe.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                boardclass b = new boardclass(userIDD, Section, DarK); 
                b.showFrame();
                frame.dispose();
            }
        });
        btnClickMe.setBounds(210, 32, 100, 45); // 버튼 위치 및 크기 설정
        btnClickMe.setBackground(colors.Ground);
        btnClickMe.setForeground(colors.Text);
        panel.add(btnClickMe); // 패널에 버튼 추가
        Font buttonFont = new Font(btnClickMe.getFont().getName(), Font.PLAIN, 18);
        btnClickMe.setFont(buttonFont);
        btnClickMe.setBorder(borderWhite); // 테두리 설정
        btnClickMe.setContentAreaFilled(false);
        btnClickMe.setFocusPainted(false);
        btnClickMe.setOpaque(true);

        // 시간표 버튼
        JButton Schedule = new JButton("시간표"); // 버튼 생성 및 텍스트 설정
        Schedule.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                schedule a = new schedule(userIDD, Section, DarK);
                a.showFrame();
                frame.dispose();
            }
        });
        Schedule.setBounds(320, 32, 100, 45); // 버튼 위치 및 크기 설정
        Schedule.setBackground(colors.Ground);
        Schedule.setForeground(colors.Text);
        panel.add(Schedule); // 패널에 버튼 추가
        Font ScheduleFont = new Font(Schedule.getFont().getName(), Font.PLAIN, 18);
        Schedule.setFont(ScheduleFont);
        Schedule.setBorder(borderWhite); // 테두리 설정
        Schedule.setContentAreaFilled(false);
        Schedule.setFocusPainted(false);
        Schedule.setOpaque(true);
        
        
        // 다크모드 버튼
//        String DarkModeIMG = "src/img/dayMode.png";
//        if(DarK == 1) {
//        	DarkModeIMG = "src/img/darkMode.png";
//        }
//        ImageIcon DarkImageIcon = new ImageIcon(DarkModeIMG);
//        Image DarkImage = DarkImageIcon.getImage();
//        Image Dark1Image = DarkImage.getScaledInstance(60, 23, Image.SCALE_SMOOTH);
//        ImageIcon Dark1ImageIcon = new ImageIcon(Dark1Image);
//        JButton DarkModebutton = new JButton(Dark1ImageIcon);
//        DarkModebutton.setBackground(colors.Ground);
//        DarkModebutton.setBounds(490, 95, 60, 23);
//        DarkModebutton.setBorder(borderWhite);
//        DarkModebutton.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                if(DarK == 1) {
//                    mypage mypage = new mypage(userIDD, Section, 0);
//                    mypage.showFrame();
//                } else {
//                    mypage mypage = new mypage(userIDD, Section, 1);
//                    mypage.showFrame();
//                }
//                frame.dispose();
//            }
//        });
//        DarkModebutton.setContentAreaFilled(false);
//        DarkModebutton.setFocusPainted(false);
//        DarkModebutton.setOpaque(true);
//        panel.add(DarkModebutton);
        
     // 패널 설정 및 버튼 추가
//        JPanel togglePanel = new JPanel();
//        togglePanel.setBackground(colors.Ground);
//        togglePanel.setBounds(485, 93, 60, 24);
//        panel.add(togglePanel);
//        togglePanel.setLayout(null);
//        togglePanel.setBorder(border); // 테두리 설정
//        RoundedBorder togglePanel1 = new RoundedBorder(20);
//        togglePanel.setBorder(togglePanel1);

        JToggleButton toggleButton = createToggleButton();
        toggleButton.setBounds(465, 100, 60, 24); // 버튼 위치 및 크기 설정
        panel.add(toggleButton);

        // 패널 생성
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(colors.Ground);
        panel_1.setBounds(73, 140, 480, 100);
        panel.add(panel_1);
        panel_1.setLayout(null);
        panel_1.setBorder(border); // 테두리 설정
        RoundedBorder roundedBorder = new RoundedBorder(20);
        panel_1.setBorder(roundedBorder);

        // 유저
        ImageIcon useroriginalImageIcon = new ImageIcon("src/img/user.png");
        Image useroriginalImage = useroriginalImageIcon.getImage();
        Image userscaledImage = useroriginalImage.getScaledInstance(40, 37, Image.SCALE_SMOOTH);
        ImageIcon userscaledImageIcon = new ImageIcon(userscaledImage);
        JLabel userimageLabel = new JLabel(userscaledImageIcon);
        userimageLabel.setBounds(11, 34, 50, 50);
        panel_1.add(userimageLabel);

        // 에브리소통 그림2
        String everyTimeIMG = "src/img/everygood.png";
        if(DarK == 1) {
        	everyTimeIMG = "src/img/everygoodDark.png";
        }
        ImageIcon everyImageIcon = new ImageIcon(everyTimeIMG);
        Image everyImage = everyImageIcon.getImage();
        Image every1Image = everyImage.getScaledInstance(120, 30, Image.SCALE_SMOOTH);
        ImageIcon every1ImageIcon = new ImageIcon(every1Image);
        JButton image1Button = new JButton(every1ImageIcon);
        image1Button.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        image1Button.setBounds(30, 40, 120, 30);
        image1Button.setBorder(borderWhite);
        image1Button.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                boardclass b = new boardclass(userIDD, Section, DarK);
                b.showFrame();
                frame.dispose();
            }
        });
        image1Button.setContentAreaFilled(false);
        image1Button.setFocusPainted(false);
        image1Button.setOpaque(true);
        panel.add(image1Button);

        // 내 정보 라벨
        JLabel myinforLabel = new JLabel("내 정보");
        myinforLabel.setBounds(15, 6, 150, 30); // Adjust the position and size as needed
        myinforLabel.setForeground(colors.Text); // Set label text color
        Font labelFont3 = new Font(myinforLabel.getFont().getName(), Font.BOLD, 16);
        myinforLabel.setFont(labelFont3);
        panel_1.add(myinforLabel);

        // 로그아웃 버튼
        RoundedButton logoutbutton = new RoundedButton("로그아웃");
        logoutbutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                login a = new login();
                a.showFrame();
                frame.dispose();
                // 버튼 동작 추가
            }
        });
        logoutbutton.setBackground(new Color(255, 0, 0));// 배경색 설정 (빨간색)
        logoutbutton.setForeground(colors.Ground); // 텍스트 색상(흰색)
        logoutbutton.setBounds(385, 15, 70, 25);
        Font RedFont = new Font(logoutbutton.getFont().getName(), Font.BOLD, 12);
        logoutbutton.setFont(RedFont);
        panel_1.add(logoutbutton);
        

        // 로그인 화면에서 아이디 받고 그 아이디로 유저 정보찾기        
        data.put("table", "users");
        data.put("want", "Nickname");
        data.put("what", "UserID");
        data.put("user_id", userIDD);
        Post po = new Post();
    	JSONObject SearchNickname1 = po.jsonpost("/find_user_information", data);
    	String SearchNickname = SearchNickname1.getString("Nickname");
                   
        data.put("table", "users");
        data.put("want", "UID");
        data.put("what", "UserID");
        data.put("user_id", userIDD);
    	JSONObject SearchSchoolcode1 = po.jsonpost("/find_user_information", data);
    	String SearchSchoolcode = SearchSchoolcode1.getString("UID");
             
        data.put("table", "users");
        data.put("want", "UserPW");
        data.put("what", "UserID");
        data.put("user_id", userIDD);
    	JSONObject SearchPW1 = po.jsonpost("/find_user_information", data);
    	String SearchPW = SearchPW1.getString("UserPW");
                
        data.put("table", "university");
        data.put("want", "UName");
        data.put("what", "UID");
        data.put("user_id", SearchSchoolcode);
    	JSONObject SearchSchoolname1 = po.jsonpost("/find_user_information", data);
    	String SearchSchoolname = SearchSchoolname1.getString("UName");
        
        data.put("table", "university");
        data.put("want", "department");
        data.put("what", "UID");
        data.put("user_id", SearchSchoolcode);
    	JSONObject Searchdepartment1 = po.jsonpost("/find_user_information", data);
    	String Searchdepartment = Searchdepartment1.getString("department");
        
        JLabel Nickname = new JLabel(SearchNickname + " / " + userIDD);
        Nickname.setBounds(67, 40, 150, 13); // Adjust the position and size as needed
        Nickname.setForeground(colors.Text); // Set label text color
        Font labelFont4 = new Font(Nickname.getFont().getName(), Font.BOLD, 12);
        Nickname.setFont(labelFont4);
        panel_1.add(Nickname);

        JLabel Schoolname = new JLabel(SearchSchoolname);
        Schoolname.setBounds(69, 57, 60, 10); // Adjust the position and size as needed
        Schoolname.setForeground(colors.Text); // Set label text color
        Font labelFont5 = new Font(Schoolname.getFont().getName(), Font.BOLD, 9);
        Schoolname.setFont(labelFont5);
        panel_1.add(Schoolname);

        JLabel department = new JLabel(Searchdepartment);
        department.setBounds(69, 68, 100, 10); // Adjust the position and size as needed
        department.setForeground(new Color(100, 100, 100)); // Set label text color
        department.setFont(labelFont5);
        panel_1.add(department);

        // 패널 생성
        JPanel panel_2 = new JPanel();
        panel_2.setBackground(colors.Ground);
        panel_2.setBounds(73, 250, 480, 135);
        panel.add(panel_2);
        panel_2.setLayout(null);
        panel_2.setBorder(border); // 테두리 설정
        RoundedBorder roundedBorder2 = new RoundedBorder(20);
        panel_2.setBorder(roundedBorder2);

        // 계정 라벨
        JLabel AccountLabel = new JLabel("계정");
        AccountLabel.setBounds(15, 11, 70, 20); // Adjust the position and size as needed
        AccountLabel.setForeground(colors.Text); // Set label text color
        AccountLabel.setFont(labelFont3);
        panel_2.add(AccountLabel);

        // 비밀번호 변경
        JButton PWchangebutton = new JButton("비밀번호 변경");
        PWchangebutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SelfCheckDialog("PWchangeDialog", SearchPW);
            }
        });
        PWchangebutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        PWchangebutton.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
        PWchangebutton.setBounds(20, 45, 450, 25);
        PWchangebutton.setHorizontalAlignment(SwingConstants.LEFT);
        PWchangebutton.setBorder(borderWhite);
        Font labelFont6 = new Font(Schoolname.getFont().getName(), Font.BOLD, 12);
        PWchangebutton.setFont(labelFont6);
        PWchangebutton.setContentAreaFilled(false);
        PWchangebutton.setFocusPainted(false);
        PWchangebutton.setOpaque(true);
        panel_2.add(PWchangebutton);

        // 학교 변경
        JButton Schoolchangebutton = new JButton("학교 설정");
        Schoolchangebutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SelfCheckDialog("SchoolchangeDialog", SearchPW);
            }
        });
        Schoolchangebutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        Schoolchangebutton.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
        Schoolchangebutton.setBounds(20, 70, 450, 25);
        Schoolchangebutton.setHorizontalAlignment(SwingConstants.LEFT);
        Schoolchangebutton.setBorder(borderWhite);
        Schoolchangebutton.setFont(labelFont6);
        Schoolchangebutton.setContentAreaFilled(false);
        Schoolchangebutton.setFocusPainted(false);
        Schoolchangebutton.setOpaque(true);
        panel_2.add(Schoolchangebutton);

        // 학과 변경
        JButton Departmentchangebutton = new JButton("학과 설정");
        Departmentchangebutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SelfCheckDialog("DepartmentchangeDialog", SearchPW);
            }
        });
        Departmentchangebutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        Departmentchangebutton.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
        Departmentchangebutton.setBounds(20, 95, 450, 25);
        Departmentchangebutton.setHorizontalAlignment(SwingConstants.LEFT);
        Departmentchangebutton.setBorder(borderWhite);
        Departmentchangebutton.setFont(labelFont6);
        Departmentchangebutton.setContentAreaFilled(false);
        Departmentchangebutton.setFocusPainted(false);
        Departmentchangebutton.setOpaque(true);
        panel_2.add(Departmentchangebutton);

        JPanel panel_3 = new JPanel();
        panel_3.setBackground(colors.Ground);
        panel_3.setBounds(73, 395, 480, 160);
        panel.add(panel_3);
        panel_3.setLayout(null);
        panel_3.setBorder(border); // 테두리 설정
        RoundedBorder roundedBorder3 = new RoundedBorder(20);
        panel_3.setBorder(roundedBorder3);

        // 커뮤니티 라벨
        JLabel CommunityLabel = new JLabel("커뮤니티");
        CommunityLabel.setBounds(15, 11, 70, 20); // Adjust the position and size as needed
        CommunityLabel.setForeground(colors.Text); // Set label text color
        CommunityLabel.setFont(labelFont3);
        panel_3.add(CommunityLabel);

        // 닉네임 설정
        JButton Nickchangebutton = new JButton("닉네임 설정");
        Nickchangebutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SelfCheckDialog("NicknamechangeDialog", SearchPW);
            }
        });
        Nickchangebutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        Nickchangebutton.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
        Nickchangebutton.setBounds(20, 45, 450, 25);
        Nickchangebutton.setHorizontalAlignment(SwingConstants.LEFT);
        Nickchangebutton.setBorder(borderWhite);
        Nickchangebutton.setFont(labelFont6);
        Nickchangebutton.setContentAreaFilled(false);
        Nickchangebutton.setFocusPainted(false);
        Nickchangebutton.setOpaque(true);
        panel_3.add(Nickchangebutton);

        // 내가 쓴 글
        JButton WrittenBbutton = new JButton("내가 쓴 글");
        WrittenBbutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	MyPostDialog myPostDialog = new MyPostDialog(userIDD, userIDD, Section, DarK);
            }
        });
        WrittenBbutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        WrittenBbutton.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
        WrittenBbutton.setBounds(20, 70, 450, 25);
        WrittenBbutton.setHorizontalAlignment(SwingConstants.LEFT);
        WrittenBbutton.setBorder(borderWhite);
        WrittenBbutton.setFont(labelFont6);
        WrittenBbutton.setContentAreaFilled(false);
        WrittenBbutton.setFocusPainted(false);
        WrittenBbutton.setOpaque(true);
        panel_3.add(WrittenBbutton);

        // 댓글 단 글
        JButton Commentbutton = new JButton("댓글 단 글");
        Commentbutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	MycommentsDialog mycommentsDialog = new MycommentsDialog(userIDD, userIDD, Section, DarK);

            }
        });
        Commentbutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        Commentbutton.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
        Commentbutton.setBounds(20, 95, 450, 25);
        Commentbutton.setHorizontalAlignment(SwingConstants.LEFT);
        Commentbutton.setBorder(borderWhite);
        Commentbutton.setFont(labelFont6);
        Commentbutton.setContentAreaFilled(false);
        Commentbutton.setFocusPainted(false);
        Commentbutton.setOpaque(true);
        panel_3.add(Commentbutton);

        // 이용 제한 내역
        JButton Limitbutton = new JButton("이용 제한 내역");
        Limitbutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                LimitDialog(userIDD);

            }
        });
        Limitbutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        Limitbutton.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
        Limitbutton.setBounds(20, 120, 450, 25);
        Limitbutton.setHorizontalAlignment(SwingConstants.LEFT);
        Limitbutton.setBorder(borderWhite);
        Limitbutton.setFont(labelFont6);
        Limitbutton.setContentAreaFilled(false);
        Limitbutton.setFocusPainted(false);
        Limitbutton.setOpaque(true);
        panel_3.add(Limitbutton);

    }

    // 본인확인
    private void SelfCheckDialog(String methodName, String PW) {
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
            colors.ToggleBtn = new Color(70, 70, 70);
        }
        Border borderBlack = BorderFactory.createLineBorder(new Color(0, 0, 0), 1);
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(270, 400, 300, 190);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 276, 150);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255), 1)); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel SuccessLabel = new JLabel("※본인 확인※");
        SuccessLabel.setBounds(95, 20, 200, 15);
        SuccessLabel.setForeground(new Color(150, 100, 100)); // 텍스트 색상(흰색)
        Font SuccessFont = new Font(SuccessLabel.getFont().getName(), Font.BOLD, 14);
        SuccessLabel.setFont(SuccessFont);
        dialogPanel.add(SuccessLabel);

        RoundPasswordField PWfield = new RoundPasswordField(); // 텍스트 필드 생성
        PWfield.setBounds(37, 55, 200, 30); // 텍스트 필드 위치 및 크기 설정
        PWfield.setBackground(colors.BoardPanel); // 배경색 설정
        PWfield.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        dialogPanel.add(PWfield); // 패널에 텍스트 필드 추가
        PWfield.setColumns(10); // 텍스트 필드 컬럼 수 설정
        PWfield.setBorder(borderBlack); // 테두리 설정

        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("확인");
        confirmButton.setBounds(107, 120, 65, 20);
        confirmButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)

        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String GetPW = PWfield.getText();

                if (PW.equals(GetPW)) {
                    try {
                        Method method = mypage.class.getDeclaredMethod(methodName);
                        method.setAccessible(true);
                        method.invoke(mypage.this); // 메소드 실행
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }

                } else {
                    NoSelfCheckDialog();
                }
                dialogFrame.dispose();

            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }

    // 실패
    private void NoSelfCheckDialog() {
        collor colors = new collor(); 
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
            colors.ToggleBtn = new Color(70, 70, 70);
        }
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(270, 400, 300, 150);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 276, 110);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255), 1)); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel SuccessLabel = new JLabel("비밀번호가 다릅니다");
        SuccessLabel.setBounds(86, 20, 200, 15);
        SuccessLabel.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
        Font SuccessFont = new Font(SuccessLabel.getFont().getName(), Font.BOLD, 12);
        SuccessLabel.setFont(SuccessFont);
        dialogPanel.add(SuccessLabel);

        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("확인");
        confirmButton.setBounds(107, 80, 65, 20);
        confirmButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialogFrame.dispose();

            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }

    //비번바꾸기
	private void PWchangeDialog() {
        collor colors = new collor(); 
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
            colors.ToggleBtn = new Color(70, 70, 70);
        }
    	JSONObject data = new JSONObject();   	
    	Border borderBlack = BorderFactory.createLineBorder(new Color(0, 0, 0), 2);
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(250, 350, 350, 220);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 326, 178);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255), 1)); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel MyPostLabel = new JLabel("비밀번호 설정");
        MyPostLabel.setBounds(108, 25, 200, 20);
        MyPostLabel.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
        Font MyPostFont = new Font(MyPostLabel.getFont().getName(), Font.BOLD, 18);
        MyPostLabel.setFont(MyPostFont);
        dialogPanel.add(MyPostLabel);

        // 비밀번호 입력 필드
        RoundPasswordField usePWField = new RoundPasswordField();
        usePWField.setBounds(60, 65, 200, 20);
        usePWField.setBackground(colors.BoardPanel);
        usePWField.setForeground(new Color(255, 255, 255));
        dialogPanel.add(usePWField);
        usePWField.setColumns(10);
        usePWField.setBorder(borderBlack);
        // 비밀번호 확인 입력 필드
        RoundPasswordField usePW2Field = new RoundPasswordField();
        usePW2Field.setBounds(60, 95, 200, 20);
        usePW2Field.setBackground(colors.BoardPanel);
        usePW2Field.setForeground(new Color(255, 255, 255));
        dialogPanel.add(usePW2Field);
        usePW2Field.setColumns(10);
        usePW2Field.setBorder(borderBlack);

        // 비밀번호 일치 여부를 표시하는 라벨
        JLabel passwordMatchLabel = new JLabel("");
        Font labelFont2 = new Font(passwordMatchLabel.getFont().getName(), Font.BOLD, 9);

        passwordMatchLabel.setFont(labelFont2);
        dialogPanel.add(passwordMatchLabel);

        // 비밀번호 확인 필드에 DocumentListener 추가
        usePW2Field.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                checkPasswordMatch();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                checkPasswordMatch();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                checkPasswordMatch();
            }

            private void checkPasswordMatch() {
                String password1 = usePWField.getText();
                String password2 = usePW2Field.getText();

                if (password1.equals(password2)) {
                    if (password1.length() < 8) {
                        passwordMatchLabel.setText("최소 8자리 입력");
                        passwordMatchLabel.setForeground(new Color(255, 0, 0)); // 빨간색
                        passwordMatchLabel.setBounds(125, 115, 200, 20);
                    } else {
                        passwordMatchLabel.setText("비밀번호 일치함");
                        passwordMatchLabel.setForeground(new Color(0, 0, 255)); // 파란색
                        passwordMatchLabel.setBounds(125, 115, 200, 20);
                    }
                } else {
                    passwordMatchLabel.setText("비밀번호 일치하지 않음");
                    passwordMatchLabel.setForeground(new Color(255, 0, 0)); // 빨간색
                    passwordMatchLabel.setBounds(112, 115, 200, 20);
                }
            }
        });
        
        
        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("변경");
        confirmButton.setBounds(128, 140, 65, 20);
        confirmButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	String password1 = usePWField.getText();
                String password2 = usePW2Field.getText();
            	
            	if (password1.equals(password2)) {
                    if (password1.length() < 8) {
                        passwordMatchLabel.setText("최소 8자리 입력");
                        passwordMatchLabel.setForeground(new Color(255, 0, 0)); // 빨간색
                        passwordMatchLabel.setBounds(125, 115, 200, 20);
                    } else {
                        data.put("table", "users");
                        data.put("this1", "UserID");
                        data.put("this2", userIDD);
                        data.put("what", "UserPW");
                        data.put("change", password2);
                        Post po = new Post();
        				JSONObject change_check = po.jsonpost("/change_user", data);
        				boolean success = change_check.getBoolean("success"); 
        				System.out.println("변경 성공 여부: " + success);
                    	dialogFrame.dispose();
                    	showSuccessDialog("비밀번호 ");
                    }
                } else {
                    passwordMatchLabel.setText("비밀번호 일치하지 않음");
                    passwordMatchLabel.setForeground(new Color(255, 0, 0)); // 빨간색
                    passwordMatchLabel.setBounds(112, 115, 200, 20);
                }
            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
   
    
    //학교 설정
	private void SchoolchangeDialog() {
    	JSONObject data = new JSONObject();
        collor colors = new collor(); 
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
            colors.ToggleBtn = new Color(70, 70, 70);
        }
    	
    	Border borderBlack = BorderFactory.createLineBorder(new Color(0, 0, 0), 2);
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(250, 350, 350, 220);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 326, 178);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255), 1)); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel MyPostLabel = new JLabel("학교 설정");
        MyPostLabel.setBounds(122, 25, 200, 20);
        MyPostLabel.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
        Font MyPostFont = new Font(MyPostLabel.getFont().getName(), Font.BOLD, 18);
        MyPostLabel.setFont(MyPostFont);
        dialogPanel.add(MyPostLabel);
        
        data.put("table", "users");
        data.put("want", "UID");
        data.put("what", "UserID");
        data.put("user_id", userIDD);
        Post po = new Post();
    	JSONObject UserUID1 = po.jsonpost("/find_user_information", data);
    	String UserUID = UserUID1.getString("UID");
        
        data.put("what", UserUID);
		JSONObject universityInfo = po.jsonpost("/get_university_info", data);
		String getUName = universityInfo.getString("uName");  
        
        // 중복 라벨
        JLabel NickduplicationLabel = new JLabel("현제 학교: " +getUName );
        NickduplicationLabel.setBounds(117, 105, 150, 15); // Adjust the position and size as needed
        NickduplicationLabel.setForeground(new Color(100, 100, 150)); // Set label text color
        Font labelFont2 = new Font(NickduplicationLabel.getFont().getName(), Font.BOLD, 9);
        NickduplicationLabel.setFont(labelFont2);
        dialogPanel.add(NickduplicationLabel);
        
        // 학과 입력 필드
        RoundtextField UniversityField = new RoundtextField();
        UniversityField.setBounds(60, 70, 200, 20);
        UniversityField.setBackground(colors.BoardPanel);
        UniversityField.setForeground(new Color(255, 255, 255));
        dialogPanel.add(UniversityField);
        UniversityField.setColumns(10);
        UniversityField.setBorder(borderBlack);
        UniversityField.setDefaultText("  학교");

        // 별명중복 확인 버튼 (원래 중복 확인 기능은 여기에 넣어도 됨)
        RoundedButton NicknameDuplicationButton = new RoundedButton("검색");
        NicknameDuplicationButton.setBounds(260, 71, 30, 20);
        Font checkFont1 = new Font(NicknameDuplicationButton.getFont().getName(), Font.PLAIN, 10);
        NicknameDuplicationButton.setFont(checkFont1);

        NicknameDuplicationButton.setBackground(colors.buttonBackground);// 배경색 설정 (빨간색)
        NicknameDuplicationButton.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        dialogPanel.add(NicknameDuplicationButton); // 패널에 버튼 추가
        NicknameDuplicationButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent en) {
                // 여기서 데이터베이스 조회하여 중복 여부 확인
        		
        		String cutDepartment = UserUID.substring(UserUID.length() - 2);        		
                String Universitysave = UniversityField.getText();
                String newUID = Universitysave + cutDepartment;  
                try {
                    Integer.parseInt(Universitysave);                
                    System.out.println("입력한 내용은 정수입니다." + newUID);
                    data.put("what", newUID);
            		JSONObject universityInfo = po.jsonpost("/get_university_info", data);
            		String getUName = universityInfo.getString("uName"); 
            		if (getUName.equals("정보")) {
            			NickduplicationLabel.setText("학교 코드를 정확히 입력해 주세요.");
            			NickduplicationLabel.setForeground(new Color(150, 100, 100));
            			NickduplicationLabel.setBounds(92, 105, 150, 15);
                    } else {
                    	NickduplicationLabel.setText(getUName);
                        NickduplicationLabel.setForeground(new Color(100, 100, 150));
                        NickduplicationLabel.setBounds(137, 105, 150, 15);
                    }
                                        
                } catch (NumberFormatException e) {
                    System.out.println("입력한 내용은 문자열입니다.");
    				data.put("table", "university");
    		        data.put("want", "UID");
    		        data.put("where1", "UID");
    		        data.put("what1", cutDepartment);
    		        data.put("where2", "UName");
    		        data.put("what2", Universitysave);
    		    	JSONObject SearchUID1 = po.jsonpost("/find_like_wnat", data);
    		    	boolean DepartDuplicate = SearchUID1.getBoolean("check");

            		if (DepartDuplicate) {
            			NickduplicationLabel.setText(Universitysave);
                        NickduplicationLabel.setForeground(new Color(100, 100, 150));
                        NickduplicationLabel.setBounds(137, 105, 150, 15);
            			
                    } else {
                    	NickduplicationLabel.setText("학교 정보를 정확히 입력해 주세요.");
            			NickduplicationLabel.setForeground(new Color(150, 100, 100));
            			NickduplicationLabel.setBounds(92, 105, 150, 15);
                    }
                    
                }
        		
        	
            }
        });
        
        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("변경");
        confirmButton.setBounds(128, 140, 65, 20);
        confirmButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	
        		String cutDepartment = UserUID.substring(UserUID.length() - 2);        		
                String Universitysave = UniversityField.getText();
                String newUID = Universitysave + cutDepartment;  
                try {
                    Integer.parseInt(Universitysave);                
                    System.out.println("입력한 내용은 정수입니다." + newUID);
                    data.put("what", newUID);
            		JSONObject universityInfo = po.jsonpost("/get_university_info", data);
            		String getUName = universityInfo.getString("uName"); 
            		if (getUName.equals("정보")) {
            			NickduplicationLabel.setText("학교 코드를 정확히 입력해 주세요.");
            			NickduplicationLabel.setForeground(new Color(150, 100, 100));
            			NickduplicationLabel.setBounds(92, 105, 150, 15);
                    } else {
                    	data.put("table", "users");
                        data.put("this1", "UserID");
                        data.put("this2", userIDD);
                        data.put("what", "UID");
                        data.put("change", newUID);
        				JSONObject change_check = po.jsonpost("/change_user", data);
        				boolean success = change_check.getBoolean("success"); 
        				System.out.println("변경 성공 여부: " + success);
                    	dialogFrame.dispose();
                    	showSuccessDialog("학교 ");
                    }
                                        
                } catch (NumberFormatException s) {
                    System.out.println("입력한 내용은 문자열입니다.");
    				data.put("table", "university");
    		        data.put("want", "UID");
    		        data.put("where1", "UID");
    		        data.put("what1", cutDepartment);
    		        data.put("where2", "UName");
    		        data.put("what2", Universitysave);
    		    	JSONObject SearchUID1 = po.jsonpost("/find_like_wnat", data);
    		    	boolean DepartDuplicate = SearchUID1.getBoolean("check");
    		    	String searchUID = SearchUID1.optString("UID", null);

            		if (DepartDuplicate) {
            			data.put("table", "users");
                        data.put("this1", "UserID");
                        data.put("this2", userIDD);
                        data.put("what", "UID");
                        data.put("change", searchUID);
        				JSONObject change_check = po.jsonpost("/change_user", data);
        				boolean success = change_check.getBoolean("success"); 
        				System.out.println("변경 성공 여부: " + success);
                    	dialogFrame.dispose();
                    	showSuccessDialog("학교 ");
            			
                    } else {
                    	NickduplicationLabel.setText("학교 정보를 정확히 입력해 주세요.");
            			NickduplicationLabel.setForeground(new Color(100, 100, 150));
            			NickduplicationLabel.setBounds(92, 105, 150, 15);
                    }
                    
                }
            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
   
	//학과설정
	private void DepartmentchangeDialog() {
    	JSONObject data = new JSONObject();
        collor colors = new collor(); 
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
            colors.ToggleBtn = new Color(70, 70, 70);
        }
    	Border borderBlack = BorderFactory.createLineBorder(new Color(0, 0, 0), 2);
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(250, 350, 350, 220);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 326, 178);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255), 1)); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel MyPostLabel = new JLabel("학과 설정");
        MyPostLabel.setBounds(122, 25, 200, 20);
        MyPostLabel.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
        Font MyPostFont = new Font(MyPostLabel.getFont().getName(), Font.BOLD, 18);
        MyPostLabel.setFont(MyPostFont);
        dialogPanel.add(MyPostLabel);
        
        data.put("table", "users");
        data.put("want", "UID");
        data.put("what", "UserID");
        data.put("user_id", userIDD);
        Post po = new Post();
    	JSONObject UserUID1 = po.jsonpost("/find_user_information", data);
    	String UserUID = UserUID1.getString("UID");
        
        data.put("what", UserUID);
		JSONObject universityInfo = po.jsonpost("/get_university_info", data);
		String getDepartment = universityInfo.getString("department"); 
        
        // 중복 라벨
        JLabel NickduplicationLabel = new JLabel("현제 학과: " +getDepartment );
        NickduplicationLabel.setBounds(110, 105, 150, 15); // Adjust the position and size as needed
        NickduplicationLabel.setForeground(new Color(100, 100, 150)); // Set label text color
        Font labelFont2 = new Font(NickduplicationLabel.getFont().getName(), Font.BOLD, 9);
        NickduplicationLabel.setFont(labelFont2);
        dialogPanel.add(NickduplicationLabel);
        
        // 학과 입력 필드
        RoundtextField DepartmentField = new RoundtextField();
        DepartmentField.setBounds(60, 70, 200, 20);
        DepartmentField.setBackground(colors.BoardPanel);
        DepartmentField.setForeground(new Color(255, 255, 255));
        dialogPanel.add(DepartmentField);
        DepartmentField.setColumns(10);
        DepartmentField.setBorder(borderBlack);
        DepartmentField.setDefaultText("  학과");

        // 별명중복 확인 버튼 (원래 중복 확인 기능은 여기에 넣어도 됨)
        RoundedButton NicknameDuplicationButton = new RoundedButton("검색");
        NicknameDuplicationButton.setBounds(260, 71, 30, 20);
        Font checkFont1 = new Font(NicknameDuplicationButton.getFont().getName(), Font.PLAIN, 10);
        NicknameDuplicationButton.setFont(checkFont1);

        NicknameDuplicationButton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        NicknameDuplicationButton.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        dialogPanel.add(NicknameDuplicationButton); // 패널에 버튼 추가
        NicknameDuplicationButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent en) {
                // 여기서 데이터베이스 조회하여 중복 여부 확인
        		
        		String cutuniversity = UserUID.substring(0, UserUID.length() - 2);
        		
                String Departmentsave = DepartmentField.getText();
                try {
                    Integer.parseInt(Departmentsave);
                    String newUID = cutuniversity + Departmentsave;                    
                    System.out.println("입력한 내용은 정수입니다." + newUID);
                    data.put("what", newUID);
            		JSONObject universityInfo = po.jsonpost("/get_university_info", data);
            		String getDepartment = universityInfo.getString("department");
            		if (getDepartment.equals("없음")) {
            			NickduplicationLabel.setText("학과 코드를 정확히 입력해 주세요.");
            			NickduplicationLabel.setForeground(new Color(150, 100, 100));
            			NickduplicationLabel.setBounds(92, 105, 150, 15);
                    } else {
                    	NickduplicationLabel.setText(getDepartment);
                        NickduplicationLabel.setForeground(new Color(100, 100, 150));
                        NickduplicationLabel.setBounds(131, 105, 150, 15);
                    }
                                        
                } catch (NumberFormatException e) {
                    System.out.println("입력한 내용은 문자열입니다.");
    				data.put("table", "university");
    		        data.put("want", "UID");
    		        data.put("where1", "UID");
    		        data.put("what1", cutuniversity);
    		        data.put("where2", "department");
    		        data.put("what2", Departmentsave);
    		    	JSONObject SearchUID1 = po.jsonpost("/find_like_wnat", data);
    		    	boolean DepartDuplicate = SearchUID1.getBoolean("check");

            		if (DepartDuplicate) {
            			NickduplicationLabel.setText(Departmentsave);
                        NickduplicationLabel.setForeground(new Color(100, 100, 150));
                        NickduplicationLabel.setBounds(131, 105, 150, 15);
            			
                    } else {
                    	NickduplicationLabel.setText("학과 정보를 정확히 입력해 주세요.");
            			NickduplicationLabel.setForeground(new Color(150, 100, 100));
            			NickduplicationLabel.setBounds(92, 105, 150, 15);
                    }
                    
                }
        		
        	
            }
        });
        
        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("변경");
        confirmButton.setBounds(128, 140, 65, 20);
        confirmButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	
            	String cutuniversity = UserUID.substring(0, UserUID.length() - 2);
        		
                String Departmentsave = DepartmentField.getText();
                try {
                    Integer.parseInt(Departmentsave);
                    String newUID = cutuniversity + Departmentsave;                    
                    System.out.println("입력한 내용은 정수입니다." + newUID);
                    data.put("what", newUID);
            		JSONObject universityInfo = po.jsonpost("/get_university_info", data);
            		String getDepartment = universityInfo.getString("department");
            		if (getDepartment.equals("없음")) {
            			NickduplicationLabel.setText("학과 코드를 정확히 입력해 주세요.");
            			NickduplicationLabel.setForeground(new Color(150, 100, 100));
            			NickduplicationLabel.setBounds(92, 105, 150, 15);
                    } else {
                        data.put("table", "users");
                        data.put("this1", "UserID");
                        data.put("this2", userIDD);
                        data.put("what", "UID");
                        data.put("change", newUID);
        				JSONObject change_check = po.jsonpost("/change_user", data);
        				boolean success = change_check.getBoolean("success"); 
        				System.out.println("변경 성공 여부: " + success);
                    	dialogFrame.dispose();
                    	showSuccessDialog("학과 ");
                    }
                                        
                } catch (NumberFormatException s) {
                    System.out.println("입력한 내용은 문자열입니다.");
                    data.put("table", "university");
    		        data.put("want", "UID");
    		        data.put("where1", "UID");
    		        data.put("what1", cutuniversity);
    		        data.put("where2", "department");
    		        data.put("what2", Departmentsave);
    		    	JSONObject SearchUID1 = po.jsonpost("/find_like_wnat", data);
    		    	String searchUID = SearchUID1.optString("UID", null);
    		    	boolean DepartDuplicate = SearchUID1.getBoolean("check");

            		if (DepartDuplicate) {
                        data.put("table", "users");
                        data.put("this1", "UserID");
                        data.put("this2", userIDD);
                        data.put("what", "UID");
                        data.put("change", searchUID);
        				JSONObject change_check = po.jsonpost("/change_user", data);
        				boolean success = change_check.getBoolean("success"); 
        				System.out.println("변경 성공 여부: " + success);
                    	dialogFrame.dispose();
                    	showSuccessDialog("학과 ");
            			
                    } else {
                    	NickduplicationLabel.setText("학과 정보를 정확히 입력해 주세요.");
            			NickduplicationLabel.setForeground(new Color(150, 100, 100));
            			NickduplicationLabel.setBounds(92, 105, 150, 15);
                    }
                    
                }
            	
            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
    
    //닉네임 설정
	private void NicknamechangeDialog() {
    	JSONObject data = new JSONObject();
        collor colors = new collor(); 
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
            colors.ToggleBtn = new Color(70, 70, 70);
        }
    	Border borderBlack = BorderFactory.createLineBorder(new Color(0, 0, 0), 2);
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(250, 350, 350, 220);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 326, 178);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255), 1)); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel MyPostLabel = new JLabel("닉네임 설정");
        MyPostLabel.setBounds(112, 25, 200, 20);
        MyPostLabel.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
        Font MyPostFont = new Font(MyPostLabel.getFont().getName(), Font.BOLD, 18);
        MyPostLabel.setFont(MyPostFont);
        dialogPanel.add(MyPostLabel);
        
        // 중복 라벨
        JLabel NickduplicationLabel = new JLabel("");
        NickduplicationLabel.setBounds(103, 110, 150, 15); // Adjust the position and size as needed
        NickduplicationLabel.setForeground(new Color(0, 0, 255)); // Set label text color
        Font labelFont2 = new Font(NickduplicationLabel.getFont().getName(), Font.BOLD, 9);
        NickduplicationLabel.setFont(labelFont2);
        dialogPanel.add(NickduplicationLabel);
        
        // 별명입력 입력 필드
        RoundtextField NicknameField = new RoundtextField();
        NicknameField.setBounds(60, 70, 200, 20);
        NicknameField.setBackground(colors.BoardPanel);
        NicknameField.setForeground(new Color(255, 255, 255));
        dialogPanel.add(NicknameField);
        NicknameField.setColumns(10);
        NicknameField.setBorder(borderBlack);
        NicknameField.setDefaultText("  별명");

        // 별명중복 확인 버튼 (원래 중복 확인 기능은 여기에 넣어도 됨)
        RoundedButton NicknameDuplicationButton = new RoundedButton("중복 확인");
        NicknameDuplicationButton.setBounds(260, 71, 50, 20);
        Font checkFont1 = new Font(NicknameDuplicationButton.getFont().getName(), Font.PLAIN, 10);
        NicknameDuplicationButton.setFont(checkFont1);

        NicknameDuplicationButton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        NicknameDuplicationButton.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        dialogPanel.add(NicknameDuplicationButton); // 패널에 버튼 추가
        NicknameDuplicationButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent en) {
                String Nicknamesave = NicknameField.getText();
                // 여기서 데이터베이스 조회하여 중복 여부 확인
                data.put("where", "Nickname");
                data.put("what", Nicknamesave);
                Post po = new Post();
				JSONObject nickDuplicate = po.jsonpost("/check_id_exists", data);
				boolean nickDuplicate1;
				nickDuplicate1 = nickDuplicate.getBoolean("exists");
                if (nickDuplicate1) {
                    NickduplicationLabel.setText("이미 사용 중인 별명입니다.");
                    NickduplicationLabel.setForeground(new Color(255, 0, 0));
                } else {
                    NickduplicationLabel.setText("사용 가능한 별명입니다.");
                    NickduplicationLabel.setForeground(new Color(0, 0, 255));
                }
            }
        });
        
        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("변경");
        confirmButton.setBounds(128, 140, 65, 20);
        confirmButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	String Nicknamesave = NicknameField.getText();
                data.put("where", "Nickname");
                data.put("what", Nicknamesave);
                Post po = new Post();
				JSONObject nickDuplicate = po.jsonpost("/check_id_exists", data);
				boolean nickDuplicate1;
				nickDuplicate1 = nickDuplicate.getBoolean("exists");
                if (nickDuplicate1) {
                	NickduplicationLabel.setText("별명을 확인해 주세요.");
                	NickduplicationLabel.setForeground(new Color(255, 0, 0));
                    NickduplicationLabel.setBounds(115, 110, 150, 15);
                }else {                   
                    data.put("table", "users");
                    data.put("this1", "UserID");
                    data.put("this2", userIDD);
                    data.put("what", "Nickname");
                    data.put("change", Nicknamesave);
    				JSONObject change_check = po.jsonpost("/change_user", data);
    				boolean success = change_check.getBoolean("success"); 
    				System.out.println("변경 성공 여부: " + success);
                	dialogFrame.dispose();
                	showSuccessDialog("별명 ");
                }
            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
    
    // 이용제한 내역
    private void LimitDialog(String UserID) {
    	JSONObject data = new JSONObject();
        collor colors = new collor(); 
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
            colors.ToggleBtn = new Color(70, 70, 70);
        }
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(250, 320, 350, 220);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 326, 178);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255), 1)); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel MyPostLabel = new JLabel("※이용 제한 내역※");
        MyPostLabel.setBounds(82, 25, 200, 20);
        MyPostLabel.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
        Font MyPostFont = new Font(MyPostLabel.getFont().getName(), Font.BOLD, 18);
        MyPostLabel.setFont(MyPostFont);
        dialogPanel.add(MyPostLabel);
        
        data.put("table", "users");
        data.put("want", "LimitDate");
        data.put("what", "UserID");
        data.put("user_id", UserID);
        Post po = new Post();
    	JSONObject LimitDate1 = po.jsonpost("/find_user_information", data);
    	long LimitDate = LimitDate1.getLong("LimitDate");

        long day = (LimitDate % 1000000) /10000;

        long month = (LimitDate % 100000000) / 1000000;

        long year = LimitDate / 100000000;

        String dayLabel = year + "년 " + month + "월 " + day + "일 까지";

        if (LimitDate != 0) {
            JLabel LimitLabel = new JLabel(dayLabel);
            LimitLabel.setBounds(95, 70, 200, 20);
            LimitLabel.setForeground(new Color(150, 100, 100)); // 텍스트 색상(흰색)
            Font LimitFont = new Font(LimitLabel.getFont().getName(), Font.BOLD, 14);
            LimitLabel.setFont(LimitFont);
            dialogPanel.add(LimitLabel);
        } else {
            JLabel LimitLabel = new JLabel("이용 제한 내역 없음");
            LimitLabel.setBounds(100, 70, 200, 20);
            LimitLabel.setForeground(new Color(100, 100, 150)); // 텍스트 색상(흰색)
            Font LimitFont = new Font(LimitLabel.getFont().getName(), Font.BOLD, 14);
            LimitLabel.setFont(LimitFont);
            dialogPanel.add(LimitLabel);
        }

        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("확인");
        confirmButton.setBounds(128, 140, 65, 20);
        confirmButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                dialogFrame.dispose();
            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }

    private void showSuccessDialog(String str) {
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
            colors.ToggleBtn = new Color(70, 70, 70);
        }
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(275, 400, 300, 150);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null); 

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 276, 110);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255), 1)); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel dialogLabel = new JLabel(str + "변경 성공!");
        dialogLabel.setBounds(100, 30, 200, 35);
        dialogLabel.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        dialogPanel.add(dialogLabel);

        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("확인");
        confirmButton.setBounds(110, 80, 65, 20);
        confirmButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mypage my = new mypage(userIDD, Section, DarK);
                my.showFrame();
                frame.dispose();
                dialogFrame.dispose();
            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
    
 // 토글 버튼 생성 메서드
    private JToggleButton createToggleButton() {
        collor colors = new collor();

        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
            colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
            colors.ToggleBtn = new Color(0, 0, 0);
        }

        // JToggleButton 생성 및 설정
        JToggleButton toggleButton = new JToggleButton() {
            @Override
            protected void paintComponent(Graphics g) {
                int width = getWidth();
                int height = getHeight();
                Graphics2D graphics = (Graphics2D) g;
                graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // 버튼의 상태에 따라 색상 설정
                if (getModel().isArmed()) {
                    graphics.setColor(getBackground().darker());
                } else if (getModel().isRollover()) {
                    graphics.setColor(getBackground().brighter());
                } else {
                    graphics.setColor(getBackground());
                }

                // 둥근 테두리 그리기
                graphics.fillRoundRect(0, 0, width, height, 20, 20);

                // 텍스트 가운데 정렬
                FontMetrics fontMetrics = graphics.getFontMetrics();
                Rectangle stringBounds = fontMetrics.getStringBounds(this.getText(), graphics).getBounds();
                int textX = (width - stringBounds.width) / 2;
                int textY = (height - stringBounds.height) / 2 + fontMetrics.getAscent();

                graphics.setColor(getForeground());
                graphics.setFont(getFont());
                graphics.drawString(getText(), textX, textY);

                super.paintComponent(g);
            }
        };

        toggleButton.setPreferredSize(new Dimension(60, 24));
        toggleButton.setFocusPainted(false);
        toggleButton.setBackground(colors.ToggleBtn);
        toggleButton.setBorder(BorderFactory.createEmptyBorder());
        toggleButton.setLayout(null);
        toggleButton.setOpaque(false); // 둥근 모양을 표현하기 위해 false 설정
        toggleButton.setContentAreaFilled(false);
        toggleButton.setFocusPainted(false);

        // 'ON' 표시 라벨
        JLabel onLabel = new JLabel("DARK", SwingConstants.CENTER);
        onLabel.setFont(new Font("Arial", Font.BOLD, 9));
        onLabel.setForeground(new Color(120, 120, 120));
        onLabel.setBounds(5, 2, 30, 20); // ON 텍스트를 왼쪽에 표시
        onLabel.setVisible(false); // 처음엔 보이지 않도록 설정
        toggleButton.add(onLabel);

        // 'OFF' 표시 라벨
        JLabel offLabel = new JLabel("LIGHT", SwingConstants.CENTER);
        offLabel.setFont(new Font("Arial", Font.BOLD, 9));
        offLabel.setForeground(Color.WHITE);
        offLabel.setBounds(22, 2, 30, 20); // OFF 텍스트를 오른쪽에 표시
        toggleButton.add(offLabel);

     // 내부 원 모양 버튼 생성 및 설정
        JPanel circlePanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(getBackground());
                g2d.fillOval(0, 0, getWidth(), getHeight()); // 원 모양 그리기
            }
        };

        // 원 모양 설정
        circlePanel.setOpaque(false);
        circlePanel.setBackground(colors.Ground);
        circlePanel.setBounds(3, 2, 20, 20);
        circlePanel.setBorder(null);  // 테두리 제거

        toggleButton.add(circlePanel);

        // 버튼 클릭 이벤트
        toggleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // DarK 값 변경
                DarK = (DarK == 0) ? 1 : 0;

                // 새로운 화면을 열기 전에 버튼의 모양을 설정
                if (DarK == 1) { // 다크 모드로 전환
                    toggleButton.setBackground(colors.ToggleBtn); // Dark Mode 색상
                    circlePanel.setBounds(38, 2, 20, 20); // 동그라미 오른쪽으로 이동
                    onLabel.setVisible(true);
                    offLabel.setVisible(false);;
                } else { // 라이트 모드로 전환
                    toggleButton.setBackground(colors.ToggleBtn); // Light Mode 색상
                    circlePanel.setBounds(3, 2, 20, 20); // 동그라미 왼쪽으로 이동
                    onLabel.setVisible(false);
                    offLabel.setVisible(true);
                }

                // mypage 객체 생성 및 프레임 열기
                mypage mypage = new mypage(userIDD, Section, DarK);
                mypage.showFrame(); // 프레임 열기

                // 기존 프레임 닫기
                frame.dispose();
            }
        });

        // 초기 상태 설정
        setButtonState(toggleButton, circlePanel, onLabel, offLabel);

        return toggleButton;
    }

    // 버튼 상태 설정 메서드
    private void setButtonState(JToggleButton toggleButton, JPanel circlePanel, JLabel onLabel, JLabel offLabel) {
        collor colors = new collor();

        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
            colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
            colors.ToggleBtn = new Color(0, 0, 0);
        }
        if (DarK == 1) { // 다크 모드 설정
            toggleButton.setBackground(colors.ToggleBtn); // Dark Mode 색상
            circlePanel.setBounds(38, 2, 20, 20); // 동그라미 오른쪽으로 이동
            onLabel.setVisible(true);
            offLabel.setVisible(false);
        } else { // 라이트 모드 설정
            toggleButton.setBackground(colors.ToggleBtn); // Light Mode 색상
            circlePanel.setBounds(2, 2, 20, 20); // 동그라미 왼쪽으로 이동
            onLabel.setVisible(false);
            offLabel.setVisible(true);
        }
    }

    
    
	public void showFrame() {
        frame.setVisible(true);
    }

}