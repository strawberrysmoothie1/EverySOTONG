package main.java.com.pws.dialog;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicScrollBarUI;

import org.json.JSONObject;

import main.java.com.pws.Thing.FrameManager;
import main.java.com.pws.Thing.GetInstructors;
import main.java.com.pws.Thing.GetSearch_Instructor;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundedBorder;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.RoundtextField;
import main.java.com.pws.Thing.collor;

public class InstructorList{
	private String userIDD;
    private String Section;
    private int DarK;

    public InstructorList(String userIDD, String Section, int DarK) {
        this.userIDD = userIDD;
        this.Section = Section;
        this.DarK = DarK;

        initialize();
    }

    private void initialize() {
	    JSONObject data = new JSONObject();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }

	
        Border borderBlue = BorderFactory.createLineBorder(new Color(155, 155, 155), 2);
        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        Border borderBlack = BorderFactory.createLineBorder(colors.BoardPanel, 1);
	
	    // 다이얼로그 프레임 생성
	    JFrame dialogFrame = new JFrame();
	    dialogFrame.setBounds(150, 240, 550, 570);
	    dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	    dialogFrame.getContentPane().setLayout(null);
	
    	FrameManager.addFrame(dialogFrame);

	    // 다이얼로그 패널 생성
	    JPanel dialogPanel = new JPanel();
	    dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
	    dialogPanel.setBounds(5, 0, 526, 528);
	    dialogPanel.setLayout(null);
	    dialogPanel.setBackground(colors.Ground); // 배경색 설정
	    dialogPanel.setBorder(borderWhite); // 테두리 설정
	    dialogFrame.getContentPane().add(dialogPanel);
	
	    // 다이얼로그 라벨 생성
	    JLabel MyPostLabel = new JLabel("교수 목록");
	    MyPostLabel.setBounds(220, 25, 200, 20);
	    MyPostLabel.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
	    Font MyPostFont = new Font(MyPostLabel.getFont().getName(), Font.BOLD, 20);
	    MyPostLabel.setFont(MyPostFont);
	    dialogPanel.add(MyPostLabel);
	    
	    
	    JLabel ShowIDLabel = new JLabel("아이디");
	    ShowIDLabel.setBounds(85, 110, 100, 20);
	    ShowIDLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
	    Font ShowInfoFont = new Font(ShowIDLabel.getFont().getName(), Font.BOLD, 15);
	    ShowIDLabel.setFont(ShowInfoFont);
	    dialogPanel.add(ShowIDLabel);
	    
	    JLabel ShowNameLabel = new JLabel("이름");
	    ShowNameLabel.setBounds(246, 110, 100, 20);
	    ShowNameLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
	    ShowNameLabel.setFont(ShowInfoFont);
	    dialogPanel.add(ShowNameLabel);
	    
	    JLabel ShowDeptLabel = new JLabel("학과");
	    ShowDeptLabel.setBounds(405, 110, 100, 20);
	    ShowDeptLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
	    ShowDeptLabel.setFont(ShowInfoFont);
	    dialogPanel.add(ShowDeptLabel);
	    
        RoundedButton AddInstructorbutton = new RoundedButton("교수 추가");
        AddInstructorbutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	AddInstructor ShowAddInstructor = new AddInstructor(userIDD, DarK);
            }
        });
        AddInstructorbutton.setBackground(new Color(200, 100, 150));// 배경색 설정 (빨간색)
        AddInstructorbutton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        AddInstructorbutton.setBounds(440, 15, 70, 20);
        dialogPanel.add(AddInstructorbutton);
        	
	    
	    
        // 검색창 박스
        RoundtextField textField = new RoundtextField(); // 텍스트 필드 생성
        textField.setBounds(83, 50, 360, 43); // 텍스트 필드 위치 및 크기 설정
        textField.setBackground(colors.BoardPanel); // 배경색 설정
        textField.setForeground(colors.Text); // 텍스트 색상(흰색)
        dialogPanel.add(textField); // 패널에 텍스트 필드 추가
        textField.setColumns(10); // 텍스트 필드 컬럼 수 설정
        textField.setBorder(borderBlue); // 테두리 설정
        textField.setDefaultText("  검색"); // 기본 텍스트 설정
	    
        
        // 검색 버튼
        JButton lblId = new JButton("검색"); // 레이블 생성 및 텍스트 설정
        lblId.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                String SearInstructor = textField.getText();

                data.put("keyword", SearInstructor);
                GetSearch_Instructor  getSearch_Instructor  = new GetSearch_Instructor ();
                List<String> Searchuser = getSearch_Instructor.searchInstructor(data);
                
                if (Searchuser.isEmpty()) {
                    System.out.println("검색 결과가 없습니다.");
                } else {
        	        String instructor_ID = Searchuser.get(0);
                	
                	InstructorInfo instructorInfo = new InstructorInfo(userIDD, instructor_ID, Section, DarK);
                }
            }
        });
        lblId.setBounds(450, 52, 30, 43); // 레이블 위치 및 크기 설정
        lblId.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        lblId.setForeground(new Color(155, 155, 155)); // 텍스트 색상(흰색)
        lblId.setBorder(borderWhite); // 테두리 설정
        lblId.setContentAreaFilled(false);
        lblId.setFocusPainted(false);
        lblId.setOpaque(true);
        dialogPanel.add(lblId); // 패널에 텍스트 필드 추가

        GetInstructors  getInstructors  = new GetInstructors ();
        List<List<String>> Instructors = getInstructors.GetInstructors();

	    // 패널 생성
	    JPanel panel_1 = new JPanel();
	    panel_1.setBackground(colors.Ground);
	    int hight = 408;
	    if (Instructors.size() > 9) {
	        hight = 20 + 42 * Instructors.size();
	    }
	    panel_1.setBounds(24, 140, 480, hight);
	    dialogPanel.add(panel_1);
	    panel_1.setLayout(null);
	    panel_1.setBorder(borderWhite); // 테두리 설정
	    RoundedBorder roundedBorder = new RoundedBorder(20);
	    panel_1.setPreferredSize(new Dimension(480, hight));
	    
	    
	    data.put("table", "users");
	    data.put("want", "UID");
	    data.put("what", "UserID");
	    data.put("user_id", userIDD);
	    Post po = new Post();
		JSONObject SearchNickname1 = po.jsonpost("/find_user_information", data);
		String AdminUID = SearchNickname1.getString("UID");
        String SchoolID = AdminUID.substring(0, AdminUID.length() - 2);

		
	    int COUNT = 0;
	    int aa = Instructors.size() -1 ;
	    for (int a = 1; a <= Instructors.size(); a++) {
	    	List<String> user = Instructors.get(aa);
	
	        String instructor_id = user.get(0);
	        String name = user.get(1);
	        String GetUID = user.get(2);

	
	        String UserSchoolID = GetUID.substring(0, GetUID.length() - 2);
	        aa--;

        if (UserSchoolID.equals(SchoolID)) {
        	
        	// 학교 이름 가져오기
            data.put("table", "university");
            data.put("want", "UName");
            data.put("what", "UID");
            data.put("user_id", GetUID);
            data.put("want", "department");
            JSONObject Searchdepartment1 = po.jsonpost("/find_user_information", data);
            String Searchdepartment = Searchdepartment1.getString("department");
            
            // 게시물 페널
            JPanel Postpanel = new JPanel();
            Postpanel.setBackground(colors.Ground);
            Postpanel.setBounds(25, 5 + (42 * COUNT), 474, 40);
            panel_1.add(Postpanel);
            Postpanel.setLayout(null);
            Postpanel.setBorder(borderBlack); // 테두리 설정
            Postpanel.setBorder(roundedBorder);


            // 유저 아이디 버튼
            JButton instructorIDbutton = new JButton(instructor_id);
            instructorIDbutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	InstructorInfo instructorInfo = new InstructorInfo(userIDD, instructor_id, Section, DarK);
                    dialogFrame.dispose();
                }
            });
            instructorIDbutton.setBorder(borderWhite);
            instructorIDbutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
            instructorIDbutton.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
            instructorIDbutton.setBounds(5, 5, 155, 30);
            Font contentFont = new Font(instructorIDbutton.getFont().getName(), Font.BOLD, 14);
            instructorIDbutton.setFont(contentFont);
            instructorIDbutton.setContentAreaFilled(false);
            instructorIDbutton.setFocusPainted(false);
            instructorIDbutton.setOpaque(true);
            Postpanel.add(instructorIDbutton);
            
            // 아이디 버튼
            JButton instructorNamebutton = new JButton(name);
            instructorNamebutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	InstructorInfo instructorInfo = new InstructorInfo(userIDD, instructor_id, Section, DarK);
                    dialogFrame.dispose();
                }
            });
            instructorNamebutton.setBorder(borderWhite);
            instructorNamebutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
            instructorNamebutton.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
            instructorNamebutton.setBounds(160, 5, 155, 30);
            instructorNamebutton.setFont(contentFont);
            instructorNamebutton.setContentAreaFilled(false);
            instructorNamebutton.setFocusPainted(false);
            instructorNamebutton.setOpaque(true);
            Postpanel.add(instructorNamebutton);

            // 닉네임 버튼
            JButton Nicknamebutton = new JButton(Searchdepartment);
            Nicknamebutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	InstructorInfo instructorInfo = new InstructorInfo(userIDD, instructor_id, Section, DarK);
                    dialogFrame.dispose();
                }
            });
            Nicknamebutton.setBorder(borderWhite);
            Nicknamebutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
            Nicknamebutton.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
            Nicknamebutton.setBounds(315, 5, 155, 30);
            Nicknamebutton.setFont(contentFont);
            Nicknamebutton.setContentAreaFilled(false);
            Nicknamebutton.setFocusPainted(false);
            Nicknamebutton.setOpaque(true);
            Postpanel.add(Nicknamebutton);


            
            COUNT++;
            }
    	}
        // 스크롤바 추가
        JScrollPane scrollPane = new JScrollPane(panel_1);
        scrollPane.setBounds(0, 140, 625, 408); // JScrollPane의 위치 및 크기 설정
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        // 가로 스크롤바를 비활성화합니다.
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        // 세로 스크롤바의 UI 변경
        scrollPane.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = new Color(100, 100, 100); // 스크롤바 색상 설정
            }

            @Override
            protected JButton createDecreaseButton(int orientation) {
                return new JButton() {
                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension(0, 0); // 위 버튼 크기 0으로 설정하여 숨김
                    }
                };
            }

            @Override
            protected JButton createIncreaseButton(int orientation) {
                return new JButton() {
                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension(0, 0); // 아래 버튼 크기 0으로 설정하여 숨김
                    }
                };
            }

            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // 둥근 모양의 스크롤바
                g2.setColor(Color.LIGHT_GRAY); // 색상 변경
                g2.fillRoundRect(thumbBounds.x, thumbBounds.y, thumbBounds.width, thumbBounds.height, 10, 10);

                g2.dispose();
            }
        });
        scrollPane.setVisible(true);

        dialogPanel.add(scrollPane);
        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
	
}
