package main.java.com.pws.Board;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicScrollBarUI;

import org.json.JSONObject;

import main.java.com.pws.Board.showPost;
import main.java.com.pws.Schedule.schedule;
import main.java.com.pws.Thing.FrameManager;
import main.java.com.pws.Thing.GetComments;
import main.java.com.pws.Thing.GetComplaint;
import main.java.com.pws.Thing.GetMyFriends;
import main.java.com.pws.Thing.GetUsers;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundedBorder;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.TodayDate;
import main.java.com.pws.Thing.collor;
import main.java.com.pws.dialog.DeleteComment;

public class AdminComplaint2 {
	private String UserID;
	private String Section;
	private int DarK;

	public AdminComplaint2(String UserID, String Section, int DarK) {		
        this.UserID = UserID;
        this.Section = Section;
        this.DarK = DarK;

		 initialize();
	}
	
	
    private void initialize() {
        JSONObject data = new JSONObject();
        TodayDate todayDate = new TodayDate();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }


        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        Border borderBlack = BorderFactory.createLineBorder(new Color(0, 0, 0), 1);

        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(150, 240, 550, 570);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 526, 528);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255), 1)); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 게시판 버튼
        JButton btnClickMe = new JButton("안읽음");
        btnClickMe.addActionListener(new ActionListener() {	
            public void actionPerformed(ActionEvent e) {
            	AdminComplaint adminComplaint = new AdminComplaint(UserID, Section, DarK);
                dialogFrame.dispose();
            }
        });
        btnClickMe.setBounds(160, 53, 70, 20);
        btnClickMe.setBackground(colors.Ground);
        btnClickMe.setForeground(colors.Text);
        btnClickMe.setFont(new Font(btnClickMe.getFont().getName(), Font.PLAIN, 15));
        btnClickMe.setBorder(borderWhite);
        btnClickMe.setContentAreaFilled(false);
        btnClickMe.setFocusPainted(false);
        btnClickMe.setOpaque(true);
        dialogFrame.add(btnClickMe);
        
     // 시간표 버튼 생성 및 설정
        JButton scheduleButton = new JButton("읽음");
        scheduleButton.addActionListener(e -> {
        	AdminComplaint2 adminComplaint2 = new AdminComplaint2(UserID, Section, DarK);
            dialogFrame.dispose();
        });
        scheduleButton.setBounds(300, 53, 70, 20);
        scheduleButton.setBackground(colors.Ground);
        scheduleButton.setForeground(colors.Text);
        scheduleButton.setFont(new Font(scheduleButton.getFont().getName(), Font.BOLD, 15));
        scheduleButton.setBorder(borderWhite);
        scheduleButton.setContentAreaFilled(false);
        scheduleButton.setFocusPainted(false);
        scheduleButton.setOpaque(true);
        dialogFrame.add(scheduleButton);
        
        
        
        // 다이얼로그 라벨 생성
        JLabel MyPostLabel = new JLabel("신고함");
        MyPostLabel.setBounds(230, 17, 200, 20);
        MyPostLabel.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
        Font MyPostFont = new Font(MyPostLabel.getFont().getName(), Font.BOLD, 20);
        MyPostLabel.setFont(MyPostFont);
        dialogPanel.add(MyPostLabel);
        
        data.put("checking", "1");

        // 해당 유저의 친구 목록을 조회
        GetComplaint getComplaint = new GetComplaint();
        List<List<String>> Complaints = getComplaint.getComplaint(data); // 친구 목록 조회

        
        // 유저 목록과 친구 목록을 조회하여 매핑하는 부분
        GetUsers getUsers = new GetUsers();
        List<List<String>> users = getUsers.getAllUsers(); // 유저 목록 조회

        Map<String, String> userMap = new HashMap<>();
        for (List<String> user : users) {
            String userID = user.get(0);  // 유저 ID
            String nickname = user.get(3); // 유저 닉네임 (인덱스 3에 닉네임이 있다고 가정)
            userMap.put(userID, nickname); // 유저ID와 닉네임을 맵에 저장
        }

        System.out.println("신고함 크기: "+Complaints.size());
        
        // 패널 생성
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(colors.Ground);
        int hight = 468;
        if (Complaints.size() > 5) {
            hight = 5 + 79 * Complaints.size();
        }
        panel_1.setBounds(23, 80, 480, hight);
        dialogPanel.add(panel_1);
        panel_1.setLayout(null);
        panel_1.setBorder(borderWhite); // 테두리 설정
        RoundedBorder roundedBorder = new RoundedBorder(20);
        panel_1.setPreferredSize(new Dimension(480, hight));
        
        
        
        int COUNT = 0;
        int aa = Complaints.size() -1 ;
        for (int a = 1; a <= Complaints.size(); a++) {
        	List<String> Complaint = Complaints.get(aa);
            String CUserID = Complaint.get(0);
            String CBulletinID = Complaint.get(1);
            String type = Complaint.get(2);
            String problemID = Complaint.get(3);
            String Ccontent = Complaint.get(4);
         // 시간 및 날짜 계산
            long ComplaintDate = Long.parseLong(Complaint.get(6));

            String Nickname = userMap.get(CUserID);

            long NewCDateTime = todayDate.TodayDate();
            long newCMinte = NewCDateTime % 100;
            long searchCMinte = ComplaintDate % 100;
            long Cminute = newCMinte - searchCMinte;

            long newCHour = (NewCDateTime % 10000) / 100;
            long searchCHour = (ComplaintDate % 10000) / 100;
            long Chour = newCHour - searchCHour;
            
            // 분 차이 계산 (음수일 경우 60을 더하고 시간에서 1을 빼줌)
            if (Cminute < 0) {
                Cminute += 60;
                Chour -= 1; // 분에서 빼준 만큼 시간을 조정
            }
            long newCDay = (NewCDateTime % 1000000) / 10000;
            long searchCDay = (ComplaintDate % 1000000) / 10000;
            long Cday = newCDay - searchCDay;            
            // 시간 차이 계산 (음수일 경우 24 더하고, 날짜에서 1을 빼줌)
            if (Chour < 0) {
                Chour += 24;
                Cday -= 1; // 시간에서 빼준 만큼 날짜를 조정
            }
            long newCmonth = (NewCDateTime % 100000000) / 1000000;
            long searchCmonth = (ComplaintDate % 100000000) / 1000000;
            long Cmonth = newCmonth - searchCmonth;           
            // 날짜 차이 계산 (음수일 경우 30일을 더하고, 월에서 1을 빼줌)
            if (Cday < 0) {
                Cday += 30;  // 필요 시 해당 달의 일수로 조정해야 할 수도 있음
                Cmonth -= 1;
            }
            long newCyear = NewCDateTime / 100000000;
            long searchCyear = ComplaintDate / 100000000;
            long Cyear = newCyear - searchCyear;            
            // 월 차이 (음수일 경우 12를 더하고, 연도에서 1을 빼줌)
            if (Cmonth < 0) {
                Cmonth += 12;
                Cyear -= 1;
            }
            // 시간 차이 라벨을 만드는 로직
            String CdayLabel = null;
            if (Cyear > 0) {
                CdayLabel = searchCyear + "년 " + searchCmonth + "/" + searchCDay + " " + searchCHour + ":" + searchCMinte;
            } else if (Cmonth > 0) {
                CdayLabel = searchCmonth + "/" + searchCDay + " " + searchCHour + ":" + searchCMinte;
            } else if (Cday > 0) {
                CdayLabel = searchCmonth + "/" + searchCDay + " " + searchCHour + ":" + searchCMinte;
            } else if (Chour > 0) {
                CdayLabel = Chour + "시간 " + Cminute + "분 전";
            } else {
                CdayLabel = Cminute + "분 전";
            }
      
                // 게시물 페널
                JPanel Postpanel = new JPanel();
                Postpanel.setBackground(colors.Ground);
                Postpanel.setBounds(23, 5 + (47 * COUNT), 474, 45);
                panel_1.add(Postpanel);
                Postpanel.setLayout(null);
                Postpanel.setBorder(borderBlack); // 테두리 설정
                Postpanel.setBorder(roundedBorder);

                // 제목 버튼
                JButton postbutton = new JButton(Nickname+": "+Ccontent);
                postbutton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        FrameManager.closeAllFrames(); // 모든 프레임 닫기
                        boardclass b = new boardclass(UserID, Section, DarK);
                        b.showFrame();

                        dialogFrame.dispose();
                    }
                });
                postbutton.setHorizontalAlignment(SwingConstants.LEFT);
                postbutton.setBorder(borderWhite);
                postbutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
                postbutton.setForeground(colors.Text); // 텍스트 색상(흰색)
                postbutton.setBounds(6, 2, 410, 28);
                Font memberbuttonFont = new Font(postbutton.getFont().getName(), Font.BOLD, 12);
                postbutton.setFont(memberbuttonFont);
                postbutton.setContentAreaFilled(false);
                postbutton.setFocusPainted(false);
                postbutton.setOpaque(true);
                Postpanel.add(postbutton);

    	        String NoreadIMG = "src/img/Noread.png";
                ImageIcon NoreadImageIcon = new ImageIcon(NoreadIMG);
                Image NoreadImage = NoreadImageIcon.getImage();
                Image Noread1Image = NoreadImage.getScaledInstance(45, 20, Image.SCALE_SMOOTH);
                ImageIcon Noread1ImageIcon = new ImageIcon(Noread1Image);           
                JButton NoReedenbutton = new JButton(Noread1ImageIcon);
                NoReedenbutton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                    	
                    	data.put("table", "Complaint");
                        data.put("this1", "UserID");
                        data.put("this11", CUserID);
                        data.put("this2", "type");
                        data.put("this22", type);
                        data.put("this3", "problemID");
                        data.put("this33", problemID);
                    	data.put("what", "checking");
                        data.put("change", "0");     
                        Post po = new Post();
            			JSONObject change_check2 = po.jsonpost("/change_Information3", data);
            			boolean success2 = change_check2.getBoolean("success"); 
            			System.out.println("변경 여부: " + success2);
                        FrameManager.closeAllFrames(); // 모든 프레임 닫기
                        boardclass b = new boardclass(UserID, Section, DarK);
                        b.showFrame();
            			
                    	AdminComplaint2 adminComplaint2 = new AdminComplaint2(UserID, Section, DarK);
                        dialogFrame.dispose();

                    }
                });
                NoReedenbutton.setHorizontalAlignment(SwingConstants.LEFT);
                NoReedenbutton.setBorder(borderWhite);
                NoReedenbutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
                NoReedenbutton.setForeground(colors.Text); // 텍스트 색상(흰색)
                NoReedenbutton.setBounds(418, 11, 45, 20);
                Font NoReedenFont = new Font(NoReedenbutton.getFont().getName(), Font.BOLD, 8);
                NoReedenbutton.setFont(NoReedenFont);
                NoReedenbutton.setContentAreaFilled(false);
                NoReedenbutton.setFocusPainted(false);
                NoReedenbutton.setOpaque(true);
                Postpanel.add(NoReedenbutton);

                // 시간 라벨
                JLabel TimeCLabel = new JLabel(CdayLabel);
                TimeCLabel.setBounds(12, 28, 60, 15); // Adjust the position and size as needed
                TimeCLabel.setForeground(new Color(100, 100, 100)); // Set label text color
                Font TimeFont = new Font(TimeCLabel.getFont().getName(), Font.BOLD, 8);
                TimeCLabel.setFont(TimeFont);
                Postpanel.add(TimeCLabel);
            aa--;
            COUNT++;

        }
        JScrollPane scrollPane = new JScrollPane(panel_1);
        scrollPane.setBounds(0, 80, 526, 468); // JScrollPane의 위치 및 크기 설정
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        // 가로 스크롤바를 비활성화합니다.
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        // 세로 스크롤바의 UI 변경
        scrollPane.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = new Color(100, 100, 100); // 스크롤바 색상 설정
            }

            @Override
            protected JButton createDecreaseButton(int orientation) {
                return new JButton() {
                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension(0, 0); // 위 버튼 크기 0으로 설정하여 숨김
                    }
                };
            }

            @Override
            protected JButton createIncreaseButton(int orientation) {
                return new JButton() {
                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension(0, 0); // 아래 버튼 크기 0으로 설정하여 숨김
                    }
                };
            }

            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // 둥근 모양의 스크롤바
                g2.setColor(Color.LIGHT_GRAY); // 색상 변경
                g2.fillRoundRect(thumbBounds.x, thumbBounds.y, thumbBounds.width, thumbBounds.height, 10, 10);

                g2.dispose();
            }
        });
        scrollPane.setVisible(true);

        dialogPanel.add(scrollPane);
        // 다이얼로그 프레임에 패널 추가
        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }

}

