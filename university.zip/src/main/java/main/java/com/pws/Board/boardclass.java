package main.java.com.pws.Board;

import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import javax.swing.*;
import org.json.JSONObject;
import main.java.com.pws.Login.login;
import main.java.com.pws.Schedule.schedule;
import main.java.com.pws.Thing.FrameManager;
import main.java.com.pws.Thing.GetBulletins;
import main.java.com.pws.Thing.GetMyFriends;
import main.java.com.pws.Thing.GetSection;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.User.mypage;
import main.java.com.pws.dialog.MycommentsDialog;
import main.java.com.pws.dialog.Schoolchange;
import main.java.com.pws.dialog.UserList;
import main.java.com.pws.Thing.RoundtextField;
import main.java.com.pws.Thing.TodayDate;
import main.java.com.pws.Thing.collor;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.border.Border;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.List;

public class boardclass {
    private String userIDD;
    private String Section;
    private int DarK;

    


    JFrame frame;

    /**
     * 어플리케이션 실행 메소드
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    login window = new login();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }); 
    }

    public boardclass(String userIDD, String Section, int DarK) {
        this.userIDD = userIDD;
        this.Section = Section;
        this.DarK = DarK;

        initialize();
    }

    private void initialize() {
        JSONObject data = new JSONObject();
        TodayDate todayDate = new TodayDate();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }

        frame = new JFrame();
        frame.setBounds(100, 100, 650, 800); // 프레임 위치 및 크기 설정
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // 닫기 버튼 동작 설정
        frame.getContentPane().setLayout(null);

        FrameManager.addFrame(frame);

        // 테두리 스타일 설정
        Border borderBlue = BorderFactory.createLineBorder(colors.Ground, 2);
        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        Border borderBlack = BorderFactory.createLineBorder(new Color(0, 0, 0), 1);

        JPanel panel = new JPanel();
        panel.setBounds(5, 0, 625, 755);
        frame.getContentPane().add(panel);
        panel.setLayout(null);
        panel.setBackground(colors.Ground); // 패널 배경색 설정

        long NewCDateTime = todayDate.TodayDate() / 10000;

        GetSection getSection = new GetSection();
        List<List<String>> Sections = getSection.GetSection();

        for (int a = 0; a < Sections.size(); a++) {
            long startSection = Long.parseLong(Sections.get(a).get(1).replace("-", ""));
            long endSection = Long.parseLong(Sections.get(a).get(2).replace("-", ""));

            if (NewCDateTime >= startSection && NewCDateTime <= endSection) {
                Section = Sections.get(a).get(0);
                break;
            }
        }
        System.out.println("현재 학기: " + Section);

        // 에브리소통 그림
        String everyTimeIMG = "src/img/everygood.png";
        if(DarK == 1) {
        	everyTimeIMG = "src/img/everygoodDark.png";
        }
        ImageIcon everyImageIcon = new ImageIcon(everyTimeIMG);
        Image everyImage = everyImageIcon.getImage();
        Image every1Image = everyImage.getScaledInstance(120, 30, Image.SCALE_SMOOTH);
        ImageIcon every1ImageIcon = new ImageIcon(every1Image);
        JButton image1Button = new JButton(every1ImageIcon);
        image1Button.setBackground(colors.Ground);
        image1Button.setBounds(30, 40, 120, 30);
        image1Button.setBorder(borderWhite);
        image1Button.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                boardclass b = new boardclass(userIDD, Section, DarK);
                b.showFrame();
                frame.dispose();
            }
        });
        panel.add(image1Button);

        // 학교 이름 라벨
        data.put("table", "users");
        data.put("want", "UID");
        data.put("what", "UserID");
        data.put("user_id", userIDD);
        Post po = new Post();
        JSONObject UserUID1 = po.jsonpost("/find_user_information", data);
        String UserUID = UserUID1.getString("UID");

        data.put("table", "university");
        data.put("want", "UName");
        data.put("what", "UID");
        data.put("user_id", UserUID);
        JSONObject University1 = po.jsonpost("/find_user_information", data);
        String University = University1.getString("UName");

        JLabel UnameLabel = new JLabel(University);
        UnameLabel.setBounds(260, 40, 170, 25);
        UnameLabel.setForeground(new Color(150, 150, 150));
        Font UniversityFont = new Font(UnameLabel.getFont().getName(), Font.TRUETYPE_FONT, 24);
        UnameLabel.setFont(UniversityFont);
        panel.add(UnameLabel);

        // 게시판 버튼
        JButton btnClickMe = new JButton("게시판");
        btnClickMe.addActionListener(new ActionListener() {	
            public void actionPerformed(ActionEvent e) {
                boardclass b = new boardclass(userIDD, Section, DarK);
                b.showFrame();
                frame.dispose();
            }
        });
        btnClickMe.setBounds(210, 70, 100, 45);
        btnClickMe.setBackground(colors.Ground);
        btnClickMe.setForeground(colors.Text);
        btnClickMe.setFont(new Font(btnClickMe.getFont().getName(), Font.BOLD, 18));
        btnClickMe.setBorder(borderWhite);
        btnClickMe.setContentAreaFilled(false);
        btnClickMe.setFocusPainted(false);
        btnClickMe.setOpaque(true);
        panel.add(btnClickMe);
        
     // 시간표 버튼 생성 및 설정
        JButton scheduleButton = new JButton("시간표");
        scheduleButton.addActionListener(e -> {
            schedule schedule = new schedule(userIDD, Section, DarK);
            schedule.showFrame();
            frame.dispose();
        });
        scheduleButton.setBounds(320, 70, 100, 45);
        scheduleButton.setBackground(colors.Ground);
        scheduleButton.setForeground(colors.Text);
        scheduleButton.setFont(new Font(scheduleButton.getFont().getName(), Font.PLAIN, 18));
        scheduleButton.setBorder(borderWhite);
        scheduleButton.setContentAreaFilled(false);
        scheduleButton.setFocusPainted(false);
        scheduleButton.setOpaque(true);
        panel.add(scheduleButton);

     // 내 정보 버튼 생성 및 설정
        JButton memberButton = new JButton("설정");
        memberButton.addActionListener(e -> {
            mypage mypage = new mypage(userIDD, Section, DarK);
            mypage.showFrame();
            frame.dispose();
        });
        memberButton.setBounds(530, 30, 70, 30);
        memberButton.setBackground(colors.Ground);
        memberButton.setForeground(colors.Text);
        Font memberbuttonFont = new Font(memberButton.getFont().getName(), Font.BOLD, 12);
        memberButton.setBorder(borderWhite);
        memberButton.setContentAreaFilled(false);
        memberButton.setFocusPainted(false);
        memberButton.setOpaque(true);
        panel.add(memberButton);


     // 관리자 전용 버튼들 (학교 변경, 유저 관리)
        if (userIDD.equals("admin")) {
            // 학교 변경 버튼 생성 및 설정
            RoundedButton changeSchoolButton = new RoundedButton("학교 변경");
            changeSchoolButton.addActionListener(e -> {
                Schoolchange schoolChange = new Schoolchange(userIDD, frame, Section, DarK);
            });
            changeSchoolButton.setBounds(530, 70, 70, 20);
            changeSchoolButton.setBackground(new Color(200, 100, 100));
            changeSchoolButton.setForeground(colors.Ground);
            panel.add(changeSchoolButton);

            // 유저 관리 버튼 생성 및 설정
            RoundedButton manageUserButton = new RoundedButton("유저 관리");
            manageUserButton.addActionListener(e -> {
                UserList userList = new UserList(userIDD, Section, DarK);
            });
            manageUserButton.setBounds(530, 95, 70, 20);
            manageUserButton.setBackground(new Color(200, 100, 150));
            manageUserButton.setForeground(colors.Ground);
            panel.add(manageUserButton);
            
            data.put("table", "Complaint");
            data.put("where", "checking");
            data.put("what", "0");
			JSONObject isDuplicate = po.jsonpost("/check_exists", data);
			boolean isDuplicate1 = isDuplicate.getBoolean("exists");
			
			
	        String messageIMG = "src/img/messageNo.png";
            if (!isDuplicate1) { //안읽은거 있을 때
            	messageIMG = "src/img/message.png";
            }
            if (isDuplicate1 && DarK == 1) { //안읽은거 있을 때
            	messageIMG = "src/img/WmessageNo.png";
            }
            if (!isDuplicate1 && DarK == 1) { //안읽은거 있을 때
            	messageIMG = "src/img/Wmessage.png";
            }
            ImageIcon messageImageIcon = new ImageIcon(messageIMG);
            Image messageImage = messageImageIcon.getImage();
            Image message1Image = messageImage.getScaledInstance(50, 30, Image.SCALE_SMOOTH);
            ImageIcon message1ImageIcon = new ImageIcon(message1Image);           
            //신고함
            JButton ComplaintButton = new JButton(message1ImageIcon);
            ComplaintButton.addActionListener(e -> {
            	AdminComplaint adminComplaint = new AdminComplaint(userIDD, Section, DarK);
            });
            ComplaintButton.setBounds(50, 95, 50, 30);
            ComplaintButton.setBackground(colors.Ground);
            ComplaintButton.setBorder(borderWhite);
            panel.add(ComplaintButton);
        }

        
     // 검색창 텍스트 필드 설정
        RoundtextField searchField = new RoundtextField();
        searchField.setBounds(130, 140, 360, 43);
        searchField.setBackground(colors.BoardPanel);
        searchField.setForeground(new Color(255, 255, 255));
        searchField.setColumns(10);
        searchField.setBorder(borderBlue);
        searchField.setDefaultText("  검색");
        panel.add(searchField);

     // 검색 버튼 생성 및 설정
        JButton searchButton = new JButton("검색");
        searchButton.addActionListener(e -> {
            String searchWord = searchField.getText();
            searchclass search = new searchclass(userIDD, searchWord, Section, DarK);
            search.showFrame();
            frame.dispose();
        });
        searchButton.setBounds(490, 140, 30, 43);
        searchButton.setBackground(colors.Ground);
        searchButton.setForeground(new Color(155, 155, 155));
        searchButton.setBorder(borderWhite);
        searchButton.setContentAreaFilled(false);
        searchButton.setFocusPainted(false);
        searchButton.setOpaque(true);
        panel.add(searchButton);

        JTextArea textArea = new JTextArea(); // 텍스트 에어리어 생성
        panel.add(textArea); // 패널에 텍스트 에어리어 추가

        String cutUserUID = UserUID.substring(0, UserUID.length() - 2);

        // 자유게시판 버튼
        JButton freeBoardButton = new JButton("자유게시판");
        freeBoardButton.addActionListener(e -> {
            freeboardclass freeBoard = new freeboardclass(userIDD, "001", Section, DarK);
            freeBoard.showFrame();
            frame.dispose();
        });
        freeBoardButton.setFont(new Font(freeBoardButton.getFont().getName(), Font.BOLD, 16));
        freeBoardButton.setBounds(59, 210, 253, 30);
        freeBoardButton.setBackground(colors.BoardPanel);
        freeBoardButton.setForeground(colors.RedText);
        freeBoardButton.setBorder(borderWhite);
        freeBoardButton.setContentAreaFilled(false);
        freeBoardButton.setFocusPainted(false);
        freeBoardButton.setOpaque(true);
        panel.add(freeBoardButton);
        
        Font TimeFont = new Font(freeBoardButton.getFont().getName(), Font.BOLD, 8);

        // 자유게시판 목록 표시 패널 생성 및 설정
        JPanel freeBoardPanel = new JPanel();
        freeBoardPanel.setBounds(59, 239, 253, 187);
        freeBoardPanel.setBackground(colors.BoardPanel);
        freeBoardPanel.setBorder(borderWhite);
        freeBoardPanel.setLayout(null);
        panel.add(freeBoardPanel);
        
        //List<List<String>> bulletins = DBConnection.getAllBulletins();
        	

        GetBulletins getBulletins = new GetBulletins();
        List<List<String>> bulletins = getBulletins.getAllBulletins();
     
        int a2 = 0;
        int a3 =bulletins.size() -1;
        for (int a = 0; a < bulletins.size(); a++) {
            List<String> bulletin = bulletins.get(a3);

            String BulletinID = bulletin.get(0);
            String SearchBoardID = bulletin.get(3);
            String SearchTitle = bulletin.get(4);
            long SearchBdate = Long.parseLong(bulletin.get(6));
            String SearchUserID = bulletin.get(1);
            String bulletinUID = bulletin.get(2);
            String cutUID = bulletinUID.substring(0, bulletinUID.length() - 2);
            
            a3--;
            if (SearchBoardID.equals("001") && cutUserUID.equals(cutUID)) {
                String ShowTitle = SearchTitle;
                if (a2 == 5) {
                    break;
                }
                long NewDateTime = todayDate.TodayDate();
                long newMinte = NewDateTime % 100;
                long searchMinte = SearchBdate % 100;
                long minute = newMinte - searchMinte;

                long newHour = (NewDateTime % 10000) / 100;
                long searchHour = (SearchBdate % 10000) / 100;
                long hour = newHour - searchHour;
                
                if (minute < 0) {
                    minute += 60;
                    hour -= 1; // 분에서 빼준 만큼 시간을 조정
                }
                long newDay = (NewDateTime % 1000000) / 10000;
                long searchDay = (SearchBdate % 1000000) / 10000;
                long day = newDay - searchDay;
                if (hour < 0) {
                    hour += 24;
                    day -= 1; // 시간에서 빼준 만큼 날짜를 조정
                }
                long newmonth = (NewDateTime % 100000000) / 1000000;
                long searchmonth = (SearchBdate % 100000000) / 1000000;
                long month = newmonth - searchmonth;
                if (day < 0) {
                    day += 30;  // 필요 시 해당 달의 일수로 조정해야 할 수도 있음
                    month -= 1;
                }
                long newyear = NewDateTime / 100000000;
                long searchyear = SearchBdate / 100000000;
                long year = newyear - searchyear;
                if (month < 0) {
                    month += 12;
                    year -= 1;
                }
                String dayLabel = null;

                if (year > 0) {
                    dayLabel = searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (month > 0) {
                    dayLabel = searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (day > 0) {
                    dayLabel = searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (day == 0 && hour > 0) {
                    dayLabel = hour + "시간" + minute + "분 전";
                } else {
                    dayLabel = minute + "분 전";
                }

                JLabel TimeLabel = new JLabel(dayLabel);
                TimeLabel.setForeground(new Color(150, 150, 150)); // Set label text color
                TimeLabel.setFont(TimeFont);
                TimeLabel.setHorizontalAlignment(SwingConstants.RIGHT);

                JLabel rightLabel = new JLabel(ShowTitle + "");
                rightLabel.setForeground(new Color(150, 150, 150)); // Set label text color
                rightLabel.setFont(TimeFont);
                rightLabel.setFont(memberbuttonFont);
                rightLabel.setHorizontalAlignment(SwingConstants.LEFT);

                JButton postbutton = new JButton();
                postbutton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        showPost b = new showPost(userIDD, SearchUserID, BulletinID, "일반", Section, DarK);
                        b.showFrame();
                        frame.dispose();
                    }
                });
                postbutton.setBorder(borderWhite);
                postbutton.setBackground(colors.postbuttonColor);            
                postbutton.setBounds(5, 5 + (a2 * 36), 242, 33);
                postbutton.setLayout(new BorderLayout());
                postbutton.add(TimeLabel, BorderLayout.EAST);
                postbutton.add(rightLabel, BorderLayout.WEST);
                postbutton.setContentAreaFilled(false);
                postbutton.setFocusPainted(false);
                postbutton.setOpaque(true);
                freeBoardPanel.add(postbutton);
                a2++;
            }
        }

        JButton board2 = new JButton("비밀게시판"); // 버튼 생성 및 텍스트 설정
        board2.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                freeboardclass c = new freeboardclass(userIDD, "002", Section, DarK);
                c.showFrame();
                frame.dispose();
            }
        });
        board2.setBounds(320, 210, 253, 30); // 버튼 위치 및 크기 설정
        board2.setFont(new Font(freeBoardButton.getFont().getName(), Font.BOLD, 16));
        board2.setBackground(colors.BoardPanel);// 배경색 설정 (빨간색)
        board2.setForeground(colors.RedText); // 텍스트 색상(흰색)
        board2.setBorder(borderBlack); // 테두리 설정
        board2.setContentAreaFilled(false);
        board2.setFocusPainted(false);
        board2.setOpaque(true);
        panel.add(board2); // 패널에 버튼 추가
        board2.setBorder(borderWhite); // 테두리 설정

        JPanel panel_2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        panel_2.setBounds(320, 239, 253, 187);
        panel_2.setBackground(colors.BoardPanel);
        panel_2.setBorder(borderBlack);
        panel.add(panel_2);
        panel_2.setBorder(borderWhite); // 테두리 설정
        panel_2.setLayout(null);

        int b2 = 0;
        int b3 =bulletins.size() -1;
        for (int a = 0; a < bulletins.size(); a++) {
            List<String> bulletin = bulletins.get(b3);
            String BulletinID = bulletin.get(0);
            String SearchBoardID = bulletin.get(3);
            String SearchTitle = bulletin.get(4);
            long SearchBdate = Long.parseLong(bulletin.get(6));
            String SearchUserID = bulletin.get(1);
            String bulletinUID = bulletin.get(2);
            String cutUID = bulletinUID.substring(0, bulletinUID.length() - 2);
            b3--;
            if (SearchBoardID.equals("002") && cutUserUID.equals(cutUID)) {
                String ShowTitle = SearchTitle;
                if (b2 == 5) {
                    break;
                }

                long NewDateTime = todayDate.TodayDate();
                long newMinte = NewDateTime % 100;
                long searchMinte = SearchBdate % 100;
                long minute = newMinte - searchMinte;
                if (minute < 0) {
                    minute = 60 + minute;
                }
                long newHour = (NewDateTime % 10000) / 100;
                long searchHour = (SearchBdate % 10000) / 100;
                long hour = newHour - searchHour;
                if (hour < 0) {
                    hour = 24 + hour;
                }
                long newDay = (NewDateTime % 1000000) / 10000;
                long searchDay = (SearchBdate % 1000000) / 10000;
                long day = newDay - searchDay;
                long newmonth = (NewDateTime % 100000000) / 1000000;
                long searchmonth = (SearchBdate % 100000000) / 1000000;
                long month = newmonth - searchmonth;
                long newyear = NewDateTime / 100000000;
                long searchyear = SearchBdate / 100000000;
                long year = newyear - searchyear;

                String dayLabel = null;

                if (year > 0) {
                    dayLabel = searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (month > 0) {
                    dayLabel = searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (day > 0) {
                    dayLabel = searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (day == 0 && hour > 0) {
                    dayLabel = hour + "시간" + minute + "분 전";
                } else {
                    dayLabel = minute + "분 전";
                }

                JLabel TimeLabel = new JLabel(dayLabel);
                TimeLabel.setForeground(new Color(150, 150, 150)); // Set label text color
                TimeLabel.setFont(TimeFont);
                TimeLabel.setHorizontalAlignment(SwingConstants.RIGHT);

                JLabel rightLabel = new JLabel(ShowTitle + "");
                rightLabel.setForeground(new Color(150, 150, 150)); // Set label text color
                rightLabel.setFont(TimeFont);
                rightLabel.setFont(memberbuttonFont);
                rightLabel.setHorizontalAlignment(SwingConstants.LEFT);

                JButton postbutton = new JButton();
                postbutton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        showPost b = new showPost(userIDD, SearchUserID, BulletinID, "일반", Section, DarK);
                        b.showFrame();
                        frame.dispose();
                    }
                });
                postbutton.setBorder(borderWhite);
                postbutton.setBackground(colors.postbuttonColor);
                postbutton.setBounds(5, 5 + (b2 * 36), 242, 33);
                postbutton.setLayout(new BorderLayout());
                postbutton.add(TimeLabel, BorderLayout.EAST);
                postbutton.add(rightLabel, BorderLayout.WEST);
                postbutton.setContentAreaFilled(false);
                postbutton.setFocusPainted(false);
                postbutton.setOpaque(true);
                panel_2.add(postbutton);
                b2++;
            }
        }

        // 신입생게시판 박스
        JButton board3 = new JButton("신입생게시판"); // 버튼 생성 및 텍스트 설정
        board3.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                freeboardclass c = new freeboardclass(userIDD, "003", Section, DarK);
                c.showFrame();
                frame.dispose();
            }
        });
        board3.setBounds(59, 435, 253, 30); // 버튼 위치 및 크기 설정
        board3.setFont(new Font(freeBoardButton.getFont().getName(), Font.BOLD, 16));
        board3.setBackground(colors.BoardPanel);// 배경색 설정 (빨간색)
        board3.setForeground(colors.RedText); // 텍스트 색상(흰색)
        board3.setBorder(borderBlack); // 테두리 설정
        board3.setContentAreaFilled(false);
        board3.setFocusPainted(false);
        board3.setOpaque(true);
        panel.add(board3); // 패널에 버튼 추가
        board3.setBorder(borderWhite); // 테두리 설정

        // 자유게시판 아래에 추가 패널 생성
        JPanel panel_3 = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        panel_3.setBounds(59, 464, 253, 187);
        panel_3.setBackground(colors.BoardPanel);
        panel_3.setBorder(borderBlack);
        panel.add(panel_3);
        panel_3.setBorder(borderWhite); // 테두리 설정
        panel_3.setLayout(null);
        int c2 = 0;
        int c3 =bulletins.size() -1;
        for (int a = 0; a < bulletins.size(); a++) {
            List<String> bulletin = bulletins.get(c3);
            String BulletinID = bulletin.get(0);
            String SearchBoardID = bulletin.get(3);
            String SearchTitle = bulletin.get(4);
            long SearchBdate = Long.parseLong(bulletin.get(6));
            String SearchUserID = bulletin.get(1);
            String bulletinUID = bulletin.get(2);
            String cutUID = bulletinUID.substring(0, bulletinUID.length() - 2);
            c3--;
            if (SearchBoardID.equals("003") && cutUserUID.equals(cutUID)) {
                String ShowTitle = SearchTitle;
                if (c2 == 5) {
                    break;
                }

                long NewDateTime = todayDate.TodayDate();
                long newMinte = NewDateTime % 100;
                long searchMinte = SearchBdate % 100;
                long minute = newMinte - searchMinte;
                if (minute < 0) {
                    minute = 60 + minute;
                }
                long newHour = (NewDateTime % 10000) / 100;
                long searchHour = (SearchBdate % 10000) / 100;
                long hour = newHour - searchHour;
                if (hour < 0) {
                    hour = 24 + hour;
                }
                long newDay = (NewDateTime % 1000000) / 10000;
                long searchDay = (SearchBdate % 1000000) / 10000;
                long day = newDay - searchDay;
                long newmonth = (NewDateTime % 100000000) / 1000000;
                long searchmonth = (SearchBdate % 100000000) / 1000000;
                long month = newmonth - searchmonth;
                long newyear = NewDateTime / 100000000;
                long searchyear = SearchBdate / 100000000;
                long year = newyear - searchyear;

                String dayLabel = null;

                if (year > 0) {
                    dayLabel = searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (month > 0) {
                    dayLabel = searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (day > 0) {
                    dayLabel = searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (day == 0 && hour > 0) {
                    dayLabel = hour + "시간" + minute + "분 전";
                } else {
                    dayLabel = minute + "분 전";
                }

                JLabel TimeLabel = new JLabel(dayLabel);
                TimeLabel.setForeground(new Color(150, 150, 150)); // Set label text color
                TimeLabel.setFont(TimeFont);
                TimeLabel.setHorizontalAlignment(SwingConstants.RIGHT);

                JLabel rightLabel = new JLabel(ShowTitle + "");
                rightLabel.setForeground(new Color(150, 150, 150)); // Set label text color
                rightLabel.setFont(TimeFont);
                rightLabel.setFont(memberbuttonFont);
                rightLabel.setHorizontalAlignment(SwingConstants.LEFT);

                JButton postbutton = new JButton();
                postbutton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        showPost b = new showPost(userIDD, SearchUserID, BulletinID, "일반", Section, DarK);
                        b.showFrame();
                        frame.dispose();
                    }
                });
                postbutton.setBorder(borderWhite);
                postbutton.setBackground(colors.postbuttonColor);
                postbutton.setBounds(5, 5 + (c2 * 36), 242, 33);
                postbutton.setLayout(new BorderLayout());
                postbutton.add(TimeLabel, BorderLayout.EAST);
                postbutton.add(rightLabel, BorderLayout.WEST);
                postbutton.setContentAreaFilled(false);
                postbutton.setFocusPainted(false);
                postbutton.setOpaque(true);
                panel_3.add(postbutton);
                c2++;
            }
        }

        // 졸업생게시판
        JButton board4 = new JButton("졸업생게시판"); // 버튼 생성 및 텍스트 설정
        board4.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                freeboardclass c = new freeboardclass(userIDD, "004", Section, DarK);
                c.showFrame();
                frame.dispose();
            }
        });
        board4.setBounds(320, 435, 253, 30); // 버튼 위치 및 크기 설정
        board4.setFont(new Font(freeBoardButton.getFont().getName(), Font.BOLD, 16));
        board4.setBackground(colors.BoardPanel);// 배경색 설정 (빨간색)
        board4.setForeground(colors.RedText); // 텍스트 색상(흰색)
        board4.setBorder(borderBlack); // 테두리 설정
        board4.setContentAreaFilled(false);
        board4.setFocusPainted(false);
        board4.setOpaque(true);
        panel.add(board4); // 패널에 버튼 추가
        board4.setBorder(borderWhite); // 테두리 설정

        // 자유게시판 아래에 추가 패널 생성
        JPanel panel_4 = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        panel_4.setBounds(320, 464, 253, 187);
        panel_4.setBackground(colors.BoardPanel);
        panel_4.setBorder(borderBlack);
        panel.add(panel_4);
        panel_4.setBorder(borderWhite); // 테두리 설정
        panel_4.setLayout(null);
        int d2 = 0;
        int d3 =bulletins.size() -1;
        for (int a = 0; a < bulletins.size(); a++) {
            List<String> bulletin = bulletins.get(d3);
            String BulletinID = bulletin.get(0);
            String SearchBoardID = bulletin.get(3);
            String SearchTitle = bulletin.get(4);
            long SearchBdate = Long.parseLong(bulletin.get(6));
            String SearchUserID = bulletin.get(1);
            String bulletinUID = bulletin.get(2);
            String cutUID = bulletinUID.substring(0, bulletinUID.length() - 2);
            d3--;
            if (SearchBoardID.equals("004") && cutUserUID.equals(cutUID)) {
                String ShowTitle = SearchTitle;
                if (d2 == 5) {
                    break;
                }

                long NewDateTime = todayDate.TodayDate();
                long newMinte = NewDateTime % 100;
                long searchMinte = SearchBdate % 100;
                long minute = newMinte - searchMinte;
                if (minute < 0) {
                    minute = 60 + minute;
                }
                long newHour = (NewDateTime % 10000) / 100;
                long searchHour = (SearchBdate % 10000) / 100;
                long hour = newHour - searchHour;
                if (hour < 0) {
                    hour = 24 + hour;
                }
                long newDay = (NewDateTime % 1000000) / 10000;
                long searchDay = (SearchBdate % 1000000) / 10000;
                long day = newDay - searchDay;
                long newmonth = (NewDateTime % 100000000) / 1000000;
                long searchmonth = (SearchBdate % 100000000) / 1000000;
                long month = newmonth - searchmonth;
                long newyear = NewDateTime / 100000000;
                long searchyear = SearchBdate / 100000000;
                long year = newyear - searchyear;

                String dayLabel = null;

                if (year > 0) {
                    dayLabel = searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (month > 0) {
                    dayLabel = searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (day > 0) {
                    dayLabel = searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
                } else if (day == 0 && hour > 0) {
                    dayLabel = hour + "시간" + minute + "분 전";
                } else {
                    dayLabel = minute + "분 전";
                }

                JLabel TimeLabel = new JLabel(dayLabel);
                TimeLabel.setForeground(new Color(150, 150, 150)); // Set label text color
                TimeLabel.setFont(TimeFont);
                TimeLabel.setHorizontalAlignment(SwingConstants.RIGHT);

                JLabel rightLabel = new JLabel(ShowTitle + "");
                rightLabel.setForeground(new Color(150, 150, 150)); // Set label text color
                rightLabel.setFont(TimeFont);
                rightLabel.setFont(memberbuttonFont);
                rightLabel.setHorizontalAlignment(SwingConstants.LEFT);

                JButton postbutton = new JButton();
                postbutton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        showPost b = new showPost(userIDD, SearchUserID, BulletinID, "일반", Section, DarK);
                        b.showFrame();
                        frame.dispose();
                    }
                });
                postbutton.setBorder(borderWhite);
                postbutton.setBackground(colors.postbuttonColor);
                postbutton.setBounds(5, 5 + (d2 * 36), 242, 33);
                postbutton.setLayout(new BorderLayout());
                postbutton.add(TimeLabel, BorderLayout.EAST);
                postbutton.add(rightLabel, BorderLayout.WEST);
                postbutton.setContentAreaFilled(false);
                postbutton.setFocusPainted(false);
                postbutton.setOpaque(true);
                panel_4.add(postbutton);
                d2++;
            }
        }

    }


    
    

    public void showFrame() {
        frame.setVisible(true);
    }
}
