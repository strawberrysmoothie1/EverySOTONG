package main.java.com.pws.Board;

import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.RenderingHints;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.Border;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.plaf.basic.BasicScrollBarUI;

import org.json.JSONObject;

import main.java.com.pws.Login.login;
import main.java.com.pws.Schedule.schedule;
import main.java.com.pws.Thing.FrameManager;
import main.java.com.pws.Thing.GetComments;
import main.java.com.pws.Thing.GetUsers;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.User.mypage;
import main.java.com.pws.dialog.DeleteComment;
import main.java.com.pws.dialog.DeletePost;
import main.java.com.pws.dialog.UserInfo;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.RoundedBorder;
import main.java.com.pws.Thing.RoundtextField;
import main.java.com.pws.Thing.TodayDate;
import main.java.com.pws.Thing.collor;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JLabel;

import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;

public class showPost {
    //static String LogID;
	private String userIDD;
    private String PostuserIDD;
    private String PostIDD;
    private String Section;
    private String CommentsUSERID;
    private String problemID;


    private JFrame frame;
    private int DarK;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    login window = new login();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public showPost(String userIDD, String PostuserIDD, String PostIDD, String problemID, String Section, int DarK) {
        this.userIDD = userIDD;
        this.PostuserIDD = PostuserIDD;
        this.PostIDD = PostIDD;
        this.Section = Section;
        this.DarK = DarK;
        this.problemID = problemID;

        initialize();
    }
    
 
    private void initialize() {
    	JSONObject data = new JSONObject();
        TodayDate todayDate = new TodayDate();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }


        frame = new JFrame();
        frame.setBounds(100, 100, 650, 800); // 프레임 위치 및 크기 설정
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // 닫기 버튼 동작 설정
        frame.getContentPane().setLayout(null);

    	FrameManager.addFrame(frame);
    	
        // 테두리 스타일 설정

        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        Border borderBlack = BorderFactory.createLineBorder(colors.BoardPanel);
        Border Complaintborder = BorderFactory.createLineBorder(new Color(255, 100, 100), 2);


        JPanel panel = new JPanel();
        panel.setBounds(5, 0, 625, 755);
        frame.getContentPane().add(panel);
        panel.setLayout(null);
        panel.setBackground(colors.Ground); // 배경색 설정

        // 에브리소통 그림2
        String everyTimeIMG = "src/img/everygood.png";
        if(DarK == 1) {
        	everyTimeIMG = "src/img/everygoodDark.png";
        }
        ImageIcon everyImageIcon = new ImageIcon(everyTimeIMG);
        Image everyImage = everyImageIcon.getImage();
        Image every1Image = everyImage.getScaledInstance(120, 30, Image.SCALE_SMOOTH);
        ImageIcon every1ImageIcon = new ImageIcon(every1Image);
        JButton image1Button = new JButton(every1ImageIcon);
        image1Button.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        image1Button.setBounds(30, 40, 120, 30);
        image1Button.setBorder(borderWhite);
        image1Button.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                boardclass b = new boardclass(userIDD, Section, DarK);
                b.showFrame();
                frame.dispose();
            }
        });
        panel.add(image1Button);
        
        // 신고 그림
        String declarationIMG = "src/img/declaration.png";
        ImageIcon declarationImageIcon = new ImageIcon(declarationIMG);
        Image declarationImage = declarationImageIcon.getImage();
        Image declaration1Image = declarationImage.getScaledInstance(17, 20, Image.SCALE_SMOOTH);
        ImageIcon declaration1ImageIcon = new ImageIcon(declaration1Image);
        JButton declaration1Button = new JButton(declaration1ImageIcon);
        declaration1Button.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        declaration1Button.setBounds(575, 375, 17, 20);
        declaration1Button.setBorder(borderWhite);
        declaration1Button.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
            	ComplaintDialog(PostuserIDD, "P", PostIDD);
            }
        });
        panel.add(declaration1Button);

        data.put("table", "bulletin");
        data.put("want", "BoardID");
        data.put("what", "BulletinID");
        data.put("user_id", PostIDD);
        Post po = new Post();
		JSONObject SearchBoardID1 = po.jsonpost("/find_user_information", data);
		String SearchBoardID = SearchBoardID1.getString("BoardID");
        
        
        // 게시판 버튼
        JButton btnClickMe = new JButton("게시판"); // 버튼 생성 및 텍스트 설정
        btnClickMe.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                freeboardclass c = new freeboardclass(userIDD, SearchBoardID, Section, DarK);
                c.showFrame();
                frame.dispose();
            }
        });
        btnClickMe.setBounds(210, 32, 100, 45); // 버튼 위치 및 크기 설정
        btnClickMe.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        btnClickMe.setForeground(colors.Text); // 텍스트 색상(흰색)
        panel.add(btnClickMe); // 패널에 버튼 추가
        Font buttonFont = new Font(btnClickMe.getFont().getName(), Font.BOLD, 18);
        btnClickMe.setFont(buttonFont);
        btnClickMe.setBorder(borderWhite); // 테두리 설정
        btnClickMe.setContentAreaFilled(false);
        btnClickMe.setFocusPainted(false);
        btnClickMe.setOpaque(true);

        // 시간표 버튼
        JButton Schedule = new JButton("시간표"); // 버튼 생성 및 텍스트 설정
        Schedule.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                schedule a = new schedule(userIDD, Section, DarK);
                a.showFrame();
                frame.dispose();
            }
        });
        Schedule.setBounds(320, 32, 100, 45); // 버튼 위치 및 크기 설정
        Schedule.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        Schedule.setForeground(colors.Text); // 텍스트 색상(흰색)
        panel.add(Schedule); // 패널에 버튼 추가
        Font ScheduleFont = new Font(Schedule.getFont().getName(), Font.PLAIN, 18);
        Schedule.setFont(ScheduleFont);
        Schedule.setBorder(borderWhite); // 테두리 설정
        Schedule.setContentAreaFilled(false);
        Schedule.setFocusPainted(false);
        Schedule.setOpaque(true);


        // 게시판 버튼        
        data.put("table", "board");
        data.put("want", "BoardName");
        data.put("what", "BoardID");
        data.put("user_id", SearchBoardID);
		JSONObject SearchBoardname1 = po.jsonpost("/find_user_information", data);
		String SearchBoardname = SearchBoardname1.getString("BoardName");
		
        JButton BackButton = new JButton(SearchBoardname); // 버튼 생성 및 텍스트 설정
        BackButton.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                freeboardclass c = new freeboardclass(userIDD, SearchBoardID, Section, DarK);
                c.showFrame();
                frame.dispose();
            }
        });
        BackButton.setBounds(237, 98, 150, 22); // 버튼 위치 및 크기 설정
        BackButton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        BackButton.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
        panel.add(BackButton); // 패널에 버튼 추가
        Font BackFont = new Font(BackButton.getFont().getName(), Font.PLAIN, 16);
        BackButton.setFont(BackFont);
        BackButton.setBorder(borderWhite); // 테두리 설정
        BackButton.setContentAreaFilled(false);
        BackButton.setFocusPainted(false);
        BackButton.setOpaque(true);

        // 게시글 라벨
        JLabel BoardnameLabel = new JLabel("게시글");
        BoardnameLabel.setBounds(278, 120, 150, 27); // Adjust the position and size as needed
        BoardnameLabel.setForeground(colors.Text); // Set label text color
        Font labelFont2 = new Font(BoardnameLabel.getFont().getName(), Font.BOLD, 22);
        BoardnameLabel.setFont(labelFont2);
        panel.add(BoardnameLabel);

        Font TimeFont = new Font(BoardnameLabel.getFont().getName(), Font.BOLD, 8);

        // 댓글 버튼
        RoundedButton commentbutton = new RoundedButton("댓글 달기");
        commentbutton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                
                data.put("table", "users");
                data.put("want", "LimitDate");
                data.put("what", "UserID");
                data.put("user_id", userIDD);
        		JSONObject SearchBdate1 = po.jsonpost("/find_user_information", data);
        		long SearchBdate = SearchBdate1.getLong("LimitDate");
                
                long NowDateTime = todayDate.TodayDate();
                if (NowDateTime > SearchBdate) {
                    NewcommentsDialog();
                } else {
                    LimitDialog(userIDD);
                }
            }
        });
        commentbutton.setBackground(new Color(200, 50, 50));// 배경색 설정 (빨간색)
        commentbutton.setForeground(colors.Ground); // 텍스트 색상(흰색)
        commentbutton.setBounds(470, 180, 70, 25);
        Font RedFont = new Font(commentbutton.getFont().getName(), Font.BOLD, 12);
        commentbutton.setFont(RedFont);
        panel.add(commentbutton);

        data.put("table", "users");
        data.put("want", "Nickname");
        data.put("what", "UserID");
        data.put("user_id", PostuserIDD);
		JSONObject SearchNickname1 = po.jsonpost("/find_user_information", data);
		String SearchNickname = SearchNickname1.getString("Nickname");
        
        // 게시물삭제
        if (PostuserIDD.equals(userIDD)|| userIDD.equals("admin")) {
            RoundedButton CDeletebutton = new RoundedButton("게시물 삭제");
            CDeletebutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    DeletePost deletePost = new DeletePost(SearchBoardID, userIDD, Section, DarK);
                }
            });
            CDeletebutton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
            CDeletebutton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
            CDeletebutton.setBounds(470, 145, 70, 20);
            panel.add(CDeletebutton);

        } if (PostuserIDD.equals(userIDD)){
            RoundedButton Correctionbutton = new RoundedButton("수정");
            Correctionbutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    NewPostDialog(userIDD);
                }
            });
            Correctionbutton.setBackground(new Color(200, 100, 100));// 배경색 설정 (빨간색)
            Correctionbutton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
            Correctionbutton.setBounds(470, 210, 70, 20);
            panel.add(Correctionbutton);
        }

        // 이미지 유저
        ImageIcon userImageIcon = new ImageIcon("src/img/user.png");
        Image userImage = userImageIcon.getImage();
        Image user1Image = userImage.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        ImageIcon user1ImageIcon = new ImageIcon(user1Image);
        JButton user1Button = new JButton(user1ImageIcon);
        user1Button.setBackground(new Color(255, 255, 255));// 배경색 설정 (빨간색)
        user1Button.setBounds(90, 170, 50, 50);
        user1Button.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        user1Button.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
            	UserInfo userDialog = new UserInfo(userIDD, PostuserIDD, DarK);
            }
        });
        panel.add(user1Button);

        // 닉네임
        JLabel Nickname = new JLabel(SearchNickname);
        Nickname.setBounds(150, 179, 150, 20); // Adjust the position and size as needed
        Nickname.setForeground(colors.Text); // Set label text color
        Font labelFont4 = new Font(Nickname.getFont().getName(), Font.BOLD, 16);
        Nickname.setFont(labelFont4);
        panel.add(Nickname);

        // 시간        
        data.put("table", "bulletin");
        data.put("want", "Bdate");
        data.put("what", "BulletinID");
        data.put("user_id", PostIDD);
		JSONObject SearchBdate1 = po.jsonpost("/find_user_information", data);
		long SearchBdate = SearchBdate1.getLong("Bdate");
        
        long searchMinte = SearchBdate % 100;
        long searchHour = (SearchBdate % 10000) / 100;
        long searchDay = (SearchBdate % 1000000) / 10000;
        long searchmonth = (SearchBdate % 100000000) / 1000000;
        String dayLabel3 = null;
        dayLabel3 = searchmonth + "/" + searchDay + " " + searchHour + ":" + searchMinte;
        JLabel Time = new JLabel(dayLabel3);
        Time.setBounds(150, 199, 150, 20); // Adjust the position and size as needed
        Time.setForeground(new Color(100, 100, 100)); // Set label text color
        Font TimeFont1 = new Font(Time.getFont().getName(), Font.BOLD, 12);
        Time.setFont(TimeFont1);
        panel.add(Time);

        data.put("table", "bulletin");
        data.put("want", "BulletinTitle");
        data.put("what", "BulletinID");
        data.put("user_id", PostIDD);
		JSONObject SearchTitle1 = po.jsonpost("/find_user_information", data);
		String SearchTitle = SearchTitle1.getString("BulletinTitle");
                
        data.put("table", "bulletin");
        data.put("want", "Bcontent");
        data.put("what", "BulletinID");
        data.put("user_id", PostIDD);
		JSONObject SearchContent1 = po.jsonpost("/find_user_information", data);
		String SearchContent = SearchContent1.getString("Bcontent");
        
        // 게시글 라벨
        JLabel TitleLabel = new JLabel(SearchTitle);
        TitleLabel.setBounds(77, 240, 300, 25); // Adjust the position and size as needed
        TitleLabel.setForeground(colors.Text); // Set label text color
        Font TitleFont = new Font(TitleLabel.getFont().getName(), Font.BOLD, 16);
        TitleLabel.setFont(TitleFont);
        panel.add(TitleLabel);
        Font contentFont = new Font(TitleLabel.getFont().getName(), Font.BOLD, 11);

        // 내용 라벨
        JTextArea ContentTextArea = new JTextArea(SearchContent);
        ContentTextArea.setBounds(75, 280, 540, 130); // Adjust the position and size as needed
        ContentTextArea.setForeground(new Color(120, 120, 120)); // Set text color
        Font ContentFont = new Font(ContentTextArea.getFont().getName(), Font.BOLD, 13);
        ContentTextArea.setFont(ContentFont);
        ContentTextArea.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        ContentTextArea.setLineWrap(true); // 자동 줄 바꿈 활성화
        ContentTextArea.setWrapStyleWord(true); // 단어 단위로 줄 바꿈
        panel.add(ContentTextArea);
        
        data.put("table", "comments");
        data.put("want", "BulletinID");
        data.put("boardID", PostIDD);
    	JSONObject SearchCount1 = po.jsonpost("/board_find_post_id", data);
    	int SearchCount = SearchCount1.getInt("count");
        
        // 댓글 패널 생성
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(colors.Ground);
        int hight = 346;
        if (SearchCount > 4) {
            hight = 5 + 72 * SearchCount;
        }
        panel_1.setBounds(73, 415, 480, hight);
        panel.add(panel_1);
        panel_1.setLayout(null);
        panel_1.setBorder(borderWhite); // 테두리 설정
        RoundedBorder roundedBorder = new RoundedBorder(20);
        panel_1.setPreferredSize(new Dimension(480, hight));
        
	
    	GetComments getComments = new GetComments();
        List<List<String>> comments = getComments.getAllComments();
    	
        int COUNT = 0;
        int aa = comments.size() -1 ;
        for (int a = 1; a <= comments.size(); a++) {
        	List<String> comment = comments.get(aa);

            String ShowContent = null;
            String ShowCNicname = null;
            
            String CommentsID = comment.get(0);
            String SearchPostID = comment.get(5);
            String commentsContent = comment.get(2);
            long commentsCdate = Long.parseLong(comment.get(3));
            String commentsUser = comment.get(1);
            String CommentsLikes = comment.get(4);

                        
            data.put("table", "users");
            data.put("want", "Nickname");
            data.put("what", "UserID");
            data.put("user_id", commentsUser);
    		JSONObject commentsNickname1 = po.jsonpost("/find_user_information", data);
    		String commentsNickname = commentsNickname1.getString("Nickname");

            aa--;

            if (SearchPostID.equals(PostIDD)) {
                // 게시물 페널
                
                JPanel CommentPanel = new JPanel();
                CommentPanel.setBackground(colors.Ground);           
                CommentPanel.setBounds(73, 5 + (72 * COUNT), 474, 70);
                panel_1.add(CommentPanel);
                CommentPanel.setLayout(null);
                CommentPanel.setBorder(roundedBorder);

                // 변수 설정
                ShowCNicname = commentsNickname;
                ShowContent = commentsContent;

                long NewCDateTime = todayDate.TodayDate();
                long newCMinte = NewCDateTime % 100;
                long searchCMinte = commentsCdate % 100;
                long Cminute = 0;
                Cminute = newCMinte - searchCMinte;
                if (Cminute < 0) {
                    Cminute = 60 + Cminute;
                }
                long newCHour = (NewCDateTime % 10000) / 100;
                long searchCHour = (commentsCdate % 10000) / 100;
                long Chour = 0;
                Chour = newCHour - searchCHour;
                if (Chour < 0) {
                    Chour = 24 + Chour;
                }
                long newCDay = (NewCDateTime % 1000000) / 10000;
                long searchCDay = (commentsCdate % 1000000) / 10000;
                long Cday = 0;
                Cday = newCDay - searchCDay;

                long newCmonth = (NewCDateTime % 100000000) / 1000000;
                long searchCmonth = (commentsCdate % 100000000) / 1000000;
                long Cmonth = 0;
                Cmonth = newCmonth - searchCmonth;

                long newCyear = NewCDateTime / 100000000;
                long searchCyear = commentsCdate / 100000000;
                long Cyear = 0;
                Cyear = newCyear - searchCyear;

                String CdayLabel = null;
                if (Cyear > 0) {
                    CdayLabel = searchCyear + " " + searchCmonth + "/" + searchCDay + " " + searchCHour + ":"
                            + searchCMinte;
                } else if (Cmonth > 0) {
                    CdayLabel = searchCmonth + "/" + searchCDay + " " + searchCHour + ":" + searchCMinte;
                } else if (Cday > 0) {
                    CdayLabel = searchCmonth + "/" + searchCDay + " " + searchCHour + ":" + searchCMinte;
                } else if (Cday == 0 && Chour > 0) {
                    CdayLabel = Chour + "시간" + Cminute + "분 전";
                } else {
                    CdayLabel = Cminute + "분 전";
                }

                // 시간 라벨
                JLabel TimeCLabel = new JLabel(CdayLabel);
                TimeCLabel.setBounds(12, 50, 60, 15); // Adjust the position and size as needed
                TimeCLabel.setForeground(new Color(100, 100, 100)); // Set label text color
                TimeCLabel.setFont(TimeFont);
                CommentPanel.add(TimeCLabel);

                // 내용 라벨
                JLabel contentbutton = new JLabel(ShowContent);
                contentbutton.setBounds(11, 33, 420, 15); // Adjust the position and size as needed
                if(CommentsID.equals(problemID)) {
                	contentbutton.setForeground(new Color(255, 100, 100));
                }
                else {
                    contentbutton.setForeground(colors.Text); // Set label text color
                }
                contentbutton.setFont(contentFont);
                CommentPanel.add(contentbutton);

                // 이미지 유저
                ImageIcon CImageIcon = new ImageIcon("src/img/user.png");
                Image CuserImage = CImageIcon.getImage();
                Image user2Image = CuserImage.getScaledInstance(26, 26, Image.SCALE_SMOOTH);
                ImageIcon user2ImageIcon = new ImageIcon(user2Image);
                JButton user2Button = new JButton(user2ImageIcon);
                user2Button.setBackground(new Color(255, 255, 255));// 배경색 설정 (빨간색)
                user2Button.setBounds(8, 5, 26, 26);
                user2Button.setBorder(BorderFactory.createLineBorder(Color.WHITE));
                user2Button.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
                    public void actionPerformed(ActionEvent e) {
                    	UserInfo userDialog = new UserInfo(userIDD, PostuserIDD, DarK);
                    }
                });
                CommentPanel.add(user2Button);

                // 닉네임
                JButton Nicknamebutton = new JButton(ShowCNicname);
                Nicknamebutton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                    	UserInfo userDialog = new UserInfo(userIDD, commentsUser, DarK);
                    }
                });
                Nicknamebutton.setBorder(borderWhite);
                Nicknamebutton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
                if(CommentsID.equals(problemID)) {
                	Nicknamebutton.setForeground(new Color(255, 100, 100));
                }
                else {
                    Nicknamebutton.setForeground(colors.Text); // 텍스트 색상(흰색)
                }
                Nicknamebutton.setBounds(34, 7, 52, 15);
                Nicknamebutton.setFont(contentFont);
                Nicknamebutton.setContentAreaFilled(false);
                Nicknamebutton.setFocusPainted(false);
                Nicknamebutton.setOpaque(true);
                CommentPanel.add(Nicknamebutton);

                // 댓글 삭제 commentsUser
                if (commentsUser.equals(userIDD) || userIDD.equals("admin")) {
                    RoundedButton CDeletebutton = new RoundedButton("삭제");
                    CDeletebutton.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                        	DeleteComment deleteComment = 
                        			new DeleteComment(CommentsID, userIDD, PostuserIDD, PostIDD, Section, DarK);
                        }
                    });
                    CDeletebutton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
                    CDeletebutton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
                    CDeletebutton.setBounds(89, 8, 27, 15);
                    CDeletebutton.setFont(TimeFont);

                    CommentPanel.add(CDeletebutton);
                }
                
                // 신고 그림
                String CdeclarationIMG = "src/img/declaration.png";
                ImageIcon CdeclarationImageIcon = new ImageIcon(CdeclarationIMG);
                Image CdeclarationImage = CdeclarationImageIcon.getImage();
                Image Cdeclaration1Image = CdeclarationImage.getScaledInstance(12, 14, Image.SCALE_SMOOTH);
                ImageIcon Cdeclaration1ImageIcon = new ImageIcon(Cdeclaration1Image);
                JButton Cdeclaration1Button = new JButton(Cdeclaration1ImageIcon);
                Cdeclaration1Button.setBackground(colors.Ground);// 배경색 설정 (빨간색)
                Cdeclaration1Button.setBounds(447, 50, 12, 14);
                Cdeclaration1Button.setBorder(borderWhite);
                Cdeclaration1Button.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
                    public void actionPerformed(ActionEvent e) {
                    	ComplaintDialog(commentsUser, "C", CommentsID);
                    }
                });
                CommentPanel.add(Cdeclaration1Button);

                int IntLike = Integer.parseInt(CommentsLikes);

                // 공감
                JButton LikesLabelButton = new JButton("공감");
                LikesLabelButton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
                LikesLabelButton.setBounds(440, 8, 25, 20);
                LikesLabelButton.setForeground(new Color(120, 120, 120)); // 텍스트 색상(흰색)
                LikesLabelButton.setBorder(borderWhite);
                LikesLabelButton.setFont(TimeFont);
                LikesLabelButton.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
                    public void actionPerformed(ActionEvent e) {                        
                        data.put("table", "users");
                        data.put("want", "LimitDate");
                        data.put("what", "UserID");
                        data.put("user_id", userIDD);
                        Post po = new Post();
                    	JSONObject SearchBdate1 = po.jsonpost("/find_user_information", data);
                    	long SearchBdate = SearchBdate1.getLong("LimitDate");
                        
                        long NowDateTime = todayDate.TodayDate();
                        if (NowDateTime > SearchBdate) {
                            int newIntLike = IntLike + 1;
                            String newStingLike = String.valueOf(newIntLike);                            
                            data.put("table", "comments");
                            data.put("this1", "CommentsID");
                            data.put("this2", CommentsID);
                            data.put("what", "likes");
                            data.put("change", newStingLike);
            				JSONObject change_check = po.jsonpost("/change_user", data);
            				boolean success = change_check.getBoolean("success"); 
            				System.out.println("좋아요 성공 여부: " + success);
            				
                            showPost b = new showPost(userIDD, PostuserIDD, PostIDD, "일반", Section, DarK);
                            b.showFrame();
                            frame.dispose();
                        } else {
                            LimitDialog(userIDD);
                        }
                    }
                });
                LikesLabelButton.setContentAreaFilled(false);
                LikesLabelButton.setFocusPainted(false);
                LikesLabelButton.setOpaque(true);
                CommentPanel.add(LikesLabelButton);

                if (IntLike > 0) {
                    // 이미지 좋아요
                    String likeIMG = "src/img/like.jpeg";
                    if(DarK == 1) {
                    	likeIMG = "src/img/DarkLike.png";
                    }
                    ImageIcon CommentsLikeIcon = new ImageIcon(likeIMG);
                    Image CommentsLikeImage = CommentsLikeIcon.getImage();
                    Image LikesImage = CommentsLikeImage.getScaledInstance(10, 10, Image.SCALE_SMOOTH);
                    ImageIcon Likes2ImageIcon = new ImageIcon(LikesImage);
                    JButton LikesButton = new JButton(Likes2ImageIcon);
                    LikesButton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
                    LikesButton.setBounds(65, 51, 10, 10);
                    LikesButton.setBorder(borderWhite);
                    LikesButton.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
                        public void actionPerformed(ActionEvent e) {
                            data.put("table", "users");
                            data.put("want", "LimitDate");
                            data.put("what", "UserID");
                            data.put("user_id", userIDD);
                            Post po = new Post();
                        	JSONObject SearchBdate1 = po.jsonpost("/find_user_information", data);
                        	long SearchBdate = SearchBdate1.getLong("LimitDate");
                            
                            long NowDateTime = todayDate.TodayDate();
                            if (NowDateTime > SearchBdate) {
                                int newIntLike = IntLike + 1;
                                String newStingLike = String.valueOf(newIntLike);                                
                                data.put("table", "comments");
                                data.put("this1", "CommentsID");
                                data.put("this2", CommentsID);
                                data.put("what", "likes");
                                data.put("change", newStingLike);
                				JSONObject change_check = po.jsonpost("/change_user", data);
                				boolean success = change_check.getBoolean("success"); 
                				System.out.println("좋아요 성공 여부: " + success);
                                
                                showPost b = new showPost(userIDD, PostuserIDD, PostIDD, "일반", Section, DarK);
                                b.showFrame();
                                frame.dispose();
                            } else {
                                LimitDialog(userIDD);
                            }
                        }
                    });
                    LikesButton.setContentAreaFilled(false);
                    LikesButton.setFocusPainted(false);
                    LikesButton.setOpaque(true);
                    CommentPanel.add(LikesButton);

                    JLabel LikeLabel = new JLabel(CommentsLikes);
                    LikeLabel.setBounds(75, 51, 10, 10); // Adjust the position and size as needed
                    LikeLabel.setForeground(new Color(100, 100, 100)); // Set label text color
                    LikeLabel.setFont(TimeFont);
                    CommentPanel.add(LikeLabel);     
                }

                COUNT++;
            }
        }

        // 스크롤바 추가
        JScrollPane scrollCPane = new JScrollPane(panel_1);
        scrollCPane.setBounds(0, 415, 625, 345); // JScrollPane의 위치 및 크기 설정
        scrollCPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        // 가로 스크롤바를 비활성화합니다.
        scrollCPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        // 세로 스크롤바의 UI 변경
        scrollCPane.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = new Color(100, 100, 100); // 스크롤바 색상 설정
            }

            @Override
            protected JButton createDecreaseButton(int orientation) {
                return new JButton() {
                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension(0, 0); // 위 버튼 크기 0으로 설정하여 숨김
                    }
                };
            }

            @Override
            protected JButton createIncreaseButton(int orientation) {
                return new JButton() {
                    @Override
                    public Dimension getPreferredSize() {
                        return new Dimension(0, 0); // 아래 버튼 크기 0으로 설정하여 숨김
                    }
                };
            }

            @Override
            protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // 둥근 모양의 스크롤바
                g2.setColor(Color.LIGHT_GRAY); // 색상 변경
                g2.fillRoundRect(thumbBounds.x, thumbBounds.y, thumbBounds.width, thumbBounds.height, 10, 10);

                g2.dispose();
            }
        });

        scrollCPane.setVisible(true);

        panel.add(scrollCPane);

        frame.getContentPane().add(panel);

        // 다이얼로그 표시
        frame.setVisible(true);

    }

    protected static void dispose() {
        // TODO Auto-generated method stub

    }

    // 댓글 쓰기
    private void NewcommentsDialog() {
    	JSONObject data = new JSONObject();
        TodayDate todayDate = new TodayDate();
        collor colors = new collor();
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }

        // 테두리 스타일 설정
        Border borderGray = BorderFactory.createLineBorder(colors.BoardPanel, 1);
        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);

        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(200, 273, 450, 450);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        // dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 100, 100);
        frame.getContentPane().add(dialogPanel);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogFrame.add(dialogPanel);

        // 변경 라벨
        JLabel ChangePWLabel = new JLabel("댓글 작성");
        ChangePWLabel.setBounds(185, 11, 150, 30); // Adjust the position and size as needed
        ChangePWLabel.setForeground(new Color(100, 100, 100)); // Set label text color
        Font ChangePWFont = new Font(ChangePWLabel.getFont().getName(), Font.BOLD, 14);
        ChangePWLabel.setFont(ChangePWFont);
        dialogPanel.add(ChangePWLabel);

        // 취소 버튼
        JButton BackButton = new JButton("취소"); // 버튼 생성 및 텍스트 설정
        BackButton.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                dialogFrame.dispose();
            }
        });
        BackButton.setBounds(382, 10, 60, 20); // 버튼 위치 및 크기 설정
        BackButton.setBackground(colors.Ground);// 배경색 설정
        BackButton.setForeground(colors.Text); // 텍스트 색상(흰색)
        dialogPanel.add(BackButton); // 패널에 버튼 추가
        Font memberbuttonFont = new Font(BackButton.getFont().getName(), Font.BOLD, 11);
        BackButton.setFont(memberbuttonFont);
        BackButton.setBorder(borderWhite); // 테두리 설정
        BackButton.setContentAreaFilled(false);
        BackButton.setFocusPainted(false);
        BackButton.setOpaque(true);

        // 내용페널
        JPanel Contentpanel = new JPanel();
        Contentpanel.setBackground(colors.Ground);
        Contentpanel.setBounds(50, 75, 340, 250);
        dialogPanel.add(Contentpanel);
        Contentpanel.setLayout(null);
        Contentpanel.setBorder(borderGray); // 테두리 설정
        RoundedBorder roundedBorder = new RoundedBorder(20);
        Contentpanel.setBorder(roundedBorder);

        // 내용 필드
        JTextArea ContentField = new JTextArea();
        ContentField.setBounds(5, 5, 330, 240);
        ContentField.setBackground(colors.Ground);
        ContentField.setForeground(colors.Text);
        ContentField.setLineWrap(true);
        ContentField.setWrapStyleWord(true);

        JLabel TextLabel = new JLabel("");
        Font TextFont = new Font(BackButton.getFont().getName(), Font.BOLD, 11);
        TextLabel.setFont(TextFont);
        dialogPanel.add(TextLabel);
        TextLabel.setBounds(340, 310, 100, 15);
        // DocumentListener를 사용하여 내용이 변경될 때마다 이벤트 처리
        ContentField.getDocument().addDocumentListener(new DocumentListener() {

            private void checkCharacterLimit() {
                if (ContentField.getText().length() > 400) {
                    String truncatedText = ContentField.getText().substring(0, 400);
                    ContentField.setText(truncatedText);
                }
            }

            private void updateCharacterCount() {
                int characterCount = ContentField.getText().length();
                // 원하는 위치에 텍스트 개수를 보여주는 JLabel 또는 다른 방법으로 표시하면 됩니다.
                if (characterCount > 400) {
                    characterCount = 400;
                }
                TextLabel.setText(characterCount + "/400");
            }

            @Override
            public void insertUpdate(DocumentEvent e) {
                updateCharacterCount();
                checkCharacterLimit();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                updateCharacterCount();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                updateCharacterCount();
            }
        });
        Contentpanel.add(ContentField);
        ContentField.setColumns(10);
        ContentField.setBorder(borderWhite);
        
        data.put("table", "comments");
        data.put("want", "CommentsID");
        Post po = new Post();
    	JSONObject SearchcommentsID1 = po.jsonpost("/find_post_id", data);
    	int SearchcommentsID = SearchcommentsID1.getInt("maxBulletinID");
        
        int newcommentsID = SearchcommentsID + 1;
        int Postnumber = Integer.parseInt(PostIDD);

        // 작성하기 버튼
        RoundedButton confirmButton = new RoundedButton("작성하기");
        confirmButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                String Content = ContentField.getText();
                Long currentDateTime = todayDate.TodayDate();

                data.put("CommentsID", newcommentsID);
                data.put("UserID", userIDD);
                data.put("Ccontent", Content);
                data.put("Cdate", currentDateTime);
                data.put("likes", 0);
                data.put("BulletinID", Postnumber);
				JSONObject change_check = po.jsonpost("/register_comments", data);
				boolean success = change_check.getBoolean("success"); 
				System.out.println("댓글 등록 성공 여부: " + success);
                
                showPost b = new showPost(userIDD, PostuserIDD, PostIDD, "일반", Section, DarK);
                b.showFrame();
                frame.dispose();
                dialogFrame.dispose();

            }
        });
        confirmButton.setBackground(new Color(255, 0, 0));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.setBounds(187, 350, 65, 25);
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }


    // 제한일
    private void LimitDialog(String UserID) {
    	JSONObject data = new JSONObject();
        collor colors = new collor();
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }

        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        Border borderBlack = BorderFactory.createLineBorder(colors.BoardPanel);
        
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(250, 320, 350, 220);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 326, 178);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(borderWhite); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel MyPostLabel = new JLabel("※이용 제한※");
        MyPostLabel.setBounds(100, 25, 200, 20);
        MyPostLabel.setForeground(new Color(100, 100, 100)); // 텍스트 색상(흰색)
        Font MyPostFont = new Font(MyPostLabel.getFont().getName(), Font.BOLD, 18);
        MyPostLabel.setFont(MyPostFont);
        dialogPanel.add(MyPostLabel);
        
        data.put("table", "users");
        data.put("want", "LimitDate");
        data.put("what", "UserID");
        data.put("user_id", UserID);
        Post po = new Post();
    	JSONObject LimitDate1 = po.jsonpost("/find_user_information", data);
    	long LimitDate = LimitDate1.getLong("LimitDate");

        long minute = LimitDate % 100;

        long Hour = (LimitDate % 10000) / 100;
    	
        long day = (LimitDate % 1000000) / 10000;

        long month = (LimitDate % 100000000) / 1000000;

        long year = LimitDate / 100000000;

        String dayLabel = year + "년 " + month + "월 " + day + "일" + Hour + "시" + minute +"분 까지";

        if (LimitDate != 0) {
            JLabel LimitLabel = new JLabel(dayLabel);
            LimitLabel.setBounds(75, 70, 200, 20);
            LimitLabel.setForeground(new Color(150, 100, 100)); // 텍스트 색상(흰색)
            Font LimitFont = new Font(LimitLabel.getFont().getName(), Font.BOLD, 14);
            LimitLabel.setFont(LimitFont);
            dialogPanel.add(LimitLabel);
        } else {
            JLabel LimitLabel = new JLabel("이용 제한 내역 없음");
            LimitLabel.setBounds(100, 70, 200, 20);
            LimitLabel.setForeground(new Color(100, 100, 150)); // 텍스트 색상(흰색)
            Font LimitFont = new Font(LimitLabel.getFont().getName(), Font.BOLD, 14);
            LimitLabel.setFont(LimitFont);
            dialogPanel.add(LimitLabel);
        }

        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("확인");
        confirmButton.setBounds(128, 140, 65, 20);
        confirmButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                dialogFrame.dispose();
            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }

    // 내용 수정
    private void NewPostDialog(String SearchUser) {
    	JSONObject data = new JSONObject();
        // 테두리 스타일 설정
        Border borderGray = BorderFactory.createLineBorder(new Color(240, 240, 240), 1);
        Border borderWhite = BorderFactory.createLineBorder(new Color(255, 255, 255), 2);
        Border borderBlack = BorderFactory.createLineBorder(new Color(0, 0, 0), 1);

        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(200, 273, 450, 500);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        // dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 100, 100);
        frame.getContentPane().add(dialogPanel);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(new Color(255, 255, 255)); // 배경색 설정
        dialogFrame.add(dialogPanel);

        // 변경 라벨
        JLabel ChangePWLabel = new JLabel("게시물 작성");
        ChangePWLabel.setBounds(180, 11, 150, 30); // Adjust the position and size as needed
        ChangePWLabel.setForeground(new Color(100, 100, 100)); // Set label text color
        Font ChangePWFont = new Font(ChangePWLabel.getFont().getName(), Font.BOLD, 14);
        ChangePWLabel.setFont(ChangePWFont);
        dialogPanel.add(ChangePWLabel);

        // 취소 버튼
        JButton BackButton = new JButton("취소"); // 버튼 생성 및 텍스트 설정
        BackButton.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                dialogFrame.dispose();
            }
        });
        BackButton.setBounds(382, 10, 60, 20); // 버튼 위치 및 크기 설정
        BackButton.setBackground(new Color(255, 255, 255));// 배경색 설정
        BackButton.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        dialogPanel.add(BackButton); // 패널에 버튼 추가
        Font memberbuttonFont = new Font(BackButton.getFont().getName(), Font.BOLD, 11);
        BackButton.setFont(memberbuttonFont);
        BackButton.setBorder(borderWhite); // 테두리 설정
        BackButton.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        BackButton.setContentAreaFilled(false);
        BackButton.setFocusPainted(false);
        BackButton.setOpaque(true);

        data.put("table", "bulletin");
        data.put("want", "BulletinTitle");
        data.put("what", "BulletinID");
        data.put("user_id", PostIDD);
        Post po =new Post();
		JSONObject SearchTitle1 = po.jsonpost("/find_user_information", data);
		String SearchTitle = SearchTitle1.getString("BulletinTitle");
        
        String lastFiveChars = "";
        String ShowTitle = "";
        if (SearchTitle.length() >= 5) {
            lastFiveChars = SearchTitle.substring(SearchTitle.length() - 5);
        } else {
            lastFiveChars = SearchTitle;
        }

        if (lastFiveChars.equals("(수정됨)")) {
            int endIndex = SearchTitle.length() - 6;
            ShowTitle = SearchTitle.substring(0, endIndex);
        } else {
            ShowTitle = SearchTitle;
        }
        
        data.put("table", "bulletin");
        data.put("want", "Bcontent");
        data.put("what", "BulletinID");
        data.put("user_id", PostIDD);
		JSONObject Searchcontent1 = po.jsonpost("/find_user_information", data);
		String Searchcontent = Searchcontent1.getString("Bcontent");
        
        String lastFiveChars2 = "";
        String ShowContent = "";
        if (Searchcontent.length() >= 5) {
            lastFiveChars2 = Searchcontent.substring(Searchcontent.length() - 5);
        } else {
            lastFiveChars2 = Searchcontent;
        }

        if (lastFiveChars2.equals("(수정됨)")) {
            int endIndex2 = Searchcontent.length() - 6;
            ShowContent = Searchcontent.substring(0, endIndex2);
        } else {
            ShowContent = Searchcontent;
        }

        // 제목 필드
        RoundtextField TitleField = new RoundtextField();
        TitleField.setBounds(50, 75, 340, 35);
        TitleField.setBackground(new Color(225, 225, 225));
        TitleField.setForeground(new Color(0, 0, 0));
        dialogPanel.add(TitleField);
        TitleField.setColumns(10);
        TitleField.setBorder(borderBlack);
        TitleField.setText(null);
        TitleField.setText(ShowTitle); // 기본 텍스트 설정

        // 내용페널
        JPanel Contentpanel = new JPanel();
        Contentpanel.setBackground(new Color(240, 240, 240));
        Contentpanel.setBounds(50, 130, 340, 250);
        dialogPanel.add(Contentpanel);
        Contentpanel.setLayout(null);
        Contentpanel.setBorder(borderGray); // 테두리 설정
        RoundedBorder roundedBorder = new RoundedBorder(20);
        Contentpanel.setBorder(roundedBorder);

        // 내용 필드
        JTextArea ContentField = new JTextArea();
        ContentField.setBounds(5, 5, 330, 240);
        ContentField.setBackground(new Color(240, 240, 240));
        ContentField.setForeground(new Color(0, 0, 0));
        ContentField.setLineWrap(true);
        ContentField.setWrapStyleWord(true);

        JLabel TextLabel = new JLabel("");
        Font TextFont = new Font(BackButton.getFont().getName(), Font.BOLD, 11);
        TextLabel.setFont(TextFont);
        dialogPanel.add(TextLabel);
        TextLabel.setBounds(340, 385, 100, 15);
        // DocumentListener를 사용하여 내용이 변경될 때마다 이벤트 처리
        ContentField.getDocument().addDocumentListener(new DocumentListener() {

            private void checkCharacterLimit() {
                if (ContentField.getText().length() > 400) {
                    String truncatedText = ContentField.getText().substring(0, 400);
                    ContentField.setText(truncatedText);
                }
            }

            private void updateCharacterCount() {
                int characterCount = ContentField.getText().length();
                // 원하는 위치에 텍스트 개수를 보여주는 JLabel 또는 다른 방법으로 표시하면 됩니다.
                if (characterCount > 400) {
                    characterCount = 400;
                }
                TextLabel.setText(characterCount + "/400");
            }

            @Override
            public void insertUpdate(DocumentEvent e) {
                updateCharacterCount();
                checkCharacterLimit();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                updateCharacterCount();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                updateCharacterCount();
            }
        });
        Contentpanel.add(ContentField);
        ContentField.setColumns(10);
        ContentField.setBorder(borderGray);
        ContentField.setText(ShowContent);

        // 작성하기 버튼
        RoundedButton confirmButton = new RoundedButton("수정하기");
        confirmButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                String Title = TitleField.getText();
                String Content = ContentField.getText();

                
                data.put("table", "bulletin");
                data.put("want", "BulletinTitle");
                data.put("what", "BulletinID");
                data.put("user_id", PostIDD);
        		JSONObject SearchTitle1 = po.jsonpost("/find_user_information", data);
        		String SearchTitle = SearchTitle1.getString("BulletinTitle");
        		
                String lastFiveChars = "";
                String ShowTitle = "";
                if (SearchTitle.length() >= 5) {
                    lastFiveChars = SearchTitle.substring(SearchTitle.length() - 5);
                } else {
                    lastFiveChars = SearchTitle;
                }

                if (lastFiveChars.equals("(수정됨)")) {
                    int endIndex = SearchTitle.length() - 6;
                    ShowTitle = SearchTitle.substring(0, endIndex);
                } else {
                    ShowTitle = SearchTitle;
                }
                
                data.put("table", "bulletin");
                data.put("want", "Bcontent");
                data.put("what", "BulletinID");
                data.put("user_id", PostIDD);
        		JSONObject Searchcontent1 = po.jsonpost("/find_user_information", data);
        		String Searchcontent = Searchcontent1.getString("Bcontent");
                
                String lastFiveChars2 = "";
                String ShowContent = "";
                if (Searchcontent.length() >= 5) {
                    lastFiveChars2 = Searchcontent.substring(Searchcontent.length() - 5);
                } else {
                    lastFiveChars2 = Searchcontent;
                }

                if (lastFiveChars2.equals("(수정됨)")) {
                    int endIndex2 = Searchcontent.length() - 6;
                    ShowContent = Searchcontent.substring(0, endIndex2);
                } else {
                    ShowContent = Searchcontent;
                }

                if (!ShowTitle.equals(Title)) {                
                    data.put("table", "bulletin");
                    data.put("this1", "BulletinID");
                    data.put("this2", PostIDD);
                    data.put("what", "BulletinTitle");
                    data.put("change", Title  + " (수정됨)");
                    Post po = new Post();
    				JSONObject change_check = po.jsonpost("/change_user", data);
    				boolean success = change_check.getBoolean("success"); 
    				System.out.println("제목 변경 성공 여부: " + success);
                
                }
                if (!ShowContent.equals(Content)) {                
                    data.put("table", "bulletin");
                    data.put("this1", "BulletinID");
                    data.put("this2", PostIDD);
                    data.put("what", "Bcontent");
                    data.put("change", Content  + " (수정됨)");
                    Post po = new Post();
    				JSONObject change_check = po.jsonpost("/change_user", data);
    				boolean success = change_check.getBoolean("success"); 
    				System.out.println("내용 변경 성공 여부: " + success);
                }
                showPost b = new showPost(userIDD, SearchUser, PostIDD, "일반", Section, DarK);
                b.showFrame();
                frame.dispose();
                dialogFrame.dispose();

            }
        });
        confirmButton.setBackground(new Color(255, 0, 0));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.setBounds(185, 400, 65, 25);
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }


    // 댓글 쓰기
    private void ComplaintDialog(String WHO, String Type, String TypeID) {
    	JSONObject data = new JSONObject();
        TodayDate todayDate = new TodayDate();
        collor colors = new collor();
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }

        // 테두리 스타일 설정
        Border borderGray = BorderFactory.createLineBorder(colors.BoardPanel, 1);
        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);

        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(200, 273, 450, 450);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        // dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 100, 100);
        frame.getContentPane().add(dialogPanel);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogFrame.add(dialogPanel);

        GetUsers getUsers = new GetUsers();
        List<List<String>> users = getUsers.getAllUsers(); // 유저 목록 조회

        Map<String, String> userMap = new HashMap<>();
        for (List<String> user : users) {
            String userID = user.get(0);  // 유저 ID
            String nickname = user.get(3); // 유저 닉네임 (인덱스 3에 닉네임이 있다고 가정)
            userMap.put(userID, nickname); // 유저ID와 닉네임을 맵에 저장
        }
        
        String PostuserNickname = userMap.get(WHO); 
        
        // 누구 신고 라벨
        JLabel complaintLabel = new JLabel(PostuserNickname + "님 신고");
        complaintLabel.setBounds(50, 15, 350, 30); // Adjust the position and size as needed
        complaintLabel.setForeground(colors.Text); // Set label text color
        Font ChangePWFont = new Font(complaintLabel.getFont().getName(), Font.BOLD, 14);
        complaintLabel.setFont(ChangePWFont);
        complaintLabel.setHorizontalAlignment(JLabel.CENTER);
        dialogPanel.add(complaintLabel);


        
        // 취소 버튼
        JButton BackButton = new JButton("취소"); // 버튼 생성 및 텍스트 설정
        BackButton.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                dialogFrame.dispose();
            }
        });
        BackButton.setBounds(380, 10, 60, 20); // 버튼 위치 및 크기 설정
        BackButton.setBackground(colors.Ground);// 배경색 설정
        BackButton.setForeground(colors.Text); // 텍스트 색상(흰색)
        dialogPanel.add(BackButton); // 패널에 버튼 추가
        Font memberbuttonFont = new Font(BackButton.getFont().getName(), Font.BOLD, 11);
        BackButton.setFont(memberbuttonFont);
        BackButton.setBorder(borderWhite); // 테두리 설정
        BackButton.setContentAreaFilled(false);
        BackButton.setFocusPainted(false);
        BackButton.setOpaque(true);

        
        // 변경 라벨
        JLabel reasonLabel = new JLabel("신고사유를 자세히 적어주세요");
        reasonLabel.setBounds(50, 60, 150, 15); // Adjust the position and size as needed
        reasonLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        Font reasonLabelFont = new Font(reasonLabel.getFont().getName(), Font.BOLD, 9);
        reasonLabel.setFont(reasonLabelFont);
        dialogPanel.add(reasonLabel);
        
        
        // 내용페널
        JPanel Contentpanel = new JPanel();
        Contentpanel.setBackground(colors.Ground);
        Contentpanel.setBounds(50, 75, 340, 250);
        dialogPanel.add(Contentpanel);
        Contentpanel.setLayout(null);
        Contentpanel.setBorder(borderGray); // 테두리 설정
        RoundedBorder roundedBorder = new RoundedBorder(20);
        Contentpanel.setBorder(roundedBorder);

        // 내용 필드
        JTextArea ContentField = new JTextArea();
        ContentField.setBounds(5, 5, 330, 240);
        ContentField.setBackground(colors.Ground);
        ContentField.setForeground(colors.Text);
        ContentField.setLineWrap(true);
        ContentField.setWrapStyleWord(true);

        JLabel TextLabel = new JLabel("");
        Font TextFont = new Font(BackButton.getFont().getName(), Font.BOLD, 11);
        TextLabel.setFont(TextFont);
        dialogPanel.add(TextLabel);
        TextLabel.setBounds(340, 310, 100, 15);
        // DocumentListener를 사용하여 내용이 변경될 때마다 이벤트 처리
        ContentField.getDocument().addDocumentListener(new DocumentListener() {

            private void checkCharacterLimit() {
                if (ContentField.getText().length() > 400) {
                    String truncatedText = ContentField.getText().substring(0, 400);
                    ContentField.setText(truncatedText);
                }
            }

            private void updateCharacterCount() {
                int characterCount = ContentField.getText().length();
                // 원하는 위치에 텍스트 개수를 보여주는 JLabel 또는 다른 방법으로 표시하면 됩니다.
                if (characterCount > 400) {
                    characterCount = 400;
                }
                TextLabel.setText(characterCount + "/400");
            }

            @Override
            public void insertUpdate(DocumentEvent e) {
                updateCharacterCount();
                checkCharacterLimit();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                updateCharacterCount();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                updateCharacterCount();
            }
        });
        Contentpanel.add(ContentField);
        ContentField.setColumns(10);
        ContentField.setBorder(borderWhite);
        

        // 작성하기 버튼
        RoundedButton confirmButton = new RoundedButton("신고하기");
        confirmButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                String Content = ContentField.getText();
                Long currentDateTime = todayDate.TodayDate();

                data.put("UserID", userIDD);
                data.put("ReportedID", WHO);
                data.put("type", Type);
                data.put("problemID", TypeID);
                data.put("content", Content);
                data.put("checking", 0);
                data.put("date", currentDateTime);

                Post po = new Post();

				JSONObject change_check = po.jsonpost("/request_Complaint", data);
				boolean success = change_check.getBoolean("success"); 
				System.out.println("신고 성공 여부: " + success);
                
                dialogFrame.dispose();

            }
        });
        confirmButton.setBackground(new Color(255, 0, 0));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.setBounds(187, 350, 65, 25);
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }


    
    public void showFrame() {
        frame.setVisible(true);
    }
}
