package main.java.com.pws.Schedule;

import javax.swing.*;
import javax.swing.border.Border;

import org.json.JSONObject;


import main.java.com.pws.Thing.FrameManager;
import main.java.com.pws.Thing.GetLecture;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.RoundtextField;
import main.java.com.pws.Thing.collor;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.List;

public class AddLecture {
    private String userIDD;
    private String maxLectureID = ""; // 초기화
    private String GetInstructorID = ""; // 초기화
    private String LectureID = "";
	private String Section;
	private String Frame;
	private int DarK;


    private int CheckLectureName = 0;
    private int CheckInstructor = 0;
    private int CheckRoomNumber = 0;
    private int CheckSection = 0;

    public AddLecture(String userIDD, String Section, String Frame, int DarK) {
        this.userIDD = userIDD;
        this.Section = Section;
        this.Frame = Frame;
        this.DarK = DarK;

        initialize();
    }

    private void initialize() {
        JSONObject data = new JSONObject();
        Post po = new Post();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }


        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        Border borderBlack = BorderFactory.createLineBorder(colors.BoardPanel, 1);
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(200, 240, 450, 570);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    	FrameManager.addFrame(dialogFrame);
        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setBounds(5, 0, 100, 100);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogFrame.add(dialogPanel);

        // 작성자 정보 라벨
        JLabel ChangePWLabel = new JLabel("강의 추가");
        ChangePWLabel.setBounds(150, 11, 150, 30); // Adjust the position and size as needed
        ChangePWLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        Font ChangePWFont = new Font(ChangePWLabel.getFont().getName(), Font.BOLD, 20);
        ChangePWLabel.setFont(ChangePWFont);
        ChangePWLabel.setHorizontalAlignment(JLabel.CENTER);
        dialogPanel.add(ChangePWLabel);
        
        JCheckBox LectureCheck = new JCheckBox("전공");
        LectureCheck.setForeground(colors.Text); // Set label text color
        Font labelFont2 = new Font(LectureCheck.getFont().getName(), Font.BOLD, 9);
        LectureCheck.setFont(labelFont2);
        LectureCheck.setBounds(298, 50, 100, 25);
        LectureCheck.setBackground(colors.Ground);
        LectureCheck.setHorizontalAlignment(JLabel.CENTER);
        dialogPanel.add(LectureCheck);

        int[] lecturea = {0};  // 변수의 값이 변경될 수 있으므로 배열로 선언
        // ItemListener 추가
        LectureCheck.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    lecturea[0] = 1;  // 체크되면 1 저장
                } else {
                    lecturea[0] = 0;  // 체크 해제되면 0 저장
                }
                System.out.println("LectureCheck 상태: " + lecturea[0]);
            }
        });
        String lecture = Integer.toString(lecturea[0]);

        data.put("table", "users");
        data.put("want", "UID");
        data.put("what", "UserID");
        data.put("user_id", userIDD);
        JSONObject SearchUID1 = po.jsonpost("/find_user_information", data);
        String SearchUID = SearchUID1.getString("UID");
		String cutuniversity = SearchUID.substring(0, SearchUID.length() - 2);

	     // 학교아이디 라벨
        JLabel LectureNameLabel = new JLabel("과목이름");
        LectureNameLabel.setBounds(125, 60, 150, 15); // Adjust the position and size as needed
        LectureNameLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        LectureNameLabel.setFont(labelFont2);
        dialogPanel.add(LectureNameLabel);
        // 학교 아이디 입력 필드
        RoundtextField LectureNameField = new RoundtextField();
        LectureNameField.setBounds(120, 75, 200, 35);
        LectureNameField.setBackground(colors.BoardPanel);
        LectureNameField.setForeground(colors.Text);
        dialogPanel.add(LectureNameField);
        LectureNameField.setColumns(10);
        LectureNameField.setBorder(borderBlack);
        LectureNameField.setDefaultText("  ex) 진로코칭3");

        JLabel LectureNameOKLabel = new JLabel("");
        LectureNameOKLabel.setForeground(new Color(100, 100, 150)); // Set label text color
        LectureNameOKLabel.setFont(labelFont2);
        LectureNameOKLabel.setBounds(150, 113, 150, 15);
        LectureNameOKLabel.setHorizontalAlignment(JLabel.CENTER);
        dialogPanel.add(LectureNameOKLabel);

        // 학교 검색 버튼 (원래 중복 확인 기능은 여기에 넣어도 됨)
        RoundedButton searchButton = new RoundedButton("중복확인");
        searchButton.setBounds(319, 82, 50, 20);
        searchButton.setBackground(colors.BoardPanel);// 배경색 설정 (빨간색)
        searchButton.setForeground(colors.Ground); // 텍스트 색상(흰색)
        Font searchFont = new Font(searchButton.getFont().getName(), Font.PLAIN, 10);
        searchButton.setFont(searchFont);
        dialogPanel.add(searchButton); // 패널에 버튼 추가
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String NewLectureName = LectureNameField.getText();
                // 여기서 데이터베이스 조회하여 중복 여부 확인
                data.put("where", "lecture_name");
                data.put("what", NewLectureName);
                Post po = new Post();
				JSONObject nickDuplicate = po.jsonpost("/check_Lecture_exists", data);
				boolean nickDuplicate1;
				nickDuplicate1 = nickDuplicate.getBoolean("exists");
				
                if (nickDuplicate1) {
                    LectureNameOKLabel.setText("이미 개설된 강의 입니다.");
                    LectureNameOKLabel.setForeground(new Color(150, 100, 100));
                    CheckLectureName = 0;
                } else {
                	LectureNameOKLabel.setText("개설가능한 강의 입니다.");
                    LectureNameOKLabel.setForeground(new Color(100, 100, 150));
                    CheckLectureName = 1;
                }
            }
        });
            

        // 교수ID 라벨
        JLabel InstructorLabel = new JLabel("교수ID");
        InstructorLabel.setBounds(125, 125, 30, 15); // Adjust the position and size as needed
        InstructorLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        InstructorLabel.setFont(labelFont2);
        dialogPanel.add(InstructorLabel);

        // 교수ID 입력 필드
        RoundtextField InstructorField = new RoundtextField();
        InstructorField.setBounds(120, 140, 200, 35);
        InstructorField.setBackground(colors.BoardPanel);
        InstructorField.setForeground(colors.Text);
        dialogPanel.add(InstructorField);
        InstructorField.setColumns(10);
        InstructorField.setBorder(borderBlack);
        InstructorField.setDefaultText("  ex) "+cutuniversity+"01");
        
        JLabel InstructorOKLabel = new JLabel("");
        InstructorOKLabel.setForeground(new Color(100, 100, 150)); // Set label text color
        InstructorOKLabel.setFont(labelFont2);
        InstructorOKLabel.setBounds(145, 178, 150, 15);
        InstructorOKLabel.setHorizontalAlignment(JLabel.CENTER);
        dialogPanel.add(InstructorOKLabel);
        
        JCheckBox InstructorSearchModeCheck = new JCheckBox("이름");
        InstructorSearchModeCheck.setForeground(new Color(120, 120, 120)); // Set label text color
        Font SearchModeFont = new Font(searchButton.getFont().getName(), Font.PLAIN, 8);
        InstructorSearchModeCheck.setFont(SearchModeFont);
        InstructorSearchModeCheck.setBounds(353, 151, 42, 15);
        InstructorSearchModeCheck.setBackground(colors.Ground);
        InstructorSearchModeCheck.setHorizontalAlignment(JLabel.CENTER);
        dialogPanel.add(InstructorSearchModeCheck);
        
        int[] ModeCheck = {0};  // 변수의 값이 변경될 수 있으므로 배열로 선언
        // ItemListener 추가
        InstructorSearchModeCheck.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                	ModeCheck[0] = 1;  // 체크되면 1 저장
                } else {
                	ModeCheck[0] = 0;  // 체크 해제되면 0 저장
                }
                System.out.println("ModeCheck 상태: " + ModeCheck[0]);
            }
        });
        
        // 교수 검색 버튼 (원래 중복 확인 기능은 여기에 넣어도 됨)
        RoundedButton search2Button = new RoundedButton("검색");
        search2Button.setBounds(319, 147, 30, 20);
        search2Button.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        search2Button.setForeground(colors.Text); // 텍스트 색상(흰색)
        search2Button.setFont(searchFont);
        dialogPanel.add(search2Button); // 패널에 버튼 추가
        
        //강의 아이디
        JLabel LectureOKLabel = new JLabel("");
        LectureOKLabel.setForeground(new Color(100, 100, 150)); // Set label text color
        Font labelFont5 = new Font(LectureOKLabel.getFont().getName(), Font.BOLD, 14);
        LectureOKLabel.setFont(labelFont5);
        LectureOKLabel.setBounds(170, 50, 110, 15);
        LectureOKLabel.setHorizontalAlignment(JLabel.CENTER);
        dialogPanel.add(LectureOKLabel);
        
        
        search2Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	String TextField = InstructorField.getText();
            	String[] GetInstructorName = {TextField};
                String[] getInstructorID = {TextField};

                if(ModeCheck[0]==0) {
                    data.put("table", "instructor");
                    data.put("want", "name");
                    data.put("what", "instructor_id");
                    data.put("user_id", getInstructorID[0]);
                    JSONObject GetInstructorName1 = po.jsonpost("/find_user_information", data);
                    GetInstructorName[0] = GetInstructorName1.getString("name");
                } else if (ModeCheck[0]==1){
                    data.put("table", "instructor");
                    data.put("want", "instructor_id");
                    data.put("what", "name");
                    data.put("user_id", getInstructorID[0]);
                    JSONObject GetInstructorID1 = po.jsonpost("/find_user_information", data);
                    getInstructorID[0] = GetInstructorID1.getString("instructor_id");
                }
                GetInstructorID = getInstructorID[0];

                if (GetInstructorName[0].equals("없음") || getInstructorID[0].equals("없음")) {
                	InstructorOKLabel.setText("교수 정보를 찾을 수 없습니다.");
                	InstructorOKLabel.setForeground(new Color(150, 100, 100));
                	CheckInstructor = 0;
                } else {
                    data.put("table", "instructor");
                    data.put("want", "UID");
                    data.put("what", "instructor_id");
                    data.put("user_id", getInstructorID[0]);
                    JSONObject GetInstructorUID1 = po.jsonpost("/find_user_information", data);
                    String GetInstructorUID = GetInstructorUID1.getString("UID");
                    String GetInstructorDept = GetInstructorUID.substring(3, GetInstructorUID.length() - 0);
                    
                    GetLecture  getLecture  = new GetLecture ();
                    List<List<String>> Lectures = getLecture.GetLecture();
                	maxLectureID = GetInstructorDept + "001";

                    int maxLectureOrder = 0; 
                    Lectures.size();
                    for(int a = 0; a<Lectures.size() ; a++) {
            	    	List<String> Lecture = Lectures.get(a);
            	        String lectureID = Lecture.get(1);
                        // 전공 번호 추출 (2~3자리)
            	        String majorCode = lectureID.substring(1, 3);

                        // 강의 순번 추출 (4~6자리)
                        int lectureOrder =  Integer.parseInt(lectureID.substring(3));

                        if (majorCode.equals(GetInstructorDept)) {
                            // 현재까지 저장된 maxLectureID의 순번과 비교하여 더 큰 순번을 가진 강의 ID를 저장
                        	if (lectureOrder > maxLectureOrder) {
                        		maxLectureOrder = lectureOrder; 
                        		maxLectureID= lectureID.substring(1, 3) + String.format("%03d", lectureOrder + 1); // +1 한 값으로 새 ID 생성
                        	}
                        }
                    }
            		
                    LectureID= Integer.toString(lecturea[0]) + maxLectureID;
            		System.out.println("저장 된 아이디: " + LectureID);

                	LectureOKLabel.setText(LectureID);
                	
                	InstructorOKLabel.setText(GetInstructorName[0]);
                	InstructorOKLabel.setForeground(new Color(100, 100, 150));
                    CheckInstructor = 1;
                }
            }
        });
        
        
        // 강의실ID 라벨
        JLabel RoomIDLabel = new JLabel("강의실ID");
        RoomIDLabel.setBounds(125, 190, 150, 15); // Adjust the position and size as needed
        RoomIDLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        RoomIDLabel.setFont(labelFont2);
        dialogPanel.add(RoomIDLabel);
        
        // 강의실ID 입력 필드
        RoundtextField RoomIDField = new RoundtextField();
        RoomIDField.setBounds(120, 205, 200, 35);
        RoomIDField.setBackground(colors.BoardPanel);
        RoomIDField.setForeground(colors.Text);
        dialogPanel.add(RoomIDField);
        RoomIDField.setColumns(10);
        RoomIDField.setBorder(borderBlack);
        RoomIDField.setDefaultText("  ex) "+cutuniversity+"001");
        
        JLabel RoomIDOKLabel = new JLabel("");
        RoomIDOKLabel.setForeground(new Color(100, 100, 150)); // Set label text color
        RoomIDOKLabel.setFont(labelFont2);
        RoomIDOKLabel.setBounds(145, 243, 150, 15);
        RoomIDOKLabel.setHorizontalAlignment(JLabel.CENTER);
        dialogPanel.add(RoomIDOKLabel);
        
        // 강의실 검색 버튼 (원래 중복 확인 기능은 여기에 넣어도 됨)
        RoundedButton search3Button = new RoundedButton("검색");
        search3Button.setBounds(319, 212, 30, 20);
        search3Button.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        search3Button.setForeground(colors.Text); // 텍스트 색상(흰색)
        search3Button.setFont(searchFont);
        dialogPanel.add(search3Button); // 패널에 버튼 추가
        search3Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String getRoomIDID = RoomIDField.getText();
                // 여기서 데이터베이스 조회하여 중복 여부 확인
                data.put("table", "class_room");
                data.put("want", "building");
                data.put("what", "room_id");
                data.put("user_id", getRoomIDID);
                JSONObject GetBuilding1 = po.jsonpost("/find_user_information", data);
                String GetBuilding = GetBuilding1.getString("building");
				
                if (GetBuilding.equals("없음")) {
                	RoomIDOKLabel.setText("강의실 정보를 찾을 수 없습니다.");
                	RoomIDOKLabel.setForeground(new Color(150, 100, 100));
                	CheckRoomNumber = 0;
                } else {
                    data.put("want", "room_number");
                    JSONObject GetRoomNumber1 = po.jsonpost("/find_user_information", data);
                    String GetRoomNumber = GetRoomNumber1.getString("room_number");
                	RoomIDOKLabel.setText(GetBuilding+" "+GetRoomNumber);
                	RoomIDOKLabel.setForeground(new Color(100, 100, 150));
                    CheckRoomNumber = 1;
                }
            }
        });
        

        
        // 학기ID 라벨
        JLabel SectionLabel = new JLabel("학기ID");
        SectionLabel.setBounds(125, 255, 150, 15); // Adjust the position and size as needed
        SectionLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        SectionLabel.setFont(labelFont2);
        dialogPanel.add(SectionLabel);
        
        // 학기ID 입력 필드
        RoundtextField SectionField = new RoundtextField();
        SectionField.setBounds(120, 270, 200, 35);
        SectionField.setBackground(colors.BoardPanel);
        SectionField.setForeground(colors.Text);
        dialogPanel.add(SectionField);
        SectionField.setColumns(10);
        SectionField.setBorder(borderBlack);
        SectionField.setDefaultText("  ex) 20243");
        
        JLabel SectionOKLabel = new JLabel("");
        SectionOKLabel.setForeground(new Color(100, 100, 150)); // Set label text color
        SectionOKLabel.setFont(labelFont2);
        SectionOKLabel.setBounds(100, 308, 250, 15);
        SectionOKLabel.setHorizontalAlignment(JLabel.CENTER);
        dialogPanel.add(SectionOKLabel);
        
        // 학기ID 검색 버튼 (원래 중복 확인 기능은 여기에 넣어도 됨)
        RoundedButton search4Button = new RoundedButton("검색");
        search4Button.setBounds(319, 277, 30, 20);
        search4Button.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        search4Button.setForeground(colors.Text); // 텍스트 색상(흰색)
        search4Button.setFont(searchFont);
        dialogPanel.add(search4Button); // 패널에 버튼 추가
        search4Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String getSectionID = SectionField.getText();
                // 여기서 데이터베이스 조회하여 중복 여부 확인
                data.put("table", "section");
                data.put("want", "start_section");
                data.put("what", "section_id");
                data.put("user_id", getSectionID);
                JSONObject GetStartSection1 = po.jsonpost("/find_user_information", data);
                String GetStartSection = GetStartSection1.getString("start_section");
                data.put("want", "end_section");
                JSONObject GetEndSectionr1 = po.jsonpost("/find_user_information", data);
                String GetEndSectionr = GetEndSectionr1.getString("end_section");
                

                if (GetStartSection.equals("없음")) {
                	SectionOKLabel.setText("학기 정보를 찾을 수 없습니다.");
                	SectionOKLabel.setForeground(new Color(150, 100, 100));
                	CheckSection = 0;
                } else {
                	SectionOKLabel.setText(GetStartSection+"~"+GetEndSectionr);
                	SectionOKLabel.setForeground(new Color(100, 100, 150));
                	CheckSection = 1;
                }
            }
        });
        
        // 학점 라벨
        JLabel GradeLabel = new JLabel("학점");
        GradeLabel.setBounds(125, 320, 150, 15); // Adjust the position and size as needed
        GradeLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        GradeLabel.setFont(labelFont2);
        dialogPanel.add(GradeLabel);
        
        // 학점 입력 필드
        RoundtextField GradeField = new RoundtextField();
        GradeField.setBounds(120, 335, 200, 35);
        GradeField.setBackground(colors.BoardPanel);
        GradeField.setForeground(colors.Text);
        dialogPanel.add(GradeField);
        GradeField.setColumns(10);
        GradeField.setBorder(borderBlack);
        GradeField.setDefaultText("  ex) 3");    
        
        
        // 강의시간 라벨
        JLabel TimeLabel = new JLabel("강의시간");
        TimeLabel.setBounds(125, 375, 150, 15); // Adjust the position and size as needed
        TimeLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        TimeLabel.setFont(labelFont2);
        dialogPanel.add(TimeLabel);
        
        // 강의 시작시간 입력 필드
        RoundtextField StartField = new RoundtextField();
        StartField.setBounds(120, 390, 80, 35);
        StartField.setBackground(colors.BoardPanel);
        StartField.setForeground(colors.Text);
        dialogPanel.add(StartField);
        StartField.setColumns(10);
        StartField.setBorder(borderBlack);
        StartField.setDefaultText("  ex) 월09");
        
        // 강의시간 라벨
        JLabel Start2Label = new JLabel("부터");
        Start2Label.setBounds(205, 402, 50, 15); // Adjust the position and size as needed
        Start2Label.setForeground(new Color(120, 120, 120)); // Set label text color
        Start2Label.setFont(labelFont2);
        dialogPanel.add(Start2Label);
        
        // 강의 종료시간 입력 필드
        RoundtextField EndField = new RoundtextField();
        EndField.setBounds(240, 390, 80, 35);
        EndField.setBackground(colors.BoardPanel);
        EndField.setForeground(colors.Text);
        dialogPanel.add(EndField);
        EndField.setColumns(10);
        EndField.setBorder(borderBlack);
        EndField.setDefaultText("  ex) 월13");
        
        // 종료시간 라벨
        JLabel End2Label = new JLabel("까지");
        End2Label.setBounds(325, 402, 50, 15); // Adjust the position and size as needed
        End2Label.setForeground(new Color(120, 120, 120)); // Set label text color
        End2Label.setFont(labelFont2);
        dialogPanel.add(End2Label);
        
        int[] dateWhat = {0};
        String[] PM = {"✚"};
        // 학기ID 검색 버튼 (원래 중복 확인 기능은 여기에 넣어도 됨)
        RoundedButton PlusButton = new RoundedButton(PM[0]);
        PlusButton.setBounds(90, 438, 20, 20);
        PlusButton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        PlusButton.setForeground(colors.Text); // 텍스트 색상(흰색)
        PlusButton.setFont(searchFont);
        dialogPanel.add(PlusButton); // 패널에 버튼 추가

        // 필드와 라벨을 변수로 선언해 밖에서 접근 가능하게 함
        RoundtextField Starta2Field = new RoundtextField();
        JLabel Starta2Label = new JLabel("부터");
        RoundtextField EndaField = new RoundtextField();
        JLabel Enda2Label = new JLabel("까지");

        PlusButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (dateWhat[0] == 0) {
                    // 필드와 라벨을 추가
                    Starta2Field.setBounds(120, 432, 80, 35);
                    Starta2Field.setBackground(colors.BoardPanel);
                    Starta2Field.setForeground(colors.Text);
                    Starta2Field.setColumns(10);
                    Starta2Field.setBorder(borderBlack);
                    Starta2Field.setDefaultText("  ex) 화09");
                    dialogPanel.add(Starta2Field);

                    Starta2Label.setBounds(205, 444, 50, 15); 
                    Starta2Label.setForeground(new Color(120, 120, 120)); 
                    Starta2Label.setFont(labelFont2);
                    dialogPanel.add(Starta2Label);

                    EndaField.setBounds(240, 432, 80, 35);
                    EndaField.setBackground(colors.BoardPanel);
                    EndaField.setForeground(colors.Text);
                    EndaField.setColumns(10);
                    EndaField.setBorder(borderBlack);
                    EndaField.setDefaultText("  ex) 화13");
                    dialogPanel.add(EndaField);

                    Enda2Label.setBounds(325, 444, 50, 15);
                    Enda2Label.setForeground(new Color(120, 120, 120)); 
                    Enda2Label.setFont(labelFont2);
                    dialogPanel.add(Enda2Label);

                    // 버튼 텍스트 변경
                    PlusButton.setText("⚊");
                    dateWhat[0] = 1;
                } else if (dateWhat[0] == 1) {
                    // 필드와 라벨을 제거
                    dialogPanel.remove(Starta2Field);
                    dialogPanel.remove(Starta2Label);
                    dialogPanel.remove(EndaField);
                    dialogPanel.remove(Enda2Label);

                    // 버튼 텍스트를 "+"로 변경
                    PlusButton.setText("✚");
                    dateWhat[0] = 0;
                }

                // 패널 갱신
                dialogPanel.revalidate();
                dialogPanel.repaint();
            }
        });

        
        
        //  버튼
        RoundedButton OKButton = new RoundedButton("추가");
        OKButton.setBounds(188, 475, 65, 20);
        OKButton.setBackground(new Color(255, 0, 0));// 배경색 설정 (빨간색)
        OKButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        dialogPanel.add(OKButton); // 패널에 버튼 추가

        JLabel OKLabel = new JLabel("");
        OKLabel.setFont(labelFont2);
        OKLabel.setBounds(100, 500, 250, 15);
        OKLabel.setHorizontalAlignment(JLabel.CENTER);
        dialogPanel.add(OKLabel);

        // 회원가입 버튼에 ActionListener 추가
        OKButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String NewLectureID = LectureID;

                String LectureName = LectureNameField.getText();
                String Instructor = GetInstructorID;
                String RoomID = RoomIDField.getText();
                
                String Section = SectionField.getText();
                String Grade = GradeField.getText();
                
                String Start = StartField.getText();
                String End = EndField.getText();
                String Start2 = Starta2Field.getText();
                String End2 = EndaField.getText();

                // 에러 메시지 라벨 초기화
                OKLabel.setText("");
                if(CheckLectureName ==0) {
                	OKLabel.setText("과목이름 입력칸을 다시 확인해 주세요");
                } else if(CheckInstructor == 0) {
                	OKLabel.setText("교수 입력칸을 다시 확인해 주세요");
                } else if(CheckRoomNumber == 0) {
                	OKLabel.setText("강의실 입력칸을 다시 확인해 주세요");
                } else if(CheckSection == 0) {
                	OKLabel.setText("학기 입력칸을 다시 확인해 주세요");
                } else if(Grade.equals("  ex) 3")){
                	OKLabel.setText("학점 입력칸을 다시 확인해 주세요");
                } else if(Start.equals("  ex) 월09") || End.equals("  ex) 월13")){
                	OKLabel.setText("학점 입력칸을 다시 확인해 주세요");
                } else {
                	if(dateWhat[0]==0) {
        				System.out.println("강의실ID: " + RoomID);
        				System.out.println("강의ID: " + NewLectureID);
        				System.out.println("강의시작: " + Start);
        				System.out.println("강의종료: " + End);
        				System.out.println("강의이름: " + LectureName);
        				System.out.println("학점: " + Grade);
        				System.out.println("교수ID: " + Instructor);
        				System.out.println("학기ID: " + Section);


                		
                		
                        data.put("room_id", RoomID);
                        data.put("lecture_id", NewLectureID);
                        data.put("start_time", Start);
                        data.put("end_time", End);
                        data.put("lecture_name", LectureName);
                        data.put("grade", Grade);
                        data.put("instructor_id", Instructor);
                        data.put("section_id", Section);
        				JSONObject change_check = po.jsonpost("/register_Lecture", data);
        				boolean success = change_check.getBoolean("success"); 
        				System.out.println("강의추가 성공 여부: " + success);
                        // 회원가입 성공 다이얼로그 표시
                        showSuccessDialog();
                		
                	}else {
                		if(Start2.equals("  ex) 화09") || End2.equals("  ex) 화13")) {
                        	OKLabel.setText("학점 입력칸을 다시 확인해 주세요");
                		} else {
                            data.put("room_id", RoomID);
                            data.put("lecture_id", NewLectureID);
                            data.put("start_time", Start);
                            data.put("end_time", End);
                            data.put("lecture_name", LectureName);
                            data.put("grade", Grade);
                            data.put("instructor_id", Instructor);
                            data.put("section_id", Section);
            				JSONObject change_check = po.jsonpost("/register_Lecture", data);
            				boolean success = change_check.getBoolean("success"); 
            				System.out.println("강의추가 성공 여부1: " + success);
                			
                            data.put("room_id", RoomID);
                            data.put("lecture_id", NewLectureID);
                            data.put("start_time", Start2);
                            data.put("end_time", End2);
                            data.put("lecture_name", LectureName);
                            data.put("grade", Grade);
                            data.put("instructor_id", Instructor);
                            data.put("section_id", Section);
            				JSONObject change_check2 = po.jsonpost("/register_Lecture", data);
            				boolean success2 = change_check2.getBoolean("success"); 
            				System.out.println("강의추가 성공 여부2: " + success2);
                            // 회원가입 성공 다이얼로그 표시
                            showSuccessDialog();
                			
                		}
                	}
                }     
            }
        });
        
        
        
        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
  
    private void showSuccessDialog() {
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(31, 31, 31);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(70, 70, 70);
            colors.buttonBackground = new Color(50, 50, 50);
            colors.postbuttonColor = new Color(40, 40, 40);
            colors.RedText = new Color(200, 100, 100);
        }

        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(270, 400, 300, 150);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null); 

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 276, 110);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(borderWhite); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel dialogLabel = new JLabel("추가 성공!");
        dialogLabel.setBounds(115, 30, 200, 35);
        dialogLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
        dialogPanel.add(dialogLabel);
        
        String[] SearchLectures = {"없음"};

        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("확인");
        confirmButton.setBounds(110, 80, 65, 20);
        confirmButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialogFrame.dispose();
                FrameManager.closeAllFrames(); // 모든 프레임 닫기
            	LectureList adminlecture = new LectureList(userIDD, SearchLectures, Section, Frame, DarK);
            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
}
