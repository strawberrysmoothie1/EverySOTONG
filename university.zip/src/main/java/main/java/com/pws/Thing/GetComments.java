package main.java.com.pws.Thing;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GetComments {

    public List<List<String>> getAllComments() {
        List<List<String>> comments = new ArrayList<>();
        HttpURLConnection connection = null;

        try {
            String apiURL = "http://127.0.0.1:5000/get_all_comments";
            URL link = new URL(apiURL);
            connection = (HttpURLConnection) link.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");

            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"))) {
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    String returnMsg = response.toString();
                    System.out.println("서버 응답: " + returnMsg); // 서버 응답 출력

                    if (!returnMsg.trim().isEmpty()) {
                        JSONObject jsonResponse = new JSONObject(returnMsg);
                        JSONArray commentArray = jsonResponse.getJSONArray("comments");
                        for (int i = 0; i < commentArray.length(); i++) {
                            JSONObject comment = commentArray.getJSONObject(i);
                            List<String> commentData = new ArrayList<>();
                            commentData.add(String.valueOf(comment.getInt("CommentsID")));
                            commentData.add(comment.getString("UserID"));
                            commentData.add(comment.getString("Ccontent"));
                            commentData.add(comment.getString("Cdate"));
                            commentData.add(comment.getString("likes"));
                            commentData.add(String.valueOf(comment.getInt("BulletinID"))); // 정수를 문자열로 변환하여 추가


                            comments.add(commentData);
                        }
                    } else {
                        System.out.println("서버 응답이 비어있습니다.");
                    }
                }
            } else {
                System.out.println("HTTP 응답 코드: " + responseCode);
            }

        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }

        return comments;
    }

}
