package main.java.com.pws.dialog;

import javax.swing.*;
import javax.swing.border.Border;

import org.json.JSONObject;

import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.collor;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UserInfo {
    private String userIDD;
    private String PostIDD;
    private int DarK;

    
    public UserInfo(String userIDD, String PostIDD, int DarK) {
        this.userIDD = userIDD;
        this.PostIDD = PostIDD;
        this.DarK = DarK;

        initialize();
    }

    private void initialize() {
        JSONObject data = new JSONObject();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }


        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);

        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(275, 350, 300, 350);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setBounds(5, 0, 100, 100);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogFrame.add(dialogPanel);

        // 작성자 정보 라벨
        JLabel ChangePWLabel = new JLabel("작성자 정보");
        ChangePWLabel.setBounds(105, 11, 150, 30); // Adjust the position and size as needed
        ChangePWLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        Font ChangePWFont = new Font(ChangePWLabel.getFont().getName(), Font.BOLD, 14);
        ChangePWLabel.setFont(ChangePWFont);
        dialogPanel.add(ChangePWLabel);

        // 취소 버튼
        JButton BackButton = new JButton("취소"); // 버튼 생성 및 텍스트 설정
        BackButton.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                dialogFrame.dispose();
            }
        });
        BackButton.setBounds(275, 10, 60, 20); // 버튼 위치 및 크기 설정
        BackButton.setBackground(colors.Ground);// 배경색 설정
        BackButton.setForeground(colors.Text); // 텍스트 색상(흰색)
        dialogPanel.add(BackButton); // 패널에 버튼 추가
        Font memberbuttonFont = new Font(BackButton.getFont().getName(), Font.BOLD, 11);
        BackButton.setFont(memberbuttonFont);
        BackButton.setBorder(borderWhite); // 테두리 설정
        BackButton.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        BackButton.setContentAreaFilled(false);
        BackButton.setFocusPainted(false);
        BackButton.setOpaque(true);

        // 데이터베이스 조회 및 라벨 설정
        fetchAndSetData(data, dialogPanel);

        // 이미지 유저
        ImageIcon useroriginalImageIcon = new ImageIcon("src/img/user.png");
        Image useroriginalImage = useroriginalImageIcon.getImage();
        Image userscaledImage = useroriginalImage.getScaledInstance(60, 60, Image.SCALE_SMOOTH);
        ImageIcon userscaledImageIcon = new ImageIcon(userscaledImage);
        JLabel userimageLabel = new JLabel(userscaledImageIcon);
        userimageLabel.setBounds(110, 70, 60, 60);
        dialogPanel.add(userimageLabel);

        if (userIDD.equals("admin")) {
            RoundedButton LimitButton = new RoundedButton("제한");
            LimitButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	UserLimit userLimit = new UserLimit(userIDD, PostIDD, DarK);

                    dialogFrame.dispose();
                }
            });
            LimitButton.setBackground(colors.Text); // 배경색 설정 (검은색)
            LimitButton.setForeground(colors.Ground); // 텍스트 색상(흰색)
            LimitButton.setBounds(225, 17, 45, 18);
            dialogPanel.add(LimitButton);
        }

        // 확인 버튼
        RoundedButton confirmButton = new RoundedButton("확인");
        confirmButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialogFrame.dispose();
            }
        });
        confirmButton.setBackground(new Color(255, 0, 0)); // 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.setBounds(110, 250, 65, 25);
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }

    private void fetchAndSetData(JSONObject data, JPanel dialogPanel) {
        Post po = new Post();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(31, 31, 31);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(70, 70, 70);
            colors.buttonBackground = new Color(50, 50, 50);
            colors.postbuttonColor = new Color(40, 40, 40);
            colors.RedText = new Color(200, 100, 100);
        }

        // 닉네임 가져오기
        data.put("table", "users");
        data.put("want", "Nickname");
        data.put("what", "UserID");
        data.put("user_id", PostIDD);
        JSONObject SearchNickname1 = po.jsonpost("/find_user_information", data);
        String SearchNickname = SearchNickname1.getString("Nickname");

        // UID 가져오기
        data.put("want", "UID");
        JSONObject SearchSchoolcode1 = po.jsonpost("/find_user_information", data);
        String SearchSchoolcode = SearchSchoolcode1.getString("UID");

        // 학교 이름 가져오기
        data.put("table", "university");
        data.put("want", "UName");
        data.put("what", "UID");
        data.put("user_id", SearchSchoolcode);
        JSONObject SearchSchoolname1 = po.jsonpost("/find_user_information", data);
        String SearchSchoolname = SearchSchoolname1.getString("UName");

        // 학과 이름 가져오기
        data.put("want", "department");
        JSONObject Searchdepartment1 = po.jsonpost("/find_user_information", data);
        String Searchdepartment = Searchdepartment1.getString("department");

        // 닉네임 라벨
        JLabel Nickname = new JLabel("닉네임: " + SearchNickname);
        Nickname.setBounds(94, 150, 150, 20); // Adjust the position and size as needed
        Nickname.setForeground(colors.Text); // Set label text color
        Font labelFont4 = new Font(Nickname.getFont().getName(), Font.BOLD, 14);
        Nickname.setFont(labelFont4);
        dialogPanel.add(Nickname);

        // 학교 이름 라벨
        JLabel Schoolname = new JLabel("학교: " + SearchSchoolname);
        Schoolname.setBounds(94, 170, 150, 20); // Adjust the position and size as needed
        Schoolname.setForeground(new Color(120, 120, 120)); // Set label text color
        Font labelFont5 = new Font(Schoolname.getFont().getName(), Font.BOLD, 11);
        Schoolname.setFont(labelFont5);
        dialogPanel.add(Schoolname);

        // 학과 이름 라벨
        JLabel department = new JLabel("학과: " + Searchdepartment);
        department.setBounds(94, 190, 150, 20); // Adjust the position and size as needed
        department.setForeground(new Color(120, 120, 120)); // Set label text color
        department.setFont(labelFont5);
        dialogPanel.add(department);
    }
}
