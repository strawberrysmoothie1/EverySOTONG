package main.java.com.pws.Thing;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class ImageUtil {
    public static void resize(File src, File dest, int width, int height) throws IOException {
        BufferedImage srcImg = ImageIO.read(src);

        int srcWidth = srcImg.getWidth();
        int srcHeight = srcImg.getHeight();

        int destWidth = width;
        int destHeight = height;

        if (width == -1) {
            destWidth = srcWidth;
        }
        if (height == -1) {
            destHeight = srcHeight;
        }
        if (width == 0 && height == 0) {
            destWidth = srcWidth;
            destHeight = srcHeight;
        } else if (width == 0) {
            double ratio = (double) destHeight / srcHeight;
            destWidth = (int) (srcWidth * ratio);
        } else if (height == 0) {
            double ratio = (double) destWidth / srcWidth;
            destHeight = (int) (srcHeight * ratio);
        }

        Image scaledImg = srcImg.getScaledInstance(destWidth, destHeight, Image.SCALE_SMOOTH);
        BufferedImage destImg = new BufferedImage(destWidth, destHeight, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = destImg.createGraphics();
        g2d.drawImage(scaledImg, 0, 0, null);
        g2d.dispose();

        ImageIO.write(destImg, "jpg", dest);
    }
}
