package main.java.com.pws.Schedule;

import javax.swing.*;
import javax.swing.border.Border;

import org.json.JSONObject;

import main.java.com.pws.Thing.FrameManager;
import main.java.com.pws.Thing.GetLecture;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.collor;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class LectureInfo {
    private String userIDD;
    private String Section;
    private int LectueNum;
    private int DarK;

    private String WhFrame;

    public LectureInfo(String userIDD, String Section, int LectueNum, int DarK, String WhFrame) {
        this.userIDD = userIDD;
        this.Section = Section;
        this.LectueNum = LectueNum;
        this.DarK = DarK;
        this.WhFrame = WhFrame;

        initialize();
    }

	private void initialize() {
        JSONObject data = new JSONObject();
        Post po = new Post();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }

        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(225, 375, 400, 250);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    	FrameManager.addFrame(dialogFrame);
        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setBounds(5, 0, 100, 100);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogFrame.add(dialogPanel);
       
    	FrameManager.addFrame(dialogFrame);

        if (userIDD.equals("admin")) {
 
       
        }
        
        GetLecture  getLecture  = new GetLecture ();
        List<List<String>> Lectures = getLecture.GetLecture();

	    List<String> Lecture = Lectures.get(LectueNum);
	    

        String room_id = Lecture.get(0);
        String lectureID = Lecture.get(1);
        String start_time = Lecture.get(2);
        String end_time = Lecture.get(3);
        String lecture_name = Lecture.get(4);
        String grade = Lecture.get(5);
        String instructor_id = Lecture.get(6);
        String section_id = Lecture.get(7);

        // 제목 라벨
        int nameSize = lecture_name.length();
        JLabel LectureNameLabel = new JLabel(lecture_name);
        LectureNameLabel.setBounds(75, 13, 250, 30); // Adjust the position and size as needed
        LectureNameLabel.setForeground(colors.Text); // Set label text color
        Font ChangePWFont = new Font(LectureNameLabel.getFont().getName(), Font.BOLD, 20);
        LectureNameLabel.setFont(ChangePWFont);
        LectureNameLabel.setHorizontalAlignment(JLabel.CENTER);
        dialogPanel.add(LectureNameLabel);

        
        // 교수이름 가져오기
        data.put("table", "instructor");
        data.put("want", "name");
        data.put("what", "instructor_id");
        data.put("user_id", instructor_id);
        JSONObject Instructorname1 = po.jsonpost("/find_user_information", data);
        String Instructorname = Instructorname1.getString("name");
        
        // 교수 라벨
        JLabel IstructorLabel = new JLabel(Instructorname+ " 교수");
        IstructorLabel.setBounds(275, 50, 150, 15); // Adjust the position and size as needed
        IstructorLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        Font labelFont2 = new Font(IstructorLabel.getFont().getName(), Font.BOLD, 13);
        IstructorLabel.setFont(labelFont2);
        dialogPanel.add(IstructorLabel); 
        
        String year = section_id.substring(0, section_id.length() - 1);
        String intsection = section_id.substring(4, section_id.length() - 0);
        String Scetion = null;
        if(intsection.equals("1")) {
        	Scetion = "1학기";
        } else if(intsection.equals("2")) {
        	Scetion = "계절학기(여름)";
        } else if(intsection.equals("3")) {
        	Scetion = "2학기";
        } else if(intsection.equals("4")) {
        	Scetion = "계절학기(겨울)";
        } 
        
        JLabel SectionLabel = new JLabel(year+"년도 "+Scetion);
        SectionLabel.setBounds(50, 75, 250, 15); // Adjust the position and size as needed
        SectionLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        Font labelFont3 = new Font(SectionLabel.getFont().getName(), Font.BOLD, 11);
        SectionLabel.setFont(labelFont3);
        dialogPanel.add(SectionLabel); 
        
        String Time = start_time +":00-" + end_time+":00";
        if(LectueNum < Lectures.size()-1) {
    	    List<String> Lecture2 = Lectures.get(LectueNum+1);
            String lectureID2 = Lecture2.get(1);
            if (lectureID.equals(lectureID2)) {
	            // 시작시간 가져오기
	            String start_time2 = Lecture2.get(2);
	            // 종료시간 가져오기
	            String end_time2 = Lecture2.get(3);
	            Time = start_time2 +":00-" + end_time2 +":00, " + start_time + ":00-" + end_time+":00";
	            //TimeX = 175;
            }
        }
        // 시간 라벨
        JLabel TimeLabel = new JLabel(Time);
        TimeLabel.setBounds(50, 95, 250, 15); // Adjust the position and size as needed
        TimeLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        TimeLabel.setFont(labelFont2);
        dialogPanel.add(TimeLabel); 
        
        
        // 강의실 가져오기
        data.put("table", "class_room");
        data.put("want", "building");
        data.put("what", "room_id");
        data.put("user_id", room_id);
        JSONObject building1 = po.jsonpost("/find_user_information", data);
        String building = building1.getString("building");
        
        data.put("want", "room_number");
        JSONObject RoomNumber1 = po.jsonpost("/find_user_information", data);
        String RoomNumber = RoomNumber1.getString("room_number");
        
        String Where = building+" "+RoomNumber;
        if(building.equals(" ")) {
        	Where = "강의방식: "+RoomNumber;
        }
        
        JLabel ClassRoomLabel = new JLabel(Where);
        ClassRoomLabel.setBounds(50, 115, 250, 15); // Adjust the position and size as needed
        ClassRoomLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        ClassRoomLabel.setFont(labelFont2);
        dialogPanel.add(ClassRoomLabel); 
        

        String DeptWhat = lectureID.substring(0, lectureID.length() - 5);
        String Searchdepartment = "수업대상자: 모두";
        if(DeptWhat.equals("1")) {
            String SchoolCode = instructor_id.substring(0, instructor_id.length() - 2);
            String Dept = lectureID.substring(1, lectureID.length() - 3);
            String GetUID = SchoolCode+Dept;
	    	// 학교 이름 가져오기
	        data.put("table", "university");
	        data.put("want", "department");
	        data.put("what", "UID");
	        data.put("user_id", GetUID);
	        JSONObject Searchdepartment1 = po.jsonpost("/find_user_information", data);
	        Searchdepartment = "수업대상자: "+Searchdepartment1.getString("department") + "학생";
        }
        // 학과 라벨
        JLabel DeptLabel = new JLabel(Searchdepartment);
        DeptLabel.setBounds(50, 145, 250, 15); // Adjust the position and size as needed
        DeptLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        DeptLabel.setFont(labelFont2);
        dialogPanel.add(DeptLabel); 
        
        JLabel GradeLabel = new JLabel(grade+"학점");
        GradeLabel.setBounds(50, 165, 250, 15); // Adjust the position and size as needed
        GradeLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        GradeLabel.setFont(labelFont2);
        dialogPanel.add(GradeLabel); 
        
        if(WhFrame.equals("빼기")) {
        	RoundedButton AddLecturebutton = new RoundedButton("시간표에서 빼기");
            AddLecturebutton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	minusCheckDialog(lecture_name, lectureID, userIDD);
              	
                }
            });
            AddLecturebutton.setBorder(borderWhite);
            AddLecturebutton.setBackground(new Color(250, 50, 50));// 배경색 설정 (빨간색)
            AddLecturebutton.setForeground(new Color(255, 250, 250)); // 텍스트 색상(흰색)
            AddLecturebutton.setBounds(290, 180, 80, 20);
            Font contentFont = new Font(AddLecturebutton.getFont().getName(), Font.BOLD, 10);
            AddLecturebutton.setFont(contentFont);
            dialogPanel.add(AddLecturebutton);
        }
        
        


        
        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
	
    //삭제 확인
    private void minusCheckDialog(String Lecturnmae,String lecture_id, String UserID) {
    	
        JSONObject data = new JSONObject();
        Post po = new Post();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(31, 31, 31);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(70, 70, 70);
            colors.buttonBackground = new Color(50, 50, 50);
            colors.postbuttonColor = new Color(40, 40, 40);
            colors.RedText = new Color(200, 100, 100);
        }
        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(270, 400, 300, 150);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null); 

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 276, 110);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(borderWhite); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel dialogLabel = new JLabel(Lecturnmae + ": " +lecture_id);
        dialogLabel.setBounds(15, 23, 250, 20);
        dialogLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
        dialogLabel.setHorizontalAlignment(JLabel.CENTER);
        dialogPanel.add(dialogLabel);
        
        // 다이얼로그 라벨 생성
        JLabel dialog2Label = new JLabel("강의를 삭제 하시겠습니까?");
        dialog2Label.setBounds(15, 43, 250, 20);
        dialog2Label.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        dialog2Label.setHorizontalAlignment(JLabel.CENTER);
        dialogPanel.add(dialog2Label);
        
        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("삭제");
        confirmButton.setBounds(110, 80, 65, 20);
        confirmButton.setBackground(new Color(230, 30, 30));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                data.put("table", "lecture");
                data.put("lecture_id", lecture_id);
                data.put("UserID", UserID);
				JSONObject change_check = po.jsonpost("/delete2_column", data);
				boolean success = change_check.getBoolean("success"); 
				System.out.println("강의삭제 성공 여부: " + success);
            	
            	
                FrameManager.closeAllFrames(); // 모든 프레임 닫기
                dialogFrame.dispose();

            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }

}
