package main.java.com.pws.dialog;

import javax.swing.*;
import javax.swing.border.Border;

import org.json.JSONObject;

import main.java.com.pws.Thing.FrameManager;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.RoundtextField;
import main.java.com.pws.Thing.collor;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InstructorInfo {
    private String userIDD;
    private String IntrucID;
    private String Section;
    private int DarK;

    public InstructorInfo(String userIDD, String IntrucID, String Section, int DarK) {
        this.userIDD = userIDD;
        this.IntrucID = IntrucID;
        this.Section = Section;
        this.DarK = DarK;

        initialize();
    }

    private void initialize() {
        JSONObject data = new JSONObject();
        Post po = new Post();
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }


        Border borderBlue = BorderFactory.createLineBorder(new Color(155, 155, 155), 2);
        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);
        Border borderBlack = BorderFactory.createLineBorder(colors.BoardPanel, 1);
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(200, 270, 450, 450);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    	FrameManager.addFrame(dialogFrame);
        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setBounds(5, 0, 100, 100);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogFrame.add(dialogPanel);

        // 작성자 정보 라벨
        JLabel ChangePWLabel = new JLabel("교수 정보");
        ChangePWLabel.setBounds(183, 11, 150, 30); // Adjust the position and size as needed
        ChangePWLabel.setForeground(new Color(100, 100, 100)); // Set label text color
        Font ChangePWFont = new Font(ChangePWLabel.getFont().getName(), Font.BOLD, 16);
        ChangePWLabel.setFont(ChangePWFont);
        dialogPanel.add(ChangePWLabel);

       

        if (userIDD.equals("admin")) {
 
            RoundedButton PostButton = new RoundedButton("개설강의");
            PostButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	MyPostDialog myPostDialog = new MyPostDialog(IntrucID, userIDD, Section, DarK);
                	}
            });
            PostButton.setBackground(new Color(200, 150, 100)); // 배경색 설정 (검은색)
            PostButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
            PostButton.setBounds(370, 37, 55, 18);
            dialogPanel.add(PostButton);
            
            RoundedButton CommentsButton = new RoundedButton("추가예정");
            CommentsButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	MycommentsDialog mycommentsDialog = new MycommentsDialog(IntrucID, userIDD, Section, DarK);
                	}
            });
            CommentsButton.setBackground(new Color(200, 100, 150)); // 배경색 설정 (검은색)
            CommentsButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
            CommentsButton.setBounds(370, 57, 55, 18);
            dialogPanel.add(CommentsButton);          
        }
             
        data.put("table", "instructor");
        data.put("want", "name");
        data.put("what", "instructor_id");
        data.put("user_id", IntrucID);
        JSONObject SearchName1 = po.jsonpost("/find_user_information", data);
        String SearchName = SearchName1.getString("name");
        
        data.put("table", "instructor");
        data.put("want", "UID");
        data.put("what", "instructor_id");
        data.put("user_id", IntrucID);
        JSONObject SearchDept1 = po.jsonpost("/find_user_information", data);
        String SearchUID = SearchDept1.getString("UID");
        
        
     // 학교아이디 라벨
        JLabel universityLabel = new JLabel("학과코드");
        universityLabel.setBounds(125, 115, 150, 15); // Adjust the position and size as needed
        universityLabel.setForeground(new Color(100, 100, 100)); // Set label text color
        Font labelFont2 = new Font(universityLabel.getFont().getName(), Font.BOLD, 9);
        universityLabel.setFont(labelFont2);
        dialogPanel.add(universityLabel);
        // 학교 아이디 입력 필드
        RoundtextField universityField = new RoundtextField();
        universityField.setBounds(120, 130, 200, 35);
        universityField.setBackground(colors.BoardPanel);
        universityField.setForeground(colors.Text);
        dialogPanel.add(universityField);
        universityField.setColumns(10);
        universityField.setBorder(borderBlack);
        universityField.setDefaultText(SearchUID);

        JLabel univerLabel = new JLabel("");

        univerLabel.setForeground(new Color(100, 100, 150)); // Set label text color
        univerLabel.setFont(labelFont2);
        dialogPanel.add(univerLabel);

        // 학교 검색 버튼 (원래 중복 확인 기능은 여기에 넣어도 됨)
        RoundedButton searchButton = new RoundedButton("검색");
        searchButton.setBounds(319, 137, 50, 20);
        searchButton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        searchButton.setForeground(colors.Text); // 텍스트 색상(흰색)
        Font searchFont = new Font(searchButton.getFont().getName(), Font.PLAIN, 10);
        searchButton.setFont(searchFont);
        dialogPanel.add(searchButton); // 패널에 버튼 추가
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String schoolcode = universityField.getText();
                // 여기서 데이터베이스 조회하여 중복 여부 확인
                data.put("what", schoolcode);
                Post po = new Post();
				JSONObject universityInfo = po.jsonpost("/get_university_info", data);
				String getUName = universityInfo.getString("uName");  
				String getDepartment = universityInfo.getString("department"); 
				
                if (getDepartment.equals("없음")) {
                    univerLabel.setText("학교 정보를 찾을 수 없습니다.");
                    univerLabel.setForeground(new Color(150, 100, 100));
                    univerLabel.setBounds(162, 168, 150, 15);
                } else {
                    univerLabel.setText(getUName + "-" + getDepartment);
                    univerLabel.setForeground(new Color(100, 100, 150));
                    univerLabel.setBounds(162, 168, 150, 15);
                }
            }
        });

        // 아이디 라벨
        JLabel useIDLabel = new JLabel("아이디");
        useIDLabel.setBounds(125, 180, 150, 15); // Adjust the position and size as needed
        useIDLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        useIDLabel.setFont(labelFont2);
        dialogPanel.add(useIDLabel);
        // 중복 라벨
        JLabel duplicationLabel = new JLabel("");
        duplicationLabel.setBounds(163, 235, 150, 15); // Adjust the position and size as needed
        duplicationLabel.setForeground(new Color(100, 100, 150)); // Set label text color
        duplicationLabel.setFont(labelFont2);
        dialogPanel.add(duplicationLabel);

        // 아이디 입력 필드
        RoundtextField useIDField = new RoundtextField();
        useIDField.setBounds(120, 195, 200, 35);
        useIDField.setBackground(colors.BoardPanel);
        useIDField.setForeground(colors.Text);
        dialogPanel.add(useIDField);
        useIDField.setColumns(10);
        useIDField.setBorder(borderBlack);
        useIDField.setDefaultText(IntrucID);

        // 별명 라벨
        JLabel nicknameLabel = new JLabel("별명");
        nicknameLabel.setBounds(125, 245, 150, 15); // Adjust the position and size as needed
        nicknameLabel.setForeground(new Color(120, 120, 120)); // Set label text color
        nicknameLabel.setFont(labelFont2);
        dialogPanel.add(nicknameLabel);

        // 중복 라벨
        JLabel NickduplicationLabel = new JLabel("");
        NickduplicationLabel.setBounds(163, 300, 150, 15); // Adjust the position and size as needed
        NickduplicationLabel.setForeground(new Color(100, 100, 150)); // Set label text color
        NickduplicationLabel.setFont(labelFont2);
        dialogPanel.add(NickduplicationLabel);

        // 별명입력 입력 필드
        RoundtextField NicknameField = new RoundtextField();
        NicknameField.setBounds(120, 260, 200, 35);
        NicknameField.setBackground(colors.BoardPanel);
        NicknameField.setForeground(colors.Text);
        dialogPanel.add(NicknameField);
        NicknameField.setColumns(10);
        NicknameField.setBorder(borderBlack);
        NicknameField.setDefaultText(SearchName);

        // 별명중복 확인 버튼 (원래 중복 확인 기능은 여기에 넣어도 됨)
        RoundedButton NicknameDuplicationButton = new RoundedButton("중복 확인");
        NicknameDuplicationButton.setBounds(320, 268, 50, 20);
        Font checkFont1 = new Font(NicknameDuplicationButton.getFont().getName(), Font.PLAIN, 10);
        NicknameDuplicationButton.setFont(checkFont1);

        NicknameDuplicationButton.setBackground(colors.Ground);// 배경색 설정 (빨간색)
        NicknameDuplicationButton.setForeground(colors.Text); // 텍스트 색상(흰색)
        dialogPanel.add(NicknameDuplicationButton); // 패널에 버튼 추가
        NicknameDuplicationButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent en) {
                String Nicknamesave = NicknameField.getText();
                // 여기서 데이터베이스 조회하여 중복 여부 확인
                data.put("where", "name");
                data.put("what", Nicknamesave);
                Post po = new Post();
				JSONObject nickDuplicate = po.jsonpost("/check_Instruc_exists", data);
				boolean nickDuplicate1;
				nickDuplicate1 = nickDuplicate.getBoolean("exists");
                if (nickDuplicate1) {
                    NickduplicationLabel.setText("이미 사용 중인 이름입니다.");
                    NickduplicationLabel.setForeground(new Color(150, 100, 100));
                } else {
                    NickduplicationLabel.setText("사용 가능한 이름입니다.");
                    NickduplicationLabel.setForeground(new Color(100, 100, 150));
                }
            }
        });

        // 회원가입 버튼
        RoundedButton OKButton = new RoundedButton("정보변경");
        OKButton.setBounds(183, 317, 65, 20);
        OKButton.setBackground(new Color(255, 0, 0));// 배경색 설정 (빨간색)
        OKButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        dialogPanel.add(OKButton); // 패널에 버튼 추가

        JLabel OKLabel = new JLabel("");
        OKLabel.setFont(labelFont2);
        dialogPanel.add(OKLabel);

        // 회원가입 버튼에 ActionListener 추가
        OKButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String schoolcode = universityField.getText();
                String enteredID = useIDField.getText();
                String Nicknamesave = NicknameField.getText();

                // 학교 정보 조회
                data.put("what", schoolcode);
                Post po = new Post();
				JSONObject universityInfo = po.jsonpost("/get_university_info", data); 
				String getDepartment = universityInfo.getString("department");
                // 에러 메시지 라벨 초기화
                OKLabel.setText("");

                // 학교 정보가 없으면 에러 메시지 출력
                if (getDepartment.equals("없음")) {
                    OKLabel.setText("학교 학과 코드를 확인해 주세요.");
                    OKLabel.setForeground(new Color(150, 100, 100));
                    OKLabel.setBounds(147, 340, 250, 15);
                } else {
                	
                    if (SearchName.equals(Nicknamesave)) {
	                    //닉네임 변경 없을시        				
	                        data.put("table", "instructor");
	                        data.put("this1", "instructor_id");
	                        data.put("this2", IntrucID);
	                        data.put("what", "UID");
	                        data.put("change", schoolcode);
	        				JSONObject change_check = po.jsonpost("/change_user", data);
	        				boolean success2 = change_check.getBoolean("success"); 
	        				System.out.println("유저비번 변경 성공 여부: " + success2);
	                        // 회원가입 성공 다이얼로그 표시
	                        showSuccessDialog();
	                        dialogFrame.dispose();
	                    
	                    
                    }else {
	                    data.put("where", "name");
	                    data.put("what", Nicknamesave);
	    				JSONObject nickDuplicate = po.jsonpost("/check_Instruc_exists", data);
	    				boolean nickDuplicate1;
	    				nickDuplicate1 = nickDuplicate.getBoolean("exists");
	                    if (nickDuplicate1) {
	                        OKLabel.setText("별명을 확인해 주세요.");
	                        OKLabel.setForeground(new Color(150, 100, 100));
	                        OKLabel.setBounds(166, 340, 250, 15);
	                    }
	                    
	                    // 모든 조건이 충족되면 회원가입 성공
	                    if (!nickDuplicate1) {
	                        // 여기에 회원가입 로직을 추가하면 됩니다.
	                        data.put("table", "instructor");
	                        data.put("this1", "instructor_id");
	                        data.put("this2", IntrucID);
	                        data.put("what", "UID");
	                        data.put("change", schoolcode);
	        				JSONObject change_check = po.jsonpost("/change_user", data);
	        				boolean success = change_check.getBoolean("success"); 
	        				System.out.println("유저비번 변경 성공 여부: " + success);
	        				
	        				
	                        data.put("table", "instructor");
	                        data.put("this1", "instructor_id");
	                        data.put("this2", IntrucID);
	                        data.put("what", "name");
	                        data.put("change", Nicknamesave);
	        				JSONObject change_check2 = po.jsonpost("/change_user", data);
	        				boolean success2 = change_check2.getBoolean("success"); 
	        				System.out.println("유저닉네임 변경 성공 여부: " + success2);
	                        // 회원가입 성공 다이얼로그 표시
	                        showSuccessDialog();
	                        dialogFrame.dispose();
	                    }
                    }
                }
            }
        });
        
        
        
        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
  
    private void showSuccessDialog() {
        collor colors = new collor();
        
        // 다크 모드 또는 라이트 모드에 따라 색상 설정
        if (DarK == 1) {
        	colors.Ground = new Color(40, 40, 40);
            colors.Text = new Color(255, 255, 255);
            colors.BoardPanel = new Color(80, 80, 80);
            colors.buttonBackground = new Color(60, 60, 60);
            colors.postbuttonColor = new Color(50, 50, 50);
            colors.RedText = new Color(200, 100, 100);
        }
        Border borderWhite = BorderFactory.createLineBorder(colors.Ground, 2);

        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(270, 400, 300, 150);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null); 

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 276, 110);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(colors.Ground); // 배경색 설정
        dialogPanel.setBorder(borderWhite); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel dialogLabel = new JLabel("변경 성공!");
        dialogLabel.setBounds(115, 30, 200, 35);
        dialogLabel.setForeground(colors.Text); // 텍스트 색상(흰색)
        dialogPanel.add(dialogLabel);

        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("확인");
        confirmButton.setBounds(110, 80, 65, 20);
        confirmButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	InstructorList UserInstructor = new InstructorList(userIDD, Section, DarK);     	
                dialogFrame.dispose();
            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }
}
