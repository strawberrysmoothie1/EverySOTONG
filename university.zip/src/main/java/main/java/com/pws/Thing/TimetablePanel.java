package main.java.com.pws.Thing;

import javax.swing.*;
import java.awt.*;

public class TimetablePanel extends JPanel {

    public TimetablePanel(Color backgroundColor, Color borderColor, Color textColor) {
        // 레이아웃을 null로 설정하여 좌표를 직접 지정
        setLayout(null);
        
        // 패널의 배경색 설정
        setBackground(backgroundColor);
        
        // 요일 라벨의 기본 설정
        String[] days = {"월", "화", "수", "목", "금"};
        
        // 요일 라벨을 좌표를 사용하여 배치
        int x = 53;  // x 좌표 시작점
        int y = 0;   // y 좌표
        for (String day : days) {
            JLabel dayLabel = new JLabel(day, SwingConstants.CENTER);
            dayLabel.setForeground(textColor);
            dayLabel.setBounds(x, y, 70, 26);  // (x 좌표, y 좌표, 너비, 높이)
            add(dayLabel);
            x += 99;  // 각 라벨의 x 좌표를 100씩 증가시켜 간격을 둠
        }

        // 시간 라벨을 좌표를 사용하여 세로로 배치
        y = 39;  // y 좌표 시작점
        for (int hour = 9; hour <= 19; hour++) {
            JLabel hourLabel = new JLabel(String.valueOf(hour), SwingConstants.CENTER);
            hourLabel.setForeground(textColor);
            hourLabel.setBounds(0, y, 37, 15);  // (x 좌표, y 좌표, 너비, 높이)
            add(hourLabel);
            y += 43;
        }

        // 둥근 테두리 설정
        RoundedBorder2 roundedBorder = new RoundedBorder2(20, borderColor);  // 테두리 색상 포함
        setBorder(roundedBorder);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Graphics2D 객체로 변환
        Graphics2D g2d = (Graphics2D) g;

        // 선의 두께 설정
        g2d.setStroke(new BasicStroke(1));

        // 선 색상 설정 (검은색)
        g2d.setColor(Color.GRAY);

        // 가로선 그리기
        g2d.drawLine(0, 26, 538, 26);  // 9 (시작 x, 시작 y, 끝 x, 끝 y)
        g2d.drawLine(0, 69, 538, 69);  // 10
        g2d.drawLine(0, 112, 538, 112);  // 11
        g2d.drawLine(0, 155, 538, 155);  // 12
        g2d.drawLine(0, 198, 538, 198);  // 13
        g2d.drawLine(0, 241, 538, 241);  // 14
        g2d.drawLine(0, 284, 538, 284);  // 15
        g2d.drawLine(0, 326, 538, 326);  // 16
        g2d.drawLine(0, 369, 538, 369);  // 17
        g2d.drawLine(0, 413, 538, 413);  // 18 
        g2d.drawLine(0, 456, 538, 456);  // 19


        // 세로선 그리기
        g2d.drawLine(37, 0, 37, 500);
        g2d.drawLine(137, 0, 137, 500);
        g2d.drawLine(237, 0, 237, 500);
        g2d.drawLine(337, 0, 337, 500);
        g2d.drawLine(437, 0, 437, 500);

    }
}
