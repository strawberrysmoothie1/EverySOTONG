package main.java.com.pws.Login;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import org.json.JSONArray;
import org.json.JSONObject;

import main.java.com.pws.Thing.RoundPasswordField;
import main.java.com.pws.Thing.Post;
import main.java.com.pws.Thing.RoundedButton;
import main.java.com.pws.Thing.RoundedBorder;
import main.java.com.pws.Thing.RoundtextField;

public class join {

    private JFrame frame;
    private String SchoolUID = "없음";
    private String DeptUID = "없음";


    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    login window = new login();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public join() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
    	JSONObject data = new JSONObject();

        frame = new JFrame();
        frame.setBounds(100, 100, 650, 800); // 프레임 위치 및 크기 설정
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // 닫기 버튼 동작 설정
        frame.getContentPane().setLayout(null); // 레이아웃 설정 (null은 절대 위치 배치)

        Border borderBlack = BorderFactory.createLineBorder(new Color(0, 0, 0), 2);

        // 테두리 스타일 설정
        Border border = BorderFactory.createLineBorder(new Color(255, 0, 0), 2);

        JPanel panel = new JPanel();
        panel.setBounds(5, 0, 625, 755);
        frame.getContentPane().add(panel);
        panel.setLayout(null);
        panel.setBackground(new Color(255, 255, 255)); // 배경색 설정

        // 둥근 페널
        JPanel roundedPanel = new JPanel();
        roundedPanel.setBackground(new Color(255, 255, 255));
        roundedPanel.setBounds(70, 100, 480, 520);
        panel.add(roundedPanel);
        roundedPanel.setLayout(null);
        roundedPanel.setBorder(border); // 테두리 설정
        RoundedBorder roundedBorder = new RoundedBorder(20);
        roundedPanel.setBorder(roundedBorder);

        // 회원가입 라벨
        JLabel joinLabel = new JLabel("회원가입");
        joinLabel.setBounds(275, 40, 200, 20); // Adjust the position and size as needed
        joinLabel.setForeground(new Color(0, 0, 0)); // Set label text color
        // Set a larger font for the label
        Font labelFont = new Font(joinLabel.getFont().getName(), Font.BOLD, 20);
        joinLabel.setFont(labelFont);
        panel.add(joinLabel);

        // 학교아이디 라벨
        JLabel universityLabel = new JLabel("학교이름");
        universityLabel.setBounds(145, 60, 150, 15); // Adjust the position and size as needed
        universityLabel.setForeground(new Color(100, 100, 100)); // Set label text color
        Font labelFont2 = new Font(universityLabel.getFont().getName(), Font.BOLD, 9);
        universityLabel.setFont(labelFont2);
        roundedPanel.add(universityLabel);
        // 학교 아이디 입력 필드
        RoundtextField universityField = new RoundtextField();
        universityField.setBounds(140, 75, 200, 35);
        universityField.setBackground(new Color(200, 200, 200));
        universityField.setForeground(new Color(255, 255, 255));
        roundedPanel.add(universityField);
        universityField.setColumns(10);
        universityField.setBorder(borderBlack);
        universityField.setDefaultText("  학교이름 입력");

        JLabel univerLabel = new JLabel("");

        univerLabel.setForeground(new Color(0, 0, 255)); // Set label text color
        univerLabel.setFont(labelFont2);
        roundedPanel.add(univerLabel);

        // 학교 검색 버튼 (원래 중복 확인 기능은 여기에 넣어도 됨)
        RoundedButton searchButton = new RoundedButton("검색");
        searchButton.setBounds(339, 82, 50, 20);
        searchButton.setBackground(new Color(255, 255, 255));// 배경색 설정 (빨간색)
        searchButton.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        Font searchFont = new Font(searchButton.getFont().getName(), Font.PLAIN, 10);
        searchButton.setFont(searchFont);
        roundedPanel.add(searchButton); // 패널에 버튼 추가
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String schoolName = universityField.getText();
				
        	    data.put("table", "university");
        	    data.put("want", "UName");
        	    data.put("what", "UName");
        	    data.put("user_id", schoolName);
        	    Post po = new Post();
        		JSONObject SearchTextField1 = po.jsonpost("/find_All", data);
        		JSONArray SearchTextField2 = SearchTextField1.getJSONArray("UName");
        		schoolName = SearchTextField2.getString(0);
	    		
                if (schoolName.equals("없음")) {
                    univerLabel.setText("학교 정보를 찾을 수 없습니다.");
                    univerLabel.setForeground(new Color(255, 0, 0));
                    univerLabel.setBounds(182, 113, 150, 15);
                } else {
            	    data.put("want", "UID");
            		JSONObject SearchUID11 = po.jsonpost("/find_All", data);
            		JSONArray SearchUID1 = SearchUID11.getJSONArray("UID");
            		SchoolUID = SearchUID1.getString(0).substring(0, SearchUID1.getString(0).length() - 2);

                    univerLabel.setText(schoolName);
                    univerLabel.setForeground(new Color(0, 0, 255));
                    univerLabel.setBounds(213, 113, 150, 15);
                }
            }
        });

        
        // 학교아이디 라벨
        JLabel departmentLabel = new JLabel("학과이름");
        departmentLabel.setBounds(145, 125, 150, 15); // Adjust the position and size as needed
        departmentLabel.setForeground(new Color(100, 100, 100)); // Set label text color
        departmentLabel.setFont(labelFont2);
        roundedPanel.add(departmentLabel);
        // 학교 아이디 입력 필드
        RoundtextField departmentField = new RoundtextField();
        departmentField.setBounds(140, 140, 200, 35);
        departmentField.setBackground(new Color(200, 200, 200));
        departmentField.setForeground(new Color(255, 255, 255));
        roundedPanel.add(departmentField);
        departmentField.setColumns(10);
        departmentField.setBorder(borderBlack);
        departmentField.setDefaultText("  학과이름 입력");

        JLabel deptLabel = new JLabel("");

        deptLabel.setForeground(new Color(0, 0, 255)); // Set label text color
        deptLabel.setFont(labelFont2);
        roundedPanel.add(deptLabel);

        // 학교 검색 버튼 (원래 중복 확인 기능은 여기에 넣어도 됨)
        RoundedButton search2Button = new RoundedButton("검색");
        search2Button.setBounds(339, 147, 50, 20);
        search2Button.setBackground(new Color(255, 255, 255));// 배경색 설정 (빨간색)
        search2Button.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        search2Button.setFont(searchFont);
        roundedPanel.add(search2Button); // 패널에 버튼 추가
        search2Button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String deptName = departmentField.getText();
				
        	    data.put("table", "university");
        	    data.put("want", "department");
        	    data.put("what", "department");
        	    data.put("user_id", deptName);
        	    Post po = new Post();
        		JSONObject SearchTextField1 = po.jsonpost("/find_All", data);
        		JSONArray SearchTextField2 = SearchTextField1.getJSONArray("department");
        		deptName = SearchTextField2.getString(0);
	    		System.out.println("교수아이디: " +deptName);
	    		
                if (deptName.equals("없음")) {
                    deptLabel.setText("학과 정보를 찾을 수 없습니다.");
                    deptLabel.setForeground(new Color(255, 0, 0));
                    deptLabel.setBounds(182, 178, 150, 15);
                } else {
            	    data.put("want", "UID");
            		JSONObject SearchUID11 = po.jsonpost("/find_All", data);
            		JSONArray SearchUID1 = SearchUID11.getJSONArray("UID");
            		DeptUID = SearchUID1.getString(0).substring(3, SearchUID1.getString(0).length() - 0);

                    deptLabel.setText(deptName);
                    deptLabel.setForeground(new Color(0, 0, 255));
                    deptLabel.setBounds(208, 178, 150, 15);
                }
            }
        });
        
        
        // 아이디 라벨
        JLabel useIDLabel = new JLabel("아이디");
        useIDLabel.setBounds(145, 190, 150, 15); // Adjust the position and size as needed
        useIDLabel.setForeground(new Color(100, 100, 100)); // Set label text color
        useIDLabel.setFont(labelFont2);
        roundedPanel.add(useIDLabel);
        // 중복 라벨
        JLabel duplicationLabel = new JLabel("");
        duplicationLabel.setBounds(183, 245, 150, 15); // Adjust the position and size as needed
        duplicationLabel.setForeground(new Color(0, 0, 255)); // Set label text color
        duplicationLabel.setFont(labelFont2);
        roundedPanel.add(duplicationLabel);

        // 아이디 입력 필드
        RoundtextField useIDField = new RoundtextField();
        useIDField.setBounds(140, 205, 200, 35);
        useIDField.setBackground(new Color(200, 200, 200));
        useIDField.setForeground(new Color(255, 255, 255));
        roundedPanel.add(useIDField);
        useIDField.setColumns(10);
        useIDField.setBorder(borderBlack);
        useIDField.setDefaultText("  아이디");

        // 중복 확인 버튼 (원래 중복 확인 기능은 여기에 넣어도 됨)
        RoundedButton checkDuplicationButton = new RoundedButton("중복 확인");
        checkDuplicationButton.setBounds(340, 213, 50, 20);
        Font checkFont = new Font(checkDuplicationButton.getFont().getName(), Font.PLAIN, 10);
        checkDuplicationButton.setFont(checkFont);

        checkDuplicationButton.setBackground(new Color(255, 255, 255));// 배경색 설정 (빨간색)
        checkDuplicationButton.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        roundedPanel.add(checkDuplicationButton); // 패널에 버튼 추가
        checkDuplicationButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String enteredID = useIDField.getText();
                // 여기서 데이터베이스 조회하여 중복 여부 확인
               
                data.put("where", "UserID");
                data.put("what", enteredID);
                Post po = new Post();
				JSONObject isDuplicate = po.jsonpost("/check_id_exists", data);
				boolean isDuplicate1;
				isDuplicate1 = isDuplicate.getBoolean("exists");
                
                if (isDuplicate1) {
                    duplicationLabel.setText("이미 사용 중인 아이디입니다.");
                    duplicationLabel.setForeground(new Color(255, 0, 0));
                } else {
                    duplicationLabel.setText("사용 가능한 아이디입니다.");
                    duplicationLabel.setForeground(new Color(0, 0, 255));
                }
            }
        });

        // 비밀번호 라벨
        JLabel usePWLabel = new JLabel("비밀번호");
        usePWLabel.setBounds(145, 255, 150, 15); // Adjust the position and size as needed
        usePWLabel.setForeground(new Color(100, 100, 100)); // Set label text color
        usePWLabel.setFont(labelFont2);
        roundedPanel.add(usePWLabel);
        // 비밀번호 입력 필드
        RoundPasswordField usePWField = new RoundPasswordField();
        usePWField.setBounds(140, 270, 200, 35);
        usePWField.setBackground(new Color(200, 200, 200));
        usePWField.setForeground(new Color(255, 255, 255));
        roundedPanel.add(usePWField);
        usePWField.setColumns(10);
        usePWField.setBorder(borderBlack);

        // 비밀번호 확인 입력 필드
        RoundPasswordField usePW2Field = new RoundPasswordField();
        usePW2Field.setBounds(140, 310, 200, 35);
        usePW2Field.setBackground(new Color(200, 200, 200));
        usePW2Field.setForeground(new Color(255, 255, 255));
        roundedPanel.add(usePW2Field);
        usePW2Field.setColumns(10);
        usePW2Field.setBorder(borderBlack);

        // 비밀번호 일치 여부를 표시하는 라벨
        JLabel passwordMatchLabel = new JLabel("");
        passwordMatchLabel.setFont(labelFont2);
        roundedPanel.add(passwordMatchLabel);

        // 비밀번호 확인 필드에 DocumentListener 추가
        usePW2Field.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                checkPasswordMatch();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                checkPasswordMatch();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                checkPasswordMatch();
            }

            private void checkPasswordMatch() {
                String password1 = usePWField.getText();
                String password2 = usePW2Field.getText();

                if (password1.equals(password2)) {
                    if (password1.length() < 8) {
                        passwordMatchLabel.setText("최소 8자리 입력");
                        passwordMatchLabel.setForeground(new Color(255, 0, 0)); // 빨간색
                        passwordMatchLabel.setBounds(200, 345, 250, 15);
                    } else {
                        passwordMatchLabel.setText("비밀번호 일치함");
                        passwordMatchLabel.setForeground(new Color(0, 0, 255)); // 파란색
                        passwordMatchLabel.setBounds(203, 345, 250, 15);
                    }
                } else {
                    passwordMatchLabel.setText("비밀번호 일치하지 않음");
                    passwordMatchLabel.setForeground(new Color(255, 0, 0)); // 빨간색
                    passwordMatchLabel.setBounds(190, 345, 250, 15);
                }
            }
        });

        // 별명 라벨
        JLabel nicknameLabel = new JLabel("별명");
        nicknameLabel.setBounds(145, 360, 150, 15); // Adjust the position and size as needed
        nicknameLabel.setForeground(new Color(100, 100, 100)); // Set label text color
        nicknameLabel.setFont(labelFont2);
        roundedPanel.add(nicknameLabel);

        // 중복 라벨
        JLabel NickduplicationLabel = new JLabel("");
        NickduplicationLabel.setBounds(183, 415, 150, 15); // Adjust the position and size as needed
        NickduplicationLabel.setForeground(new Color(0, 0, 255)); // Set label text color
        NickduplicationLabel.setFont(labelFont2);
        roundedPanel.add(NickduplicationLabel);

        // 별명입력 입력 필드
        RoundtextField NicknameField = new RoundtextField();
        NicknameField.setBounds(140, 375, 200, 35);
        NicknameField.setBackground(new Color(200, 200, 200));
        NicknameField.setForeground(new Color(255, 255, 255));
        roundedPanel.add(NicknameField);
        NicknameField.setColumns(10);
        NicknameField.setBorder(borderBlack);
        NicknameField.setDefaultText("  별명");

        // 별명중복 확인 버튼 (원래 중복 확인 기능은 여기에 넣어도 됨)
        RoundedButton NicknameDuplicationButton = new RoundedButton("중복 확인");
        NicknameDuplicationButton.setBounds(340, 383, 50, 20);
        Font checkFont1 = new Font(NicknameDuplicationButton.getFont().getName(), Font.PLAIN, 10);
        NicknameDuplicationButton.setFont(checkFont1);

        NicknameDuplicationButton.setBackground(new Color(255, 255, 255));// 배경색 설정 (빨간색)
        NicknameDuplicationButton.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        roundedPanel.add(NicknameDuplicationButton); // 패널에 버튼 추가
        NicknameDuplicationButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent en) {
                String Nicknamesave = NicknameField.getText();
                // 여기서 데이터베이스 조회하여 중복 여부 확인
                data.put("where", "Nickname");
                data.put("what", Nicknamesave);
                Post po = new Post();
				JSONObject nickDuplicate = po.jsonpost("/check_id_exists", data);
				boolean nickDuplicate1;
				nickDuplicate1 = nickDuplicate.getBoolean("exists");
                if (nickDuplicate1) {
                    NickduplicationLabel.setText("이미 사용 중인 별명입니다.");
                    NickduplicationLabel.setForeground(new Color(255, 0, 0));
                } else {
                    NickduplicationLabel.setText("사용 가능한 별명입니다.");
                    NickduplicationLabel.setForeground(new Color(0, 0, 255));
                }
            }
        });

        // 회원가입 버튼
        RoundedButton OKButton = new RoundedButton("회원가입");
        OKButton.setBounds(208, 440, 65, 20);
        OKButton.setBackground(new Color(255, 0, 0));// 배경색 설정 (빨간색)
        OKButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        roundedPanel.add(OKButton); // 패널에 버튼 추가

        JLabel OKLabel = new JLabel("");
        OKLabel.setFont(labelFont2);
        roundedPanel.add(OKLabel);

        // 회원가입 버튼에 ActionListener 추가
        OKButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String schoolcode = SchoolUID + DeptUID;
                String enteredID = useIDField.getText();
                String password1 = usePWField.getText();
                String password2 = usePW2Field.getText();
                String Nicknamesave = NicknameField.getText();

                System.out.println(schoolcode);
                // 학교 정보 조회
                data.put("what", schoolcode);
                Post po = new Post();
				JSONObject universityInfo = po.jsonpost("/get_university_info", data); 
				String getDepartment = universityInfo.getString("department");
                // 에러 메시지 라벨 초기화
                OKLabel.setText("");

                // 학교 정보가 없으면 에러 메시지 출력
                if (SchoolUID.equals("없음") || DeptUID.equals("없음")) {
                    OKLabel.setText("학교 학과 코드를 확인해 주세요.");
                    OKLabel.setForeground(new Color(255, 0, 0));
                    OKLabel.setBounds(172, 470, 250, 15);
                } else {
                    // 아이디 중복 확인
                    data.put("where", "UserID");
                    data.put("what", enteredID);
    				JSONObject isDuplicate = po.jsonpost("/check_id_exists", data);
    				boolean isDuplicate1;
    				isDuplicate1 = isDuplicate.getBoolean("exists");
    				
                    // 아이디 중복 에러 메시지 출력
                    if (isDuplicate1) {
                        OKLabel.setText("아이디를 확인해 주세요.");
                        OKLabel.setForeground(new Color(255, 0, 0));
                        OKLabel.setBounds(189, 470, 250, 15);
                    }
                    
                    data.put("where", "Nickname");
                    data.put("what", Nicknamesave);
    				JSONObject nickDuplicate = po.jsonpost("/check_id_exists", data);
    				boolean nickDuplicate1;
    				nickDuplicate1 = nickDuplicate.getBoolean("exists");
                    if (nickDuplicate1) {
                        OKLabel.setText("별명을 확인해 주세요.");
                        OKLabel.setForeground(new Color(255, 0, 0));
                        OKLabel.setBounds(191, 470, 250, 15);
                    }

                    // 비밀번호 확인
                    boolean isPasswordValid = password1.length() >= 8 && password1.equals(password2);
                    // 비밀번호 관련 에러 메시지 출력

                    if (!isPasswordValid && !isDuplicate1) {
                        OKLabel.setText("비밀번호를 확인해 주세요.");
                        OKLabel.setForeground(new Color(255, 0, 0));
                        OKLabel.setBounds(185, 470, 250, 15);
                    }

                    // 모든 조건이 충족되면 회원가입 성공
                    if (!isDuplicate1 && !nickDuplicate1 && isPasswordValid) {
                        // 여기에 회원가입 로직을 추가하면 됩니다.
                        data.put("UserID", enteredID);
                        data.put("UserPW", password1);
                        data.put("UID", schoolcode);
                        data.put("Nickname", Nicknamesave);
                        data.put("LimitDate", 0);
        				JSONObject change_check = po.jsonpost("/register_user", data);
        				boolean success = change_check.getBoolean("success"); 
        				System.out.println("회원가입 성공 여부: " + success);
                        // 회원가입 성공 다이얼로그 표시
                        showSuccessDialog();
                    }
                }
            }
        });

        // 뒤로가기 버튼
        JButton BackButton = new JButton("뒤로가기"); // 버튼 생성 및 텍스트 설정
        BackButton.addActionListener(new ActionListener() { // 클릭 이벤트 리스너 추가
            public void actionPerformed(ActionEvent e) {
                login log = new login();
                log.showFrame();
                frame.dispose();
            }
        });
        BackButton.setBounds(530, 30, 90, 30); // 버튼 위치 및 크기 설정
        BackButton.setBackground(new Color(255, 255, 255));// 배경색 설정 (빨간색)
        BackButton.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        panel.add(BackButton); // 패널에 버튼 추가
        Font memberbuttonFont = new Font(BackButton.getFont().getName(), Font.BOLD, 12);
        BackButton.setFont(memberbuttonFont);
        BackButton.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        BackButton.setContentAreaFilled(false);
        BackButton.setFocusPainted(false);
        BackButton.setOpaque(true);

    }

    public void showFrame() {
        frame.setVisible(true);
    }

    private void showSuccessDialog() {
        // 다이얼로그 프레임 생성
        JFrame dialogFrame = new JFrame();
        dialogFrame.setBounds(270, 400, 300, 150);
        dialogFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dialogFrame.getContentPane().setLayout(null); 

        // 다이얼로그 패널 생성
        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        dialogPanel.setBounds(5, 0, 276, 110);
        dialogPanel.setLayout(null);
        dialogPanel.setBackground(new Color(255, 255, 255)); // 배경색 설정
        dialogPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255), 1)); // 테두리 설정
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 라벨 생성
        JLabel dialogLabel = new JLabel("회원가입 성공!");
        dialogLabel.setBounds(102, 30, 200, 35);
        dialogLabel.setForeground(new Color(0, 0, 0)); // 텍스트 색상(흰색)
        dialogPanel.add(dialogLabel);

        // 확인 버튼 생성
        RoundedButton confirmButton = new RoundedButton("확인");
        confirmButton.setBounds(110, 80, 65, 20);
        confirmButton.setBackground(new Color(100, 100, 100));// 배경색 설정 (빨간색)
        confirmButton.setForeground(new Color(255, 255, 255)); // 텍스트 색상(흰색)
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	frame.dispose();
                login l = new login();
                l.showFrame();
                dialogFrame.dispose();
            }
        });
        dialogPanel.add(confirmButton);

        // 다이얼로그 프레임에 패널 추가
        dialogFrame.getContentPane().add(dialogPanel);

        // 다이얼로그 표시
        dialogFrame.setVisible(true);
    }

}
